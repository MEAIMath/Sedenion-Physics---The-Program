#!/usr/bin/env python3
"""
sedenion_exact.py -- exact verification of every finite claim tagged [EXACT]
in "The Sedenion Presentation, deductive edition", other than blocks C28-C34,
which are verified by the companion scripts c28_doubling.py (clause 8.5(4)),
c29_frames.py (Theorem 3.9) and c30_open_items.py (13.7(iii); Section 11, item 8).

Protocol (Section 0.3 of the paper):
  * Every operator is an integer matrix (basis multiplications are signed
    permutation matrices).  All products, brackets, kernels are computed
    over Z; nothing is floating point except a one-line *screen* in C8 that
    is followed by an exact certificate.
  * Identities are verified on all basis tuples (linearisation lemma).
  * "nullity = k" is certified by (i) k exhibited null vectors verified
    exactly over Z, and (ii) rank modulo the prime P, which satisfies
    rank_P <= rank_Q, hence nullity_Q <= nullity_P.  If nullity_P = k the
    nullity over Q is exactly k.  "rank = full" is certified by rank_P.
"""
import itertools, sys, time
import numpy as np
from sympy import Matrix, sqrt, Rational, simplify, nsimplify, zeros

P = 2147483647  # prime, < 2^31, so products of residues fit in int64

out = []
def log(s=""):
    print(s); out.append(s)

def check(name, cond):
    log(("  [ok]   " if cond else "  [FAIL] ") + name)
    if not cond:
        global failures
        failures += 1
failures = 0

# ---------------------------------------------------------------- algebra
def cd_table(n):
    """Signed multiplication table of the Cayley-Dickson algebra A_n,
    convention (a,b)(c,d) = (ac - conj(d) b, da + b conj(c)).
    Returns S (signs) and K (indices) with e_i e_j = S[i,j] e_{K[i,j]}."""
    if n == 0:
        return np.array([[1]], dtype=np.int64), np.array([[0]], dtype=np.int64)
    s, k = cd_table(n - 1)
    d = 2 ** (n - 1)
    S = np.zeros((2 * d, 2 * d), dtype=np.int64)
    K = np.zeros((2 * d, 2 * d), dtype=np.int64)
    cs = lambda i: 1 if i == 0 else -1          # sign of conj(e_i)
    for i in range(d):
        for j in range(d):
            S[i, j], K[i, j] = s[i, j], k[i, j]                     # (e_i,0)(e_j,0)=(e_i e_j,0)
            S[i, d + j], K[i, d + j] = s[j, i], d + k[j, i]         # (e_i,0)(0,e_j)=(0,e_j e_i)
            S[d + i, j], K[d + i, j] = cs(j) * s[i, j], d + k[i, j] # (0,e_i)(e_j,0)=(0,e_i conj e_j)
            S[d + i, d + j], K[d + i, d + j] = -cs(j) * s[j, i], k[j, i]  # (0,e_i)(0,e_j)=(-conj(e_j) e_i,0)
    return S, K

class Alg:
    def __init__(self, n):
        self.n, self.d = n, 2 ** n
        self.S, self.K = cd_table(n)
        self.Lb = [self.L(self.e(i)) for i in range(self.d)]
        self.Rb = [self.R(self.e(i)) for i in range(self.d)]
    def e(self, i):
        v = np.zeros(self.d, dtype=np.int64); v[i] = 1; return v
    def mul(self, x, y):
        z = np.zeros(self.d, dtype=np.int64)
        for i in np.nonzero(x)[0]:
            for j in np.nonzero(y)[0]:
                z[self.K[i, j]] += x[i] * y[j] * self.S[i, j]
        return z
    def conj(self, x):
        y = -x.copy(); y[0] = x[0]; return y
    def L(self, x):
        M = np.zeros((self.d, self.d), dtype=np.int64)
        for j in range(self.d): M[:, j] = self.mul(x, self.e(j))
        return M
    def R(self, x):
        M = np.zeros((self.d, self.d), dtype=np.int64)
        for j in range(self.d): M[:, j] = self.mul(self.e(j), x)
        return M
    def assoc(self, x, y, z):
        return self.mul(self.mul(x, y), z) - self.mul(x, self.mul(y, z))
    def norm2(self, x): return int(np.dot(x, x))

# ---------------------------------------------------------------- exact linear algebra
def rank_mod_p(M):
    A = np.array(M, dtype=np.int64) % P
    m, n = A.shape; r = 0
    for c in range(n):
        piv = None
        for i in range(r, m):
            if A[i, c] != 0: piv = i; break
        if piv is None: continue
        A[[r, piv]] = A[[piv, r]]
        inv = pow(int(A[r, c]), P - 2, P)
        A[r] = (A[r] * inv) % P
        col = A[:, c].copy(); col[r] = 0
        nz = np.nonzero(col)[0]
        if len(nz):
            A[nz] = (A[nz] - np.outer(col[nz], A[r])) % P
        r += 1
        if r == m: break
    return r

def nullspace_mod_p_lifted(M):
    """Nullspace basis mod P, lifted to symmetric integer range; each vector
    is returned only if it is an exact integer null vector of M."""
    A = np.array(M, dtype=np.int64) % P
    m, n = A.shape; r = 0; pivots = []
    for c in range(n):
        piv = None
        for i in range(r, m):
            if A[i, c] != 0: piv = i; break
        if piv is None: continue
        A[[r, piv]] = A[[piv, r]]
        inv = pow(int(A[r, c]), P - 2, P)
        A[r] = (A[r] * inv) % P
        col = A[:, c].copy(); col[r] = 0
        nz = np.nonzero(col)[0]
        if len(nz):
            A[nz] = (A[nz] - np.outer(col[nz], A[r])) % P
        pivots.append(c); r += 1
        if r == m: break
    free = [c for c in range(n) if c not in pivots]
    vecs = []
    for f in free:
        v = np.zeros(n, dtype=np.int64); v[f] = 1
        for i, pc in enumerate(pivots):
            v[pc] = (-A[i, f]) % P
        v = np.where(v > P // 2, v - P, v)          # symmetric lift
        if np.all(np.array(M, dtype=object).dot(v.astype(object)) == 0):
            vecs.append(v)
    return vecs, len(free)

def exact_nullity(M):
    """Exact nullity over Q with certificate (see protocol)."""
    vecs, nullp = nullspace_mod_p_lifted(M)
    if len(vecs) == nullp:
        return nullp, vecs
    return int(Matrix(M.tolist()).nullspace().__len__()), None  # fallback: sympy exact

def exact_rank(M):
    n = M.shape[1]
    k, _ = exact_nullity(M)
    return n - k

def comm(X, Y): return X @ Y - Y @ X
def acomm(X, Y): return X @ Y + Y @ X
def is_zero(M): return not np.any(M)

def linear_system_commutant(ops, d):
    """Rows of the system  X A - A X = 0  for unknown X (d x d), A in ops."""
    rows = []
    I = np.eye(d, dtype=np.int64)
    for A in ops:
        # vec(XA - AX) = (A^T kron I - I kron A) vec(X)   (row-major vec)
        rows.append(np.kron(I, A) - np.kron(A.T, I))
    return np.vstack(rows)

def linear_system_anticommutant(ops, d):
    rows = []; I = np.eye(d, dtype=np.int64)
    for A in ops:
        rows.append(np.kron(I, A) + np.kron(A.T, I))
    return np.vstack(rows)

def vecmat(X): return X.reshape(-1)

# ================================================================ start
t0 = time.time()
O = Alg(3); Sd = Alg(4); A5 = Alg(5)
log("Exact verification of the finite claims of the deductive edition")
log("=" * 70)

# ---------------------------------------------------------------- C1 identities
log("\nC1. Identities on S, verified on all basis tuples (Section 1.1)")
d = 16; E = [Sd.e(i) for i in range(d)]
ok = True
for i in range(d):
    for j in range(d):
        x, y = E[i], E[j]
        # polarised quadratic identity: xy + yx = 2 x0 y + 2 y0 x - 2<x,y>
        lhs = Sd.mul(x, y) + Sd.mul(y, x)
        rhs = 2 * x[0] * y + 2 * y[0] * x - 2 * int(np.dot(x, y)) * E[0]
        ok &= np.array_equal(lhs, rhs)
check("polarised quadratic identity on all 256 basis pairs", ok)
ok = True
for i in range(d):
    for j in range(d):
        x, y = E[i], E[j]
        ok &= np.array_equal(Sd.conj(Sd.mul(x, y)), Sd.mul(Sd.conj(y), Sd.conj(x)))
        ok &= np.array_equal(Sd.mul(x, Sd.conj(y)) + Sd.mul(y, Sd.conj(x)), 2 * int(np.dot(x, y)) * E[0])
check("conjugation is an anti-automorphism; x conj(y) + y conj(x) = 2<x,y> (256 pairs)", ok)
ok = True
for i in range(d):
    for j in range(d):
        for k in range(d):
            x, y, z = E[i], E[j], E[k]
            ok &= is_zero(Sd.assoc(x, y, z) + Sd.assoc(z, y, x))          # flexibility, linearised
            ok &= int(np.dot(Sd.mul(x, y), z)) == int(np.dot(y, Sd.mul(Sd.conj(x), z)))  # trace form
            ok &= int(np.dot(Sd.mul(x, y), z)) == int(np.dot(x, Sd.mul(z, Sd.conj(y))))
check("linearised flexibility and trace-form invariance on all 4096 basis triples", ok)
ok = all(np.array_equal(Sd.Lb[i].T, Sd.L(Sd.conj(E[i]))) and np.array_equal(Sd.Rb[i].T, Sd.R(Sd.conj(E[i]))) for i in range(d))
check("L_x^T = L_{conj x}, R_x^T = R_{conj x} on the basis", ok)
ok = all(np.array_equal(Sd.Lb[i] @ Sd.Lb[i], -np.eye(d, dtype=np.int64)) for i in range(1, d))
check("L_{e_i}^2 = -Id for i = 1..15 (basis units are alternative)", ok)
z = E[1] + E[10]
check("e_1 + e_10 is not alternative: L_z^2 != -||z||^2 Id", not np.array_equal(Sd.L(z) @ Sd.L(z), -2 * np.eye(d, dtype=np.int64)))
kz, _ = exact_nullity(Sd.L(z))
check(f"e_1 + e_10 is a zero divisor with dim ker L_z = {kz} (exact)", kz == 4)

# ---------------------------------------------------------------- C2 tunnel lemma spot checks
log("\nC2. Tunnel lemma: L_A^T L_A = ||A||^2 Id + [[0,-Phi],[Phi,0]], Phi(y) = (u, conj y, w) (Section 1.3)")
def tunnel_check(a, b):
    A = np.concatenate([a, b])
    LA = Sd.L(A)
    T = LA.T @ LA - Sd.norm2(A) * np.eye(16, dtype=np.int64)
    u = a.copy(); u[0] = 0; w = b.copy(); w[0] = 0
    Phi = np.zeros((8, 8), dtype=np.int64)
    for j in range(8):
        Phi[:, j] = O.assoc(u, O.conj(O.e(j)), w)
    Tpred = np.block([[np.zeros((8, 8), dtype=np.int64), -Phi], [Phi, np.zeros((8, 8), dtype=np.int64)]])
    beta2 = 4 * (O.norm2(u) * O.norm2(w) - int(np.dot(u, w)) ** 2)
    PP = Phi.T @ Phi
    return (np.array_equal(T, Tpred), np.array_equal(Phi.T, -Phi),
            is_zero(PP @ (PP - beta2 * np.eye(8, dtype=np.int64))), exact_rank(Phi), beta2)
tests = [(O.e(1), O.e(2)), (O.e(1) + 2 * O.e(2), 3 * O.e(0) + O.e(3) - O.e(5)),
         (2 * O.e(0) + O.e(1) - O.e(4) + O.e(7), O.e(2) + O.e(6) - 3 * O.e(3)), (O.e(1) + O.e(3), 2 * O.e(1) + 2 * O.e(3))]
for a, b in tests:
    r = tunnel_check(a, b)
    check(f"A=({a.tolist()},{b.tolist()}): block form {r[0]}, Phi skew {r[1]}, Phi^T Phi(Phi^T Phi - beta^2)=0 {r[2]}, rank Phi = {r[3]}, beta^2 = {r[4]}",
          r[0] and r[1] and r[2] and (r[3] == (0 if r[4] == 0 else 4)))

def T_op(alg, v):  # T_v x = (v, v, x) = L_{v^2} x - L_v L_v x
    return alg.L(alg.mul(v, v)) - alg.L(v) @ alg.L(v)
u_ce = Sd.e(1) + Sd.e(10); b_ce = -Sd.e(1) + Sd.e(10)
check("converse of 'diagonal blocks vanish iff u, b alternative' fails: u = e_1+e_10, b = -e_1+e_10 give T_u != 0 but T_u + T_b = 0",
      (not is_zero(T_op(Sd, u_ce))) and is_zero(T_op(Sd, u_ce) + T_op(Sd, b_ce)))

# ---------------------------------------------------------------- C3 commutation graph and cliques
log("\nC3. The commutation graph on the thirty pure generators (Section 2.2-2.3)")
Ls = {i: Sd.Lb[i] for i in range(1, 16)}; Rs = {i: Sd.Rb[i] for i in range(1, 16)}
anti_LL = {(i, j) for i in range(1, 16) for j in range(i + 1, 16) if is_zero(acomm(Ls[i], Ls[j]))}
anti_RR = {(i, j) for i in range(1, 16) for j in range(i + 1, 16) if is_zero(acomm(Rs[i], Rs[j]))}
exceptions = {(i, 8 + j) for i in range(1, 8) for j in range(1, 8) if i != j}
allpairs = {(i, j) for i in range(1, 16) for j in range(i + 1, 16)}
check(f"L-L anticommuting pairs = {len(anti_LL)} = 105 - 42; exceptions are exactly (e_i, e_{{8+j}}), i != j", anti_LL == allpairs - exceptions)
check("R-R anticommutation graph is identical", anti_RR == anti_LL)
mixed_anti = sum(1 for i in range(1, 16) for j in range(1, 16) if is_zero(acomm(Ls[i], Rs[j])))
mixed_comm = {(i, j) for i in range(1, 16) for j in range(1, 16) if is_zero(comm(Ls[i], Rs[j]))}
check(f"no mixed L/R pair anticommutes ({mixed_anti}); commuting mixed pairs are exactly (L_i,R_i) ({len(mixed_comm)})",
      mixed_anti == 0 and mixed_comm == {(i, i) for i in range(1, 16)})
comm_LL = sum(1 for (i, j) in allpairs if is_zero(comm(Ls[i], Ls[j])))
log(f"  counts over 435 pairs: anticommute {2*len(anti_LL)}, commute {len(mixed_comm)+2*comm_LL}, neither {435-2*len(anti_LL)-len(mixed_comm)-2*comm_LL}")

def maximal_cliques(vertices, adj):
    res = []
    def bk(R, Pset, X):
        if not Pset and not X: res.append(frozenset(R)); return
        for v in list(Pset):
            bk(R | {v}, Pset & adj[v], X & adj[v]); Pset = Pset - {v}; X = X | {v}
    bk(set(), set(vertices), set()); return res
adj = {v: set() for v in range(1, 16)}
for (i, j) in anti_LL: adj[i].add(j); adj[j].add(i)
cl = maximal_cliques(range(1, 16), adj)
expected = {frozenset(range(1, 9)), frozenset(range(8, 16))} | {frozenset({i, 8, 8 + i}) for i in range(1, 8)}
check(f"maximal anticommuting cliques among the fifteen L_{{e_i}}: {len(cl)} (two of size 8, seven of size 3)", set(cl) == expected)

# ---------------------------------------------------------------- C4 generation
log("\nC4. The even Cl(0,8) system generates End(R^16) (Section 2.4)")
gens = [Sd.Lb[i] for i in range(1, 9)]
ok = all(np.array_equal(acomm(gens[i], gens[j]), -2 * (i == j) * np.eye(16, dtype=np.int64)) for i in range(8) for j in range(8))
check("Cl(0,8) relations {L_i, L_j} = -2 delta_ij for the even system", ok)
words = []
for r in range(9):
    for sub in itertools.combinations(range(8), r):
        W = np.eye(16, dtype=np.int64)
        for s in sub: W = W @ gens[s]
        words.append(vecmat(W))
check(f"rank of the 256 Clifford words = {rank_mod_p(np.array(words))} = 256 (mod-p certificate suffices for full rank)", rank_mod_p(np.array(words)) == 256)

# ---------------------------------------------------------------- C5 derivations, colour, tau, mu
log("\nC5. Derivations, colour, and the automorphisms tau and mu (Section 3, 6.1)")
def is_derivation(D, alg):
    Ei = [alg.e(i) for i in range(alg.d)]
    for i in range(alg.d):
        for j in range(alg.d):
            if not np.array_equal(D @ alg.mul(Ei[i], Ei[j]), alg.mul(D @ Ei[i], Ei[j]) + alg.mul(Ei[i], D @ Ei[j])):
                return False
    return True
Dgens = []
for a in range(1, 8):
    for b in range(a + 1, 8):
        La, Lb_, Ra, Rb_ = O.Lb[a], O.Lb[b], O.Rb[a], O.Rb[b]
        Dgens.append(comm(La, Lb_) + comm(La, Rb_) + comm(Ra, Rb_))
check("D_{a,b} = [L_a,L_b]+[L_a,R_b]+[R_a,R_b] are derivations of O (all 21)", all(is_derivation(D, O) for D in Dgens))
rk = exact_rank(np.array([vecmat(D) for D in Dgens]))
check(f"they span a space of exact dimension {rk} = dim g_2", rk == 14)
# choose 14 independent ones exactly
basisD = []
for D in Dgens:
    if exact_rank(np.array([vecmat(X) for X in basisD + [D]])) > len(basisD): basisD.append(D)
lift = lambda D: np.block([[D, np.zeros((8, 8), dtype=np.int64)], [np.zeros((8, 8), dtype=np.int64), D]])
DerS = [lift(D) for D in basisD]
check("the diagonal lifts are derivations of S (all 256 basis pairs, 14 generators)", all(is_derivation(D, Sd) for D in DerS))
# colour = derivations killing e_4: exact nullspace of the 14 x 16 system
Mcol = np.array([D @ Sd.e(4) for D in DerS]).T   # 16 x 14
ns = Matrix(Mcol.tolist()).nullspace()
colour = []
for v in ns:
    coeffs = [nsimplify(c) for c in v]
    den = 1
    for c in coeffs: den = np.lcm(den, int(c.q)) if hasattr(c, 'q') else den
    ints = [int(c * den) for c in coeffs]
    colour.append(sum(c * D for c, D in zip(ints, DerS)))
check(f"colour = stabiliser of e_4 in Der(S) has exact dimension {len(colour)} = 8", len(colour) == 8)
check("colour annihilates e_0, e_4, e_8, e_12", all(is_zero(D @ Sd.e(i)) for D in colour for i in (0, 4, 8, 12)))
tau = np.diag([1] * 8 + [-1] * 8).astype(np.int64)
def is_automorphism_int(g, alg):
    Ei = [alg.e(i) for i in range(alg.d)]
    return all(np.array_equal(g @ alg.mul(Ei[i], Ei[j]), alg.mul(g @ Ei[i], g @ Ei[j])) for i in range(alg.d) for j in range(alg.d))
check("tau = diag(1_8, -1_8) is an automorphism of S (all 256 basis pairs)", is_automorphism_int(tau, Sd))
# mu(x) = zeta x conj(zeta), zeta = (-1 + sqrt3 e_8)/2 : exact over Q(sqrt 3)
s3 = sqrt(3)
def smul(x, y):  # sympy vectors
    z = [0] * 16
    for i in range(16):
        if x[i] == 0: continue
        for j in range(16):
            if y[j] == 0: continue
            z[Sd.K[i, j]] += x[i] * y[j] * int(Sd.S[i, j])
    return [simplify(c) for c in z]
zeta = [Rational(-1, 2)] + [0] * 7 + [s3 / 2] + [0] * 7
zbar = [Rational(-1, 2)] + [0] * 7 + [-s3 / 2] + [0] * 7
def mu(x): return smul(smul(zeta, x), zbar)
MU = Matrix([[mu([1 if k == j else 0 for k in range(16)])[i] for j in range(16)] for i in range(16)])
MU = MU.applyfunc(simplify)
mu_is_aut = True
Eb = [[1 if k == j else 0 for k in range(16)] for j in range(16)]
for i in range(16):
    for j in range(16):
        lhs = Matrix(mu(smul(Eb[i], Eb[j])))
        rhs = Matrix(smul(mu(Eb[i]), mu(Eb[j])))
        if any(simplify(c) != 0 for c in (lhs - rhs)): mu_is_aut = False; break
    if not mu_is_aut: break
check("mu(x) = zeta x conj(zeta) is an automorphism (exact over Q(sqrt 3), all basis pairs)", mu_is_aut)
check("mu^3 = 1, mu fixes e_8, tau mu tau = mu^{-1}",
      (MU ** 3 - Matrix.eye(16)).applyfunc(simplify).is_zero_matrix and
      (MU * Matrix(Sd.e(8).tolist()) - Matrix(Sd.e(8).tolist())).applyfunc(simplify).is_zero_matrix and
      (Matrix(tau) * MU * Matrix(tau) - MU ** 2).applyfunc(simplify).is_zero_matrix)

# ---------------------------------------------------------------- C6 the mediator block
log("\nC6. Given the mediator e_4: Q, its Clifford triple, su(2)_Q, J, so(1,3), omega (Section 6)")
L4, L8, L12 = Sd.Lb[4], Sd.Lb[8], Sd.Lb[12]
I16 = np.eye(16, dtype=np.int64)
check("L_4, L_8, L_12 mutually anticommute and square to -Id",
      all(is_zero(acomm(X, Y)) for X, Y in [(L4, L8), (L4, L12), (L8, L12)]) and all(np.array_equal(X @ X, -I16) for X in (L4, L8, L12)))
A, B, C = L8 @ L12, L4 @ L8, L4 @ L12
check("A=L8L12, B=L4L8, C=L4L12: skew, square -Id, pairwise anticommuting, AB = C",
      all(np.array_equal(X.T, -X) and np.array_equal(X @ X, -I16) for X in (A, B, C)) and
      all(is_zero(acomm(X, Y)) for X, Y in [(A, B), (B, C), (A, C)]) and np.array_equal(A @ B, C))
check("[B,C]=2A, [C,A]=2B, [A,B]=2C", np.array_equal(comm(B, C), 2 * A) and np.array_equal(comm(C, A), 2 * B) and np.array_equal(comm(A, B), 2 * C))
J = tau @ L4
check("J = tau L_4: J^2 = -Id, J skew, [J,A]=[J,B]=[J,C]=0", np.array_equal(J @ J, -I16) and np.array_equal(J.T, -J) and all(is_zero(comm(J, X)) for X in (A, B, C)))
check("[tau, L4] = 0, {tau, L8} = {tau, L12} = 0", is_zero(comm(tau, L4)) and is_zero(acomm(tau, L8)) and is_zero(acomm(tau, L12)))
omega = L4 @ L8 @ L12
K1, K2, K3 = tau @ L8, tau @ L12, tau @ omega
check("K3 = J A, K1 = -J B, K2 = -J C", np.array_equal(K3, J @ A) and np.array_equal(K1, -J @ B) and np.array_equal(K2, -J @ C))
check("K_i symmetric with K_i^2 = Id", all(np.array_equal(X.T, X) and np.array_equal(X @ X, I16) for X in (K1, K2, K3)))
six = [A, B, C, K1, K2, K3]
check("J and all six commute with colour", all(is_zero(comm(X, D)) for X in six + [J] for D in colour))
check("omega symmetric involution commuting with the six, with J and with colour",
      np.array_equal(omega.T, omega) and np.array_equal(omega @ omega, I16) and all(is_zero(comm(omega, X)) for X in six + [J] + colour))
Qidx = [0, 4, 8, 12]; Qc = [i for i in range(16) if i not in Qidx]
PQ = np.zeros((16, 16), dtype=np.int64); 
for i in Qidx: PQ[i, i] = 1
PQc = I16 - PQ
check("omega = -1 on Q, +1 on Q^perp", np.array_equal(omega @ PQ, -PQ) and np.array_equal(omega @ PQc, PQc))
check("the six, J, omega and colour preserve Q and Q^perp", all(is_zero(PQc @ X @ PQ) and is_zero(PQ @ X @ PQc) for X in six + [J, omega] + colour))
R4, R8, R12 = Sd.Rb[4], Sd.Rb[8], Sd.Rb[12]
check("J|_Q = R_{e_4}|_Q", np.array_equal(J @ PQ, R4 @ PQ))
check("R_{e_8}^2 = -Id on S (S is a right C_e-space)", np.array_equal(R8 @ R8, -I16))
# Killing signature of span(six), exact
def coords(X, basis):
    M = Matrix([vecmat(b).tolist() for b in basis]).T
    sol = M.solve_least_squares(Matrix(vecmat(X).tolist()))
    assert (M * sol - Matrix(vecmat(X).tolist())).is_zero_matrix
    return sol
ad = []
for X in six:
    ad.append(Matrix.hstack(*[coords(comm(X, Y), six) for Y in six]))
Kill = Matrix(6, 6, lambda i, j: (ad[i] * ad[j]).trace())
ev = Kill.eigenvals()
sig = (sum(m for e, m in ev.items() if e > 0), sum(m for e, m in ev.items() if e == 0), sum(m for e, m in ev.items() if e < 0))
check(f"span{{A,B,C,K1,K2,K3}} closes under bracket; Killing signature (+,0,-) = {sig}", sig == (3, 0, 3))
# commutants (certificates)
rows = linear_system_commutant(six + colour, 16)
nul, vecs = exact_nullity(rows)
cand = [I16, J, omega, omega @ J]
check(f"commutant of so(1,3) + colour: nullity_P = {nul}; {{1, J, omega, omega J}} commute exactly and are independent",
      nul == 4 and all(is_zero(comm(X, Y)) for X in cand for Y in six + colour) and exact_rank(np.array([vecmat(X) for X in cand])) == 4)
rows = linear_system_commutant([A, B, C] + colour, 16)
nul2, _ = exact_nullity(rows)
cand2 = [PQ, R4 @ PQ, R8 @ PQ, R12 @ PQ, PQc, J @ PQc]
check(f"commutant of su(2)_Q + colour on S: nullity_P = {nul2}; exhibited basis 1_Q, R_4|_Q, R_8|_Q, R_12|_Q, 1_Qperp, J|_Qperp",
      nul2 == 6 and all(is_zero(comm(X, Y)) for X in cand2 for Y in [A, B, C] + colour) and exact_rank(np.array([vecmat(X) for X in cand2])) == 6)
# symplectic criterion checks on Q with J' = R_8
def in_sp(X, Jm): return is_zero(X.T @ Jm + Jm @ X)
check("on Q: R_8 commutes with A,B,C and anticommutes with K1,K2,K3  (so(1,3)|_Q is symplectic for sigma_{R_8})",
      all(is_zero(comm(R8, X) @ PQ) for X in (A, B, C)) and all(is_zero(acomm(R8, X) @ PQ) for X in (K1, K2, K3)))
check("on Q: the same holds for R_12 (the circle R_{cos t e_8 + sin t e_12})",
      all(is_zero(comm(R12, X) @ PQ) for X in (A, B, C)) and all(is_zero(acomm(R12, X) @ PQ) for X in (K1, K2, K3)))
sA = [in_sp(X, A) for X in six]
check(f"for J = A the symplectic members of the six are A, K1, K2: {sA}", sA == [True, False, False, True, True, False])
sJ0 = [in_sp(X, -L4) for X in six]
check(f"for J_0 = -L_4 the symplectic members are A, K1, K2: {sJ0}", sJ0 == [True, False, False, True, True, False])
check("no colour-and-su(2)-invariant complex structure on Q^perp anticommutes with J (commutant there is {1, J}, dim 2 by the certificate above)", nul2 == 6)

# ---------------------------------------------------------------- C7 odd system, so(1,8), Y
log("\nC7. The odd Cl(0,8) system, tau, and the hypercharge Y (Section 6.6)")
G = [Sd.Lb[8 + i] for i in range(8)]
check("Cl(0,8) relations for Gamma_i = L_{e_{8+i}}", all(np.array_equal(acomm(G[i], G[j]), -2 * (i == j) * I16) for i in range(8) for j in range(8)))
check("tau anticommutes with every Gamma_i", all(is_zero(acomm(tau, g)) for g in G))
rows = linear_system_anticommutant(G, 16)
nulA, _ = exact_nullity(rows)
check(f"anticommutant of the odd system: nullity_P = {nulA}, spanned by tau (exact)", nulA == 1)
vol = np.eye(16, dtype=np.int64)
for g in G: vol = vol @ g
check("tau = +/- Gamma_0 ... Gamma_7 (the volume element)", np.array_equal(vol, tau) or np.array_equal(vol, -tau))
Y = G[1] @ G[5] + G[2] @ G[6] + G[3] @ G[7]
check("Y commutes with A,B,C,K1,K2,K3, tau, colour", all(is_zero(comm(Y, X)) for X in six + [tau] + colour))
check("Y^2 = -9 on Q and -1 on Q^perp; Y|_Q = 3 R_4|_Q", np.array_equal(Y @ Y @ PQ, -9 * PQ) and np.array_equal(Y @ Y @ PQc, -PQc) and np.array_equal(Y @ PQ, 3 * R4 @ PQ))
yA = np.array_equal(Y, J @ (2 * I16 - omega)); yB = np.array_equal(Y, J @ (I16 - 2 * omega))
check(f"Y lies in the commutant span{{1,J,omega,omega J}}: Y = J(2 - omega) is {yA}, Y = J(1 - 2 omega) is {yB}", yA or yB)
check("Gamma_1Gamma_5, Gamma_2Gamma_6, Gamma_3Gamma_7 commute pairwise and square to -Id",
      all(is_zero(comm(G[i] @ G[i + 4], G[j] @ G[j + 4])) for i in (1, 2, 3) for j in (1, 2, 3)) and all(np.array_equal((G[i] @ G[i + 4]) @ (G[i] @ G[i + 4]), -I16) for i in (1, 2, 3)))
J0 = -L4
check("J_0 = -L_4 pairs (e_1,e_5),(e_2,e_6),(e_3,e_7)", all(np.array_equal(J0 @ Sd.e(i), Sd.e(i + 4)) for i in (1, 2, 3)))
biv = [G[i] @ G[j] for i in range(8) for j in range(i + 1, 8)] + [tau @ g for g in G]
r36 = exact_rank(np.array([vecmat(X) for X in biv]))
ranks = {nm: exact_rank(np.array([vecmat(X) for X in biv + [Z]])) for nm, Z in [("A", A), ("B", B), ("C", C), ("K1", K1), ("K2", K2), ("K3", K3)]}
check(f"the 36 bivectors of the Cl(1,8) system have rank {r36}; adjoining A,K1,K2 keeps 36, adjoining B,C,K3 gives 37: {ranks}",
      r36 == 36 and ranks["A"] == 36 and ranks["K1"] == 36 and ranks["K2"] == 36 and ranks["B"] == 37 and ranks["C"] == 37 and ranks["K3"] == 37)

# ---------------------------------------------------------------- C8 A_5 data
log("\nC8. A_5: annihilator strata and the exact composition witness (Section 5)")
zd2 = [Sd.e(i) + s * Sd.e(j) for i in range(1, 8) for j in range(9, 16) if j - 8 != i for s in (1, -1)]
check(f"the {len(zd2)} elements e_i +/- e_j (i in 1..7, j in 9..15, j-8 != i) are all zero divisors of S with 4-dim kernel",
      all(exact_nullity(Sd.L(z))[0] == 4 for z in zd2))
# c_4 witness
z = Sd.e(1) + Sd.e(10); Lz = Sd.L(z)
top = Lz.T @ Lz - 4 * I16
k4, vs = exact_nullity(top)
y = vs[0]
check(f"S: x = e_1+e_10, y = {y.tolist()}: ||xy||^2 = {Sd.norm2(Sd.mul(z, y))}, ||x||^2||y||^2 = {Sd.norm2(z)*Sd.norm2(y)}  -> ratio^2 = 2 exactly",
      Sd.norm2(Sd.mul(z, y)) == 2 * Sd.norm2(z) * Sd.norm2(y))
# annihilator census of two-term elements in A_5
strata = {}
reps = {}
for i in range(1, 32):
    for j in range(i + 1, 32):
        for s in (1, -1):
            x = A5.e(i) + s * A5.e(j)
            k, _ = exact_nullity(A5.L(x))
            strata[k] = strata.get(k, 0) + 1
            reps.setdefault(k, x)
check(f"A_5: the {sum(strata.values())} two-term elements e_i +/- e_j (1 <= i < j <= 31) have annihilator dimensions {sorted(strata)} with counts {dict(sorted(strata.items()))}", sorted(strata) == [0, 4, 8, 12] and sum(strata.values()) == 930)
for k in (4, 8, 12):
    x = reps[k]; nz = np.nonzero(x)[0]
    log(f"    representative with dim ker = {k}: e_{nz[0]} {'+' if x[nz[1]]>0 else '-'} e_{nz[1]}")
# doubling lemma check in A_6
A6 = Alg(6)
ok = True
for k in (4, 8, 12):
    x = np.concatenate([reps[k], np.zeros(32, dtype=np.int64)])
    kk, _ = exact_nullity(A6.L(x))
    ok &= (kk == 2 * k)
    log(f"    (z,0) in A_6 for the dim-{k} representative: dim ker = {kk}")
check("annihilator dimension doubles under z -> (z,0) (Lemma 5.2), checked on the three representatives", ok)
# composition witness with ratio exactly 2
found = None
for u in zd2:
    for b in zd2:
        x = np.concatenate([u, b])
        Lx = A5.L(x)
        lam = np.linalg.eigvalsh((Lx.T @ Lx).astype(float)).max()   # float SCREEN only
        if lam > 15.999:
            M = Lx.T @ Lx - 16 * np.eye(32, dtype=np.int64)
            k, vs = exact_nullity(M)
            if k > 0 and vs:
                yv = vs[0]
                if A5.norm2(A5.mul(x, yv)) == 4 * A5.norm2(x) * A5.norm2(yv):
                    found = (x, yv, k); break
    if found: break
x, yv, k = found
nx = np.nonzero(x)[0]; ny = np.nonzero(yv)[0]
log(f"    witness x = " + " ".join(f"{'+' if x[i]>0 else '-'}e_{i}" for i in nx))
log(f"    witness y = " + " ".join(f"{'+' if yv[i]>0 else '-'}{abs(yv[i]) if abs(yv[i])!=1 else ''}e_{i}" for i in ny))
log(f"    ||x||^2 = {A5.norm2(x)}, ||y||^2 = {A5.norm2(yv)}, ||xy||^2 = {A5.norm2(A5.mul(x, yv))}, top eigenspace dim = {k}")
check("A_5: exact pair with ||xy||^2 = 4 ||x||^2 ||y||^2, i.e. composition ratio exactly 2", found is not None)
check("hence c_5 = 2 exactly (upper bound by Theorem 5.1, lower bound by the witness)", found is not None)

# ---------------------------------------------------------------- C9 capability data
log("\nC9. Zero divisors exhibited for the split classes (Section 4.2)")
for name, v in [("e_1 - e_13 in S_8", Sd.e(1) - Sd.e(13)), ("e_4 + e_15 in twin^perp", Sd.e(4) + Sd.e(15)), ("e_4 + e_9 in S_8^perp", Sd.e(4) + Sd.e(9))]:
    k, _ = exact_nullity(Sd.L(v))
    check(f"{name}: dim ker L = {k}", k == 4)

# ---------------------------------------------------------------- C10 the observable skeleton
log("\nC10. The colour-singlet observable skeleton and the up/down involutions (Section 10.2)")
nulC, _ = exact_nullity(linear_system_commutant(colour, 16))
EQ = []
for i in (0, 4, 8, 12):
    for j in (0, 4, 8, 12):
        M = np.zeros((16, 16), dtype=np.int64); M[i, j] = 1; EQ.append(M)
eight = [I16, J, A, B, C, J @ A, J @ B, J @ C]
candC = EQ + [X @ PQc for X in eight]
check(f"commutant of colour in End(S): nullity_P = {nulC}; exhibited basis End(Q) (16) + {{1,J,A,B,C,JA,JB,JC}}|_Qperp (8) commutes exactly and has rank 24",
      nulC == 24 and all(is_zero(comm(X, D)) for X in candC for D in colour) and exact_rank(np.array([vecmat(X) for X in candC])) == 24)
nulJ, _ = exact_nullity(linear_system_commutant(colour + [J], 16))
candJ = [X @ PQ for X in eight] + [X @ PQc for X in eight]
check(f"J-linear colour-singlet operators: nullity_P = {nulJ}; exhibited basis {{1,J,A,B,C,JA,JB,JC}} on Q and on Qperp commutes exactly and has rank 16",
      nulJ == 16 and all(is_zero(comm(X, D)) for X in candJ for D in colour + [J]) and exact_rank(np.array([vecmat(X) for X in candJ])) == 16)
closed = True
for Pblk in (PQ, PQc):
    blk = [X @ Pblk for X in eight]
    closed &= exact_rank(np.array([vecmat(X) for X in blk + [X @ Y for X in blk for Y in blk]])) == 8
check("each block is closed under multiplication: two copies of H (x) C = M_2(C), with J central and A,B,C the quaternion units", closed)
ok = True
for Jn in (A, B, C):
    X = Jn @ J
    ok &= np.array_equal(X.T, X) and np.array_equal(X @ X, I16) and int(np.trace(X @ PQ)) == 0 and int(np.trace(X @ PQc)) == 0
check("for n = e_4, e_8, e_12: J_n J is a symmetric involution, traceless on Q and on Qperp (the up/down eigenplanes are 2-dimensional)", ok)
Yop = G[1] @ G[5] + G[2] @ G[6] + G[3] @ G[7]
centre = [PQ, J @ PQ, PQc, J @ PQc]
check("the centre of A_0 is span{1_Q, J_Q, 1_Qperp, J_Qperp} = span{1, J, omega, omega J} (the commutant of 6.5(3)); Y commutes with all of A_0 and lies in it",
      exact_rank(np.array([vecmat(X) for X in centre + [I16, J, omega, omega @ J]])) == 4 and all(is_zero(comm(Yop, X)) for X in candJ)
      and exact_rank(np.array([vecmat(X) for X in centre + [Yop]])) == 4)
check("the unit 1 is annihilated by colour and by every derivation lift, and fixed by tau", all(is_zero(D @ Sd.e(0)) for D in colour + DerS) and np.array_equal(tau @ Sd.e(0), Sd.e(0)))

# ---------------------------------------------------------------- C11 the canonical complex structure and quantisation
log("\nC11. The canonical complex structure R_{e_8} and the canonical quantisation (Sections 3.7, 8.2, 8.4)")
check("R_{e_8} is skew with square -Id; it commutes with every derivation lift and with colour; tau R_{e_8} tau = -R_{e_8}",
      np.array_equal(R8.T, -R8) and np.array_equal(R8 @ R8, -I16) and all(is_zero(comm(R8, D)) for D in DerS + colour) and np.array_equal(tau @ R8 @ tau, -R8))
def in_sp_on(X, Jm, Pr): return is_zero((X.T @ Jm + Jm @ X) @ Pr)
onQ = [in_sp_on(X, R8, PQ) for X in six]; onQc = [in_sp_on(X, R8, PQc) for X in six]
check(f"for sigma_e = <x, y e_8>: on Q all six are symplectic {onQ}; on Qperp exactly C, K1, K3 are {onQc}",
      onQ == [True] * 6 and onQc == [False, False, True, True, False, True])
check("{C, K1, K3} closes: [C,K1] = 2K3, [C,K3] = -2K1, [K1,K3] = -2C  (an so(1,2))",
      np.array_equal(comm(C, K1), 2 * K3) and np.array_equal(comm(C, K3), -2 * K1) and np.array_equal(comm(K1, K3), -2 * C))
oddb = [G[i] @ G[j] for i in range(8) for j in range(i + 1, 8)]
evb = [gens[i] @ gens[j] for i in range(8) for j in range(i + 1, 8)]
sb = [in_sp_on(tau @ g, R8, I16) for g in G]
check(f"no bivector of either Cl(0,8) system is symplectic for sigma_e ({sum(in_sp_on(X, R8, I16) for X in oddb)} + {sum(in_sp_on(X, R8, I16) for X in evb)} of 56); of the boosts tau Gamma_i exactly tau Gamma_0 = K1 is: {sb}",
      sum(in_sp_on(X, R8, I16) for X in oddb + evb) == 0 and sb == [True] + [False] * 7)
check("the unit 1 is not separating for A_0: A_0 . 1 = Q (so no faithful vector state, no modular flow)",
      exact_rank(np.array([X @ Sd.e(0) for X in candJ])) == 4 and all(is_zero(PQc @ X @ Sd.e(0)) for X in candJ))

# ---------------------------------------------------------------- C12 the Pati-Salam so(6) and its spinor complex structure
log("\nC12. The coloured so(6) of the odd system and the complex structure omega J (Section 6.7(6))")
idx6 = [1, 2, 3, 5, 6, 7]
so6 = [G[i] @ G[j] for a, i in enumerate(idx6) for j in idx6[a + 1:]]
oJ = omega @ J
check("omega J = -tau Gamma_0 Gamma_4 (built from the odd system and the grading alone)", np.array_equal(oJ, -tau @ G[0] @ G[4]))
check("omega J commutes with all 15 bivectors of so(6)_c; J does not",
      all(is_zero(comm(oJ, X)) for X in so6) and not all(is_zero(comm(J, X)) for X in so6))
check(f"colour lies inside so(6)_c: rank of the 15 bivectors is {exact_rank(np.array([vecmat(X) for X in so6]))}, unchanged when colour is adjoined",
      exact_rank(np.array([vecmat(X) for X in so6])) == 15 and exact_rank(np.array([vecmat(X) for X in so6 + colour])) == 15)
# each colour derivation equals its bivector image: 4 D = s * sum_{i<j} M_ij (Gamma_i Gamma_j - Gamma_j Gamma_i)/... use M from [D,Gamma_k] = sum_j M_jk Gamma_j
okB = True
for D in colour:
    M = np.zeros((8, 8), dtype=np.int64)
    for k in range(8):
        v = D @ Sd.e(8 + k)           # = (0, D_0 e_k): coefficients are M[j,k]
        M[:, k] = v[8:]
    Bsum = sum(M[i, j] * (G[i] @ G[j]) for i in range(8) for j in range(8))
    okB &= np.array_equal(4 * D, Bsum) or np.array_equal(4 * D, -Bsum)
check("each colour derivation D equals its bivector (1/4) sum_ij M_ij Gamma_i Gamma_j with [D,Gamma_k] = sum_j M_jk Gamma_j (exact, up to the sign convention)", okB)
nul6, _ = exact_nullity(linear_system_commutant(so6, 16))
cand6 = [I16, G[0] @ G[4], tau @ G[0], tau @ G[4], tau @ G[0] @ G[4], G[0], G[4], tau]
check(f"commutant of so(6)_c: nullity_P = {nul6}; exhibited basis of rank 8 commutes exactly; omega J is central in it",
      nul6 == 8 and all(is_zero(comm(X, Z)) for X in cand6 for Z in so6) and exact_rank(np.array([vecmat(X) for X in cand6])) == 8 and all(is_zero(comm(oJ, X)) for X in cand6))
nulAll, _ = exact_nullity(linear_system_commutant(six + colour + so6, 16))
check(f"commutant of so(1,3)_Q + colour + so(6)_c: nullity_P = {nulAll}; spanned by 1 and omega J -> the invariant complex structures are +/- omega J only",
      nulAll == 2 and all(is_zero(comm(X, Z)) for X in [I16, oJ] for Z in six + colour + so6))
check(f"readings of Y: tr(J Y) = {int(np.trace(J @ Y))} (not a branching), tr(omega J . Y) = {int(np.trace(oJ @ Y))}; Y = -3 omega J on Q and + omega J on Qperp (the branching 4 -> 3_1 + 1_-3)",
      int(np.trace(oJ @ Y)) == 0 and np.array_equal(Y @ PQ, -3 * oJ @ PQ) and np.array_equal(Y @ PQc, oJ @ PQc))

# ---------------------------------------------------------------- C13 the two complex structures and the unitarity obstruction
log("\nC13. R_{e_8} versus omega J, and why no squeeze is unitary (Sections 8.6-8.7)")
check("[R_{e_8}, omega J] = -2 R_{e_12} P_Q exactly; the two commute on Qperp",
      np.array_equal(comm(R8, oJ), -2 * R12 @ PQ) and is_zero(comm(R8, oJ) @ PQc))
Ei = R8 @ oJ
Vp = PQc - Ei @ PQc; Vm = PQc + Ei @ PQc
check(f"on Qperp, R8.omegaJ is a symmetric involution; Qperp = V+ (R8 = omega J) + V- (R8 = -omega J) with dims {exact_rank(Vp)}, {exact_rank(Vm)}",
      is_zero((Ei.T - Ei) @ PQc) and np.array_equal(Ei @ Ei @ PQc, PQc) and exact_rank(Vp) == 6 and exact_rank(Vm) == 6)
check("V+ and V- are colour-invariant and C-invariant; the boosts K1, K3 exchange them; A, B do not preserve them",
      all(is_zero(comm(D, Vp)) for D in colour) and is_zero(comm(C, Vp)) and is_zero(acomm(K1, Ei) @ PQc) and is_zero(acomm(K3, Ei) @ PQc)
      and not is_zero(comm(A, Vp)) and not is_zero(comm(B, Vp)))
check("every boost K_i and every tau Gamma_i is a symmetric involution with trace 0 (eigenvalues +1, -1 each of multiplicity 8), so e^{tX} has eigenvalues e^{+t}, e^{-t}",
      all(np.array_equal(X.T, X) and np.array_equal(X @ X, I16) and int(np.trace(X)) == 0 for X in [K1, K2, K3] + [tau @ g for g in G]))
nulRT, _ = exact_nullity(linear_system_commutant([R8, tau], 16))
check(f"the J_e-linear operators commuting with tau form a space of dimension {nulRT} (many standard subspaces have J_H = tau: none is canonical)", nulRT == 64)

# ---------------------------------------------------------------- C14 Lorentz versus the Pati-Salam su(4); statistics
log("\nC14. so(1,3)_Q versus so(6)_c, and the boosts as CAR reflections (Section 12)")
cm = {nm: all(is_zero(comm(X, Z)) for Z in so6) for nm, X in zip("A B C K1 K2 K3".split(), six)}
check(f"of the six, exactly A, K1, K2 commute with the Pati-Salam so(6)_c: {cm} -> so(1,3)_Q and su(4) do not commute on S",
      cm == {"A": True, "B": False, "C": False, "K1": True, "K2": True, "K3": False})
check("Y commutes with all of so(1,3)_Q, so S is a module for so(1,3)_Q + colour + u(1)_Y jointly", all(is_zero(comm(Y, X)) for X in six))
check("each boost K_i is an orthogonal involution (a CAR-Bogoliubov reflection), while e^{tK_i} is not orthogonal for t != 0",
      all(np.array_equal(X.T @ X, I16) for X in (K1, K2, K3)) and not np.array_equal((2 * I16 + K1).T @ (2 * I16 + K1), 5 * I16))

# ---------------------------------------------------------------- C15 the "neither" edges and the Lie algebras they generate
log("\nC15. Ranks on the 'neither' edges; Lie algebras generated by the thirty generators (Theorem 2.7)")
LsAll = [Sd.Lb[i] for i in range(1, 16)]; RsAll = [Sd.Rb[i] for i in range(1, 16)]
rLL = {}
for i in range(15):
    for j in range(i + 1, 15):
        X = acomm(LsAll[i], LsAll[j])
        if not is_zero(X): rLL[exact_rank(X)] = rLL.get(exact_rank(X), 0) + 1
rLR = {}; r4pairs = set()
for i in range(15):
    for j in range(15):
        if i == j: continue
        r = exact_rank(comm(LsAll[i], RsAll[j])); rLR[r] = rLR.get(r, 0) + 1
        if r == 4: r4pairs.add((i + 1, j + 1))
excp = {(i, 8 + j) for i in range(1, 8) for j in range(1, 8) if i != j}
check(f"L-L neither edges: rank of {{L_i,L_j}} is 8 on all 42 ({rLL}); L-R neither edges: rank of [L_i,R_j] is {rLR}, rank 4 exactly on the exceptional pairs (i,8+j),(8+j,i)",
      rLL == {8: 42} and rLR == {12: 126, 4: 84} and r4pairs == excp | {(b, a) for (a, b) in excp})
class _Ech:
    def __init__(self): self.rows = []; self.piv = []
    def add(self, v):
        v = np.array(v, dtype=np.int64) % P
        for r, pc in zip(self.rows, self.piv):
            if v[pc]: v = (v - v[pc] * r) % P
        nz = np.nonzero(v)[0]
        if len(nz) == 0: return False
        pc = nz[0]; v = (v * pow(int(v[pc]), P - 2, P)) % P
        for k in range(len(self.rows)):
            if self.rows[k][pc]: self.rows[k] = (self.rows[k] - self.rows[k][pc] * v) % P
        self.rows.append(v); self.piv.append(pc); return True
def _lie_dim(gs, cap):
    E = _Ech(); basis = []
    for g in gs:
        if E.add(vecmat(g)): basis.append(g)
    frontier = list(basis)
    while frontier and len(basis) < cap:
        new = []
        for a in frontier:
            for b in basis:
                c = comm(a, b)
                if not is_zero(c) and E.add(vecmat(c)):
                    basis.append(c); new.append(c)
                    if len(basis) >= cap: return len(basis)
        frontier = new
    return len(basis)
d30 = _lie_dim(LsAll + RsAll, 256); d31 = _lie_dim(LsAll + RsAll + [tau], 256)
check(f"the thirty generators generate a Lie algebra of dimension {d30} = dim so(16) (mod-p lower bound; it is contained in so(16), so equal); with tau, dimension {d31} = dim sl(16)",
      d30 == 120 and d31 == 255)

# ---------------------------------------------------------------- C16 S acting on its own doublings A_5, A_6
log("\nC16. The native action of S on its doublings A_5 = S + S e_16 and A_6 (Section 13)")
A6 = Alg(6)
okblk = True
for x in (Sd.e(4), Sd.e(8), Sd.e(12)):
    X5 = A5.L(np.concatenate([x, np.zeros(16, dtype=np.int64)]))
    okblk &= np.array_equal(X5, np.block([[Sd.L(x), np.zeros((16, 16), dtype=np.int64)], [np.zeros((16, 16), dtype=np.int64), Sd.R(x)]]))
    X6 = A6.L(np.concatenate([x, np.zeros(48, dtype=np.int64)]))
    blocks = [X6[16 * i:16 * i + 16, 16 * i:16 * i + 16] for i in range(4)]
    off = X6.copy()
    for i in range(4): off[16 * i:16 * i + 16, 16 * i:16 * i + 16] = 0
    okblk &= is_zero(off) and np.array_equal(blocks[0], Sd.L(x)) and np.array_equal(blocks[1], Sd.R(x)) and np.array_equal(blocks[2], Sd.R(x)) and np.array_equal(blocks[3], Sd.R(Sd.conj(x)))
check("for x in S: L^(5)_x = L_x (+) R_x on A_5, and L^(6)_x = L_x (+) R_x (+) R_x (+) R_xbar on A_6 (block-diagonal)", okblk)
tauh6 = np.kron(np.eye(4, dtype=np.int64), tau); E6 = [A6.e(i) for i in range(64)]
check("tau (+) tau (+) tau (+) tau is an automorphism of A_6", all(np.array_equal(tauh6 @ A6.mul(E6[i], E6[j]), A6.mul(tauh6 @ E6[i], tauh6 @ E6[j])) for i in range(64) for j in range(64)))
def rep_copy(kind):
    M = (lambda i: Sd.L(Sd.e(i))) if kind == "L" else (lambda i: Sd.R(Sd.e(i))) if kind == "R" else (lambda i: Sd.R(Sd.conj(Sd.e(i))))
    l4, l8, l12 = M(4), M(8), M(12)
    return [l8 @ l12, l4 @ l8, l4 @ l12, tau @ l8, tau @ l12, tau @ l4 @ l8 @ l12] + colour
reps = {k: rep_copy(k) for k in ("L", "R", "Rbar")}
def hom(ra, rb):
    rows = np.vstack([np.kron(I16, Bm) - np.kron(Am.T, I16) for Am, Bm in zip(ra, rb)])
    nul, vecs = exact_nullity(rows)
    Xs = [v.reshape(16, 16) for v in (vecs or [])]
    q = exact_rank(np.array([vecmat(PQ @ X @ PQ) for X in Xs])) if Xs else 0
    qc = exact_rank(np.array([vecmat(PQc @ X @ PQc) for X in Xs])) if Xs else 0
    return nul, q, qc
H = {(a, b): hom(reps[a], reps[b]) for a in reps for b in reps}
check(f"intertwiner spaces between the copy types (dim; Q-part; Qperp-part): L->L {H[('L','L')]}, R->R {H[('R','R')]}, L->R {H[('L','R')]}, L->Rbar {H[('L','Rbar')]}, R->Rbar {H[('R','Rbar')]}",
      H[('L','L')] == (4, 2, 2) and H[('R','R')] == (4, 2, 2) and H[('L','R')] == (2, 2, 0) and H[('R','L')] == (2, 2, 0) and H[('L','Rbar')] == (4, 2, 2) and H[('Rbar','L')] == (4, 2, 2) and H[('R','Rbar')] == (2, 2, 0))
c5 = sum(H[(a, b)][0] for a in ("L", "R") for b in ("L", "R"))
c6 = sum(H[(a, b)][0] for a in ("L", "R", "R", "Rbar") for b in ("L", "R", "R", "Rbar"))
check(f"commutant of so(1,3)_Q + colour: on A_5 dim {c5} = M_2(C) + C + C (a doublet on the singlet block only); on A_6 dim {c6} = M_4(C) + M_2(C) + M_2(C) (two inequivalent coloured doublet classes {{L,Rbar}} and {{R,R}}, and a singlet quartet)",
      c5 == 12 and c6 == 48)
Cj = -I16.copy(); Cj[0, 0] = 1
ok_int = all(np.array_equal(T @ Am, Bm @ T) for T in (Cj @ R8 @ PQ, Cj @ R12 @ PQ) for Am, Bm in zip(reps["L"], reps["R"])) and all(np.array_equal(Cj @ Am, Bm @ Cj) for Am, Bm in zip(reps["L"], reps["Rbar"]))
check("canonical intertwiners: C R_{e_8}|_Q and C R_{e_12}|_Q from the L-copy to the R-copy (singlet block); conjugation C from the L-copy to the Rbar-copy (all of S)", ok_int)

# ---------------------------------------------------------------- C17 the doublings: multiplicity pattern and the product's breaking of the doublet
log("\nC17. Multiplicity pattern on A_7; the doublet su(2) is not a derivation of A_5 (Section 13)")
A7 = Alg(7)
X7 = A7.L(np.concatenate([Sd.e(4), np.zeros(112, dtype=np.int64)]))
pat = []
for i in range(8):
    blk = X7[16 * i:16 * i + 16, 16 * i:16 * i + 16]
    pat.append("L" if np.array_equal(blk, Sd.L(Sd.e(4))) else "R" if np.array_equal(blk, Sd.R(Sd.e(4))) else "Rbar" if np.array_equal(blk, Sd.R(Sd.conj(Sd.e(4)))) else "?")
check(f"A_7 native action: copy types {pat} -> L:1, R:4, Rbar:3, so the two coloured classes {{L,Rbar}}, {{R}} each have multiplicity 4 = 2^(7-5)", pat == ["L", "R", "R", "Rbar", "R", "Rbar", "Rbar", "R"])
Zr = np.zeros((16, 16), dtype=np.int64)
T1 = Cj @ R8 @ PQ; T2 = Cj @ R12 @ PQ
M1 = np.block([[Zr, -T1.T], [T1, Zr]]); M2 = np.block([[Zr, -T2.T], [T2, Zr]]); M3 = comm(M1, M2)
tauh5 = np.kron(np.eye(2, dtype=np.int64), tau)
l4, l8, l12 = A5.L(A5.e(4)), A5.L(A5.e(8)), A5.L(A5.e(12))
six5 = [l8 @ l12, l4 @ l8, l4 @ l12, tauh5 @ l8, tauh5 @ l12, tauh5 @ l4 @ l8 @ l12]
colour5 = [np.kron(np.eye(2, dtype=np.int64), D) for D in colour]
check("on A_5 the mixing operators M1 = [[0,-T1^T],[T1,0]], M2 (T1 = C R_8 P_Q, T2 = C R_12 P_Q) and [M1,M2] span a 3-dimensional Lie algebra commuting with the native so(1,3)_Q + colour (the doublet su(2))",
      all(is_zero(comm(M, Zq)) for M in (M1, M2, M3) for Zq in six5 + colour5) and exact_rank(np.array([vecmat(X) for X in (M1, M2, M3)])) == 3
      and exact_rank(np.array([vecmat(X) for X in (M1, M2, M3, comm(M1, M3), comm(M2, M3))])) == 3)
E5 = [A5.e(i) for i in range(32)]
defect = sum(1 for i in range(32) for j in range(32) if not is_zero(M1 @ A5.mul(E5[i], E5[j]) - A5.mul(M1 @ E5[i], E5[j]) - A5.mul(E5[i], M1 @ E5[j])))
check(f"the doublet generators are not derivations of A_5: the Leibniz defect of M1 is nonzero on {defect} of the 1024 basis pairs (the doubling's product breaks the doublet)", defect > 0)
Mfix = np.vstack([np.array([[(D @ Sd.e(8 + k))[8 + j] for k in range(8)] for j in range(8)]) for D in colour])
check("the colour-fixed subspace of the odd index space is exactly span{Gamma_0, Gamma_4}; its complement W is canonical and so(6)_c is the bivector algebra of W", 8 - exact_rank(Mfix) == 2)

# ---------------------------------------------------------------- C18 box-kites, quaternion types, graded Malcev survival, domain-wall kinematics
log("\nC18. Box-kites (Theorem 2.8), quaternion subalgebras (2.9), tau-graded Malcev survival (4.4(iii)), K_1 triplets (7.8)")
Eb = [Sd.e(i) for i in range(16)]
def br(x, y): return Sd.mul(x, y) - Sd.mul(y, x)
def Jac(x, y, z): return br(br(x, y), z) + br(br(y, z), x) + br(br(z, x), y)
def mdef(x, y, z): return Jac(x, y, br(x, z)) - br(Jac(x, y, x * 0 + z), x)
def malcev_bad(xset, yset, zset):
    bad = 0
    for (a, b) in itertools.combinations_with_replacement(xset, 2):
        x = Eb[a] + (Eb[b] if b != a else 0 * Eb[b])
        for yy in yset:
            for zz in zset:
                if not is_zero(mdef(x, Eb[yy], Eb[zz])): bad += 1
    return bad
ImO = list(range(1, 8)); Odd = list(range(8, 16)); ImS = list(range(1, 16))
mix = sum(1 for a in ImO for b in Odd for yy in ImO for zz in ImS if not is_zero(mdef(Eb[a] + Eb[b], Eb[yy], Eb[zz])))
check(f"tau-graded Malcev survival: defects for tau-even x {malcev_bad(ImO, ImO, ImS)}, tau-odd x {malcev_bad(Odd, ImO, ImS)} (y in Im O, all z); inhomogeneous x gives {mix} defects; y in Im S gives {malcev_bad(ImO, ImS, ImS)}",
      malcev_bad(ImO, ImO, ImS) == 0 and malcev_bad(Odd, ImO, ImS) == 0 and mix > 0 and malcev_bad(ImO, ImS, ImS) > 0)
Fx, Ng = [1, 2, 3, 8, 9, 10, 11], [4, 5, 6, 7, 12, 13, 14, 15]
Fx2, Ng2 = [1, 2, 3, 12, 13, 14, 15], [4, 5, 6, 7, 8, 9, 10, 11]
check(f"the analogous survival fails for the twin grading ({malcev_bad(Fx, Fx, ImS)}, {malcev_bad(Ng, Fx, ImS)} defects) and for the S_8 grading ({malcev_bad(Fx2, Fx2, ImS)}, {malcev_bad(Ng2, Fx2, ImS)}): Malcev survival characterises the tau-kind",
      malcev_bad(Fx, Fx, ImS) > 0 and malcev_bad(Ng, Fx, ImS) > 0 and malcev_bad(Fx2, Fx2, ImS) > 0 and malcev_bad(Ng2, Fx2, ImS) > 0)
lines = {}
for i in range(1, 8):
    for j in range(i + 1, 8):
        k = int(np.nonzero(Sd.mul(Eb[i], Eb[j]))[0][0]); lines.setdefault(k, set()).add((i, j))
zdl = [(i, j, sg) for i in range(1, 8) for j in range(9, 16) if j - 8 != i for sg in (1, -1)]
vec = lambda t: Eb[t[0]] + t[2] * Eb[t[1]]
assessors = sorted(set((i, j) for i, j, sg in zdl))
adj = {A: set() for A in assessors}
leftann = {a: 0 for a in zdl}
for a in zdl:
    for b in zdl:
        if is_zero(Sd.mul(vec(a), vec(b))):
            leftann[a] += 1
            if (a[0], a[1]) != (b[0], b[1]): adj[(a[0], a[1])].add((b[0], b[1])); adj[(b[0], b[1])].add((a[0], a[1]))
seen = set(); kites = []
for A in assessors:
    if A in seen: continue
    st = [A]; c = set()
    while st:
        u = st.pop()
        if u in c: continue
        c.add(u); st.extend(adj[u] - c)
    seen |= c; kites.append(sorted(c))
okk = len(kites) == 7 and all(len(c) == 6 for c in kites) and all(len(adj[A]) == 4 for A in assessors) and set(leftann.values()) == {4}
labels = {}
for c in kites:
    k = [m for m in range(1, 8) if all(A[0] != m and A[1] - 8 != m for A in c)]
    struts = [(A, B) for A, B in itertools.combinations(c, 2) if B not in adj[A]]
    okk &= len(k) == 1 and len(struts) == 3 and {frozenset((A[0], A[1] - 8)) for A, B in struts} == {frozenset(p) for p in lines[k[0]]} and all(frozenset((A[0], A[1] - 8)) == frozenset((B[1] - 8, B[0])) for A, B in struts)
    labels[k[0]] = c
check("box-kites: the 84 two-term zero divisors e_i +- e_{8+j} (i != j) lie in 42 assessor planes; each annihilates exactly 4 others; the annihilation graph is 7 octahedra K_k, k a point of the basis Fano plane, whose 3 struts are the Fano lines through k", okk)
phi = np.diag([1, 1, 1, 1, -1, -1, -1, -1] * 2).astype(np.int64)
def flips(g, subset=None):
    f = 0
    for a in zdl:
        if subset is not None and (a[0], a[1]) not in subset: continue
        v = g @ vec(a); t = vec((a[0], a[1], -a[2]))
        if np.array_equal(v, t) or np.array_equal(v, -t): f += 1
    return f
even = [k for k in labels if flips(phi, set(labels[k])) == 0]; odd_ = [k for k in labels if flips(phi, set(labels[k])) == 12]
check(f"orientation bits: tau flips all {flips(tau)} diagonals; the twin involution phi (fixing <1,e1,e2,e3>, negating e4..e7) fixes every diagonal of the kites K_1,K_2,K_3 = {sorted(even)} and flips every diagonal of K_4..K_7 = {sorted(odd_)}; tau phi flips {flips(tau @ phi)}",
      flips(tau) == 84 and sorted(even) == [1, 2, 3] and sorted(odd_) == [4, 5, 6, 7] and flips(tau @ phi) == 36)
okB2 = True
for (i, j) in assessors:
    k = int(np.nonzero(Sd.mul(Eb[i], Eb[j]))[0][0]); Hb = [Eb[0], Eb[i], Eb[j], Eb[k]]
    okB2 &= all(any(np.array_equal(Sd.mul(a, b), sg * h) for h in Hb for sg in (1, -1)) for a in Hb for b in Hb)
    okB2 &= exact_nullity(Sd.L(Eb[i] + Eb[j]))[0] == 4 and exact_nullity(Sd.L(Eb[k]))[0] == 0
check("each assessor spans with 1 and e_i e_{8+j} a quaternion subalgebra of the zero-divisor type (its diagonals are zero divisors, its third unit is not)", okB2)
check("K_1 = tau L_8 splits Qperp into +1 and -1 eigenspaces of dimension 6 and 6, colour-invariant, exchanged by tau (and Q into 2 + 2)",
      exact_rank((I16 + K1) @ PQc) == 6 and exact_rank((I16 - K1) @ PQc) == 6 and exact_rank((I16 + K1) @ PQ) == 2 and all(is_zero(comm(D, K1)) for D in colour) and np.array_equal(tau @ K1 @ tau, -K1))

# ---------------------------------------------------------------- C19 graded contractions; the 1+3+3 frame; B1/B2 quaternion bifurcation
log("\nC19. Graded contractions of Im O and Im S; the (H, l) frame of O; B1/B2 quaternion subalgebras (2.9, 4.7)")
EO = [O.e(i) for i in range(8)]
def brO(x, y): return O.mul(x, y) - O.mul(y, x)
def brS(x, y): return Sd.mul(x, y) - Sd.mul(y, x)
def contracted(brf, Pe, d):
    Po = np.eye(d, dtype=np.int64) - Pe
    return lambda x, y: brf(Pe @ x, Pe @ y) + brf(Pe @ x, Po @ y) + brf(Po @ x, Pe @ y)
def mdefs(cbr, Ev, rng):
    def Jf(x, y, z): return cbr(cbr(x, y), z) + cbr(cbr(y, z), x) + cbr(cbr(z, x), y)
    bad = 0
    for (a, b) in itertools.combinations_with_replacement(list(rng), 2):
        x = Ev[a] + (Ev[b] if b != a else 0 * Ev[b])
        for yy in rng:
            for zz in rng:
                if not is_zero(Jf(x, Ev[yy], cbr(x, Ev[zz])) - cbr(Jf(x, Ev[yy], Ev[zz]), x)): bad += 1
    return bad
PeO = np.diag([1, 1, 1, 1, 0, 0, 0, 0]).astype(np.int64)
dO0 = mdefs(brO, EO, range(1, 8)); dO1 = mdefs(contracted(brO, PeO, 8), EO, range(1, 8))
check(f"Im O is Malcev ({dO0} defects) and its contraction along the quaternion grading (kill [odd,odd]) is Malcev ({dO1} defects)", dO0 == 0 and dO1 == 0)
gr = {"tau": [0, 1, 2, 3, 4, 5, 6, 7], "twin": [0, 1, 2, 3, 8, 9, 10, 11], "S8": [0, 1, 2, 3, 12, 13, 14, 15]}
dS = {k: mdefs(contracted(brS, np.diag([1 if i in v else 0 for i in range(16)]).astype(np.int64), 16), Eb, range(1, 16)) for k, v in gr.items()}
check(f"Im S is not Malcev ({mdefs(brS, Eb, range(1,16))} defects) and its contraction along each split kind is not Malcev either: {dS}", all(v > 0 for v in dS.values()))
Pset, Wset, Xset = [1, 2, 3], [4], [5, 6, 7]
def where(v):
    return "".join(sorted({"P" if i in Pset else "W" if i in Wset else "X" for i in np.nonzero(v)[0]})) or "0"
tab = {(A, B): set(where(brO(EO[i], EO[j])) for i in a for j in b if i != j) for A, a in [("P", Pset), ("W", Wset), ("X", Xset)] for B, b in [("P", Pset), ("W", Wset), ("X", Xset)]}
check(f"the (H, l) frame of Im O = P + W + X has bracket table [P,P] in P, [P,W] in X, [P,X] in W+X, [W,X] in P, [X,X] in P: {dict((k, sorted(v)) for k, v in tab.items() if v)}",
      tab[("P", "P")] == {"P"} and tab[("P", "W")] == {"X"} and tab[("P", "X")] == {"W", "X"} and tab[("W", "X")] == {"P"} and tab[("X", "X")] == {"P"})
# B1/B2: quaternion subalgebras <1,(u,0),(0,w),(0,wu)>: alternative iff w in C_u
def alt_span(idx):
    vs = [Eb[i] for i in idx]
    return all(exact_nullity(Sd.L(x).T @ Sd.L(x) - Sd.norm2(x) * I16)[0] == 16 for x in [a + b for a, b in itertools.combinations(vs, 2)] + vs)
check("B1 <1,e_1,e_8,e_9> consists of alternative elements; B2 <1,e_1,e_10,e_11> does not (it is a quaternion subalgebra containing zero divisors)", alt_span([0, 1, 8, 9]) and not alt_span([0, 1, 10, 11]))
linesF = {}
for i in range(1, 8):
    for j in range(i + 1, 8):
        k = int(np.nonzero(Sd.mul(Eb[i], Eb[j]))[0][0])
        for a, bc in ((i, (j, k)), (j, (i, k)), (k, (i, j))): linesF.setdefault(a, set()).add(frozenset(bc))
def gen_sub(idx):
    S_ = set(idx) | {0}; ch = True
    while ch:
        ch = False
        for a in list(S_):
            for b in list(S_):
                k = int(np.nonzero(Sd.mul(Eb[a], Eb[b]))[0][0])
                if k not in S_: S_.add(k); ch = True
    return sorted(S_)
def internal_alt(idx):
    vs = [Eb[i] for i in idx]
    return all(is_zero(Sd.assoc(x, x, y)) for x in [a + b for a, b in itertools.combinations(vs, 2)] + vs for y in vs)
def cls(H):
    return sorted(("alt" if internal_alt(gen_sub(H + [min(L)])) else "zd") for L in linesF[1])
check(f"doubling along the three Fano lines through e_1: type A {cls([1,2,3])}, B1 {cls([1,8,9])} (three octonion subalgebras), B2 {cls([1,10,11])} (one octonion, two with zero divisors)",
      cls([1, 8, 9]) == ["alt", "alt", "alt"] and cls([1, 10, 11]) == ["alt", "zd", "zd"] and cls([1, 2, 3]) == ["alt", "alt", "alt"])

# ---------------------------------------------------------------- C20 so(6)_c as a centraliser; A_6 doublets broken; the presentation as a CAR algebra
log("\nC20. so(6)_c = centraliser of {A,K1,K2} in so(1,8); the A_6 doublets are broken by the product; the presentation is a CAR algebra (2.10, 6.12)")
A_op, K1_op, K2_op = L8 @ L12, tau @ L8, tau @ L12      # (the name A was reused as a loop variable in C18)
Msys = np.vstack([np.array([vecmat(comm(X, Zc)) for X in biv]).T for Zc in (A_op, K1_op, K2_op)])
nulc, vcs = exact_nullity(Msys)
cent = [sum(int(c) * X for c, X in zip(v, biv)) for v in vcs]
check(f"the centraliser of {{A, K1, K2}} in so(1,8) has dimension {nulc} and equals so(6)_c", nulc == 15 and exact_rank(np.array([vecmat(X) for X in cent + so6])) == 15)
E6b = [A6.e(i) for i in range(64)]
Zr = np.zeros((16, 16), dtype=np.int64)
def emb4(blocks): return np.block([[blocks.get((i, j), Zr) for j in range(4)] for i in range(4)])
JR = tau @ Sd.Rb[4]
Ma = emb4({(1, 2): -I16, (2, 1): I16}); Mb = emb4({(1, 2): JR, (2, 1): JR}); Na = emb4({(0, 3): -Cj.T, (3, 0): Cj})
def defect6(Mx): return sum(1 for i in range(64) for j in range(64) if not is_zero(Mx @ A6.mul(E6b[i], E6b[j]) - A6.mul(Mx @ E6b[i], E6b[j]) - A6.mul(E6b[i], Mx @ E6b[j])))
d1, d2, d3 = defect6(Ma), defect6(Mb), defect6(Na)
check(f"on A_6 the coloured doublet generators are not derivations of the product: Leibniz defects {d1}, {d2} ({{R,R}} class) and {d3} ({{L,Rbar}} class) of 4096 basis pairs", d1 > 0 and d2 > 0 and d3 > 0)
check("the even system is a CAR algebra: {L_i, L_j} = -2 delta_ij, so gamma_i = i L_i (i = 1..8) are eight Majorana operators; S (x) C = C^16 = 2^4 is the Fock space of four modes",
      all(np.array_equal(acomm(gens[i], gens[j]), -2 * (i == j) * I16) for i in range(8) for j in range(8)))
pairs = [(8, 4), (1, 5), (2, 6), (3, 7)]
Nk = [Sd.Lb[a] @ Sd.Lb[b] for a, b in pairs]
check("the mediator pairs the eight Majoranas as (e_8,e_4),(e_1,e_5),(e_2,e_6),(e_3,e_7); the four number bivectors L_a L_b commute pairwise and square to -1",
      all(is_zero(comm(X, Y)) for X in Nk for Y in Nk) and all(np.array_equal(X @ X, -I16) for X in Nk))
nulv, vsv = exact_nullity(np.vstack([Nk[k] - Nk[0] for k in range(1, 4)]))
xv = vsv[0]; yv = Nk[0] @ xv
vac_ok = nulv == 2 and (np.array_equal(np.abs(xv), (Sd.e(0) + Sd.e(8))) or np.array_equal(np.abs(yv), (Sd.e(0) + Sd.e(8))))
check(f"the joint eigenline of the four number bivectors (the Fock vacuum of the presentation) is the real plane spanned by {xv.tolist()} and {yv.tolist()}, i.e. (1 - e_8) C_{{e_4}}, inside Q",
      vac_ok and is_zero(PQc @ xv) and is_zero(PQc @ yv))
check("tau carries the vacuum plane (1 - e_8) C_{e_4} to (1 + e_8) C_{e_4}", np.array_equal(np.abs(tau @ xv), Sd.e(0) + Sd.e(8)) and int((tau @ xv)[0] * (tau @ xv)[8]) > 0)

# ---------------------------------------------------------------- C21 the Majorana pairing is forced by colour on the generator space (Theorem 6.12, operator form)
log("\nC21. The pairing of the even Clifford generators is the colour-commuting complex structure on V_E (Theorem 6.12)")
def coordsVE(X):
    c = [int(np.sum(X * Lj)) for Lj in gens]
    assert all(v % 16 == 0 for v in c) and np.array_equal(sum((v // 16) * Lj for v, Lj in zip(c, gens)), X)
    return np.array([v // 16 for v in c], dtype=np.int64)
adVE = []
for D in colour:
    Mm = np.zeros((8, 8), dtype=np.int64)
    for j, Lj in enumerate(gens): Mm[:, j] = coordsVE(comm(D, Lj))
    adVE.append(Mm)
check("colour acts on V_E = span{L_1..L_8} by commutators, fixing exactly the plane span{L_4, L_8}",
      8 - exact_rank(np.vstack(adVE)) == 2 and all(is_zero(Mm[:, [3, 7]]) for Mm in adVE))
rowsVE = np.vstack([np.kron(np.eye(8, dtype=np.int64), Mm) - np.kron(Mm.T, np.eye(8, dtype=np.int64)) for Mm in adVE])
nulVE, vecsVE = exact_nullity(rowsVE)
Widx = [0, 1, 2, 4, 5, 6]
cw = [v.reshape(8, 8)[np.ix_(Widx, Widx)] for v in vecsVE]
JW8 = np.zeros((8, 8), dtype=np.int64)
for j in range(8):
    if j + 1 in (4, 8): continue
    JW8[:, j] = coordsVE(Sd.L(Sd.mul(Sd.e(4), Sd.e(j + 1))))
JWw = JW8[np.ix_(Widx, Widx)]
check(f"the commutant of colour in End(V_E) has dimension {nulVE} = 4 (fixed plane) + 2 (W_E); on W_E it is span{{1, J_W}} with J_W = (L_x -> L_{{e_4 x}}), so the colour-commuting complex structures on W_E are exactly +- J_W (Schur)",
      nulVE == 6 and exact_rank(np.array([vecmat(X) for X in cw])) == 2 and np.array_equal(JWw @ JWw, -np.eye(6, dtype=np.int64)) and exact_rank(np.array([vecmat(X) for X in cw + [JWw]])) == 2)
J8 = JW8.copy(); J8[7, 3] = 1; J8[3, 7] = -1
Nv = [Sd.Lb[1] @ Sd.Lb[5], Sd.Lb[2] @ Sd.Lb[6], Sd.Lb[3] @ Sd.Lb[7], Sd.Lb[8] @ Sd.Lb[4]]
_, vsv2 = exact_nullity(np.vstack([Nv[k] - Nv[0] for k in range(1, 4)]))
xv2 = vsv2[0]; yv2 = -(Nv[0] @ xv2)
okvac = True
for j in range(8):
    v = gens[j]; Jv = sum(J8[k, j] * gens[k] for k in range(8))
    okvac &= is_zero(v @ xv2 - Jv @ yv2) and is_zero(v @ yv2 + Jv @ xv2)
check("with J = J_W on W_E and the 90-degree rotation on span{L_4, L_8}, the basis-free vacuum condition (L_v + i L_{Jv}) Omega = 0 for all v in V_E has the solution Omega = x + i y with real plane (1 - e_8) C_{e_4} subset Q",
      okvac and np.array_equal(np.abs(xv2), Sd.e(0) + Sd.e(8)) and is_zero(PQc @ xv2) and is_zero(PQc @ yv2))
planes = set()
for sW in (1, -1):
    for s48 in (1, -1):
        Nn = [sW * Sd.Lb[a] @ Sd.Lb[b] for a, b in [(1, 5), (2, 6), (3, 7)]] + [s48 * Sd.Lb[8] @ Sd.Lb[4]]
        _, vv = exact_nullity(np.vstack([Nn[k] - Nn[0] for k in range(1, 4)]))
        xx = vv[0]; planes.add(int(xx[0] * xx[8]))
check("the four sign choices of J give exactly the two planes (1 - e_8) C_{e_4} and (1 + e_8) C_{e_4}, exchanged by tau", planes == {1, -1})

# ---------------------------------------------------------------- C22 the canonical squeeze and the failure disk; the Koopman carrier (Theorem 7.9)
log("\nC22. K_1 = tau L_8 on the seam and the background disk; unimodularity of so(1,3)_Q (Theorem 7.9)")
from fractions import Fraction as _F
K1_op, K2_op, K3_op = tau @ L8, tau @ L12, tau @ L4 @ L8 @ L12
six_ops = [L8 @ L12, L4 @ L8, L4 @ L12, K1_op, K2_op, K3_op]
check("the six generators of so(1,3)_Q are traceless: the group they generate is unimodular on S, so its pullback action on L^2(S) is unitary", all(int(np.trace(X)) == 0 for X in six_ops))
check("K_1 commutes with every derivation lift (D e_8 = 0, [D, tau] = 0): it is canonical given the world alone", all(is_zero(comm(K1_op, D)) for D in DerS))
zdl2 = [Sd.e(i) + sg * Sd.e(j) for i in range(1, 8) for j in range(9, 16) if j - 8 != i for sg in (1, -1)]
def is_zd(x): return exact_nullity(Sd.L(x))[0] > 0
uu = np.array([0, 2, -1, 3, 0, 1, 0, 0]); ww = np.array([0, 1, 2, 0, 1, -1, 0, 2])
check("K_1 acts on the doubly-pure subspace as the swap (u,w) -> (w,u), preserving it and mapping the seam to itself (all 84 two-term zero divisors)",
      np.array_equal(K1_op @ np.concatenate([uu, ww]), np.concatenate([ww, uu])) and all(is_zd(K1_op @ z) for z in zdl2)
      and all(int((K1_op @ Sd.e(i))[0]) == 0 and int((K1_op @ Sd.e(i))[8]) == 0 for i in range(1, 16) if i != 8))
def fi2(x):
    u_, w_ = x[:8].copy(), x[8:].copy(); u_[0] = 0; w_[0] = 0
    N_ = int(x @ x); return _F(4 * (int(u_ @ u_) * int(w_ @ w_) - int(u_ @ w_) ** 2), N_ * N_)
okflow = True
for (c, sg) in ((5, 3), (13, 5), (17, 15)):
    for z in zdl2[:30]:
        okflow &= fi2(c * z + sg * (K1_op @ z)) == _F((c * c - sg * sg) ** 2, (c * c + sg * sg) ** 2)
check("along e^{tK_1} every seam point acquires failure index beta/N = 1/cosh(2t), i.e. |Q| = tanh(2t) in the background disk (30 seam points, cosh t = 5/4, 13/12, 17/8)", okflow)
z0 = Sd.e(1) + Sd.e(10); z1 = Sd.e(4) + Sd.e(9)
check("mediator-dependent boosts differ: K_2 maps the mediator-orthogonal seam point e_1+e_10 along the seam (failure index stays 1) but carries the mediator-aligned seam point e_4+e_9 out of the doubly-pure subspace; K_3 moves e_1+e_10 radially like K_1",
      fi2(5 * z0 + 3 * (K2_op @ z0)) == 1 and int((K2_op @ z1)[8]) != 0 and fi2(5 * z0 + 3 * (K3_op @ z0)) == _F(64, 289) and not all(is_zd(K2_op @ z) for z in zdl2))

# ---------------------------------------------------------------- C23 twisted group algebra and the Z_2 cocycle; R-flux contractions of Im O and Im S
log("\nC23. S as a twisted group algebra of Z_2^4 with a {+-1}-valued associator cocycle (1.7); R-flux contractions (4.7 revised)")
check("Cayley-Dickson basis of S: e_i e_j = F(i,j) e_{i XOR j} for all i, j (so S = R_F[Z_2^4])", all(int(Sd.K[i, j]) == (i ^ j) for i in range(16) for j in range(16)))
Fm = np.array([[int(Sd.S[i, j]) for j in range(16)] for i in range(16)])
phi = {(a, b, c): Fm[a, b] * Fm[a ^ b, c] * Fm[b, c] * Fm[a, b ^ c] for a in range(16) for b in range(16) for c in range(16)}
coc = all(phi[(b, c, d)] * phi[(a, b ^ c, d)] * phi[(a, b, c)] == phi[(a ^ b, c, d)] * phi[(a, b, c ^ d)] for a in range(16) for b in range(16) for c in range(16) for d in range(16))
check(f"the associator sign phi = dF is a {{+-1}}-valued 3-cocycle on Z_2^4 (identity on all 65536 quadruples); phi = -1 on {sum(1 for v in phi.values() if v == -1)} of 4096 basis triples (168 of 512 for O)", coc and sum(1 for v in phi.values() if v == -1) == 1848)
# R-flux contraction of Im O (weights X:1, P:2, W:3)
def comm_table(alg, n):
    tab = {}
    for a in range(1, n):
        for b in range(1, n):
            if a == b: continue
            c = int(alg.K[a, b]); coef = int(alg.S[a, b]) - (int(alg.S[b, a]) if alg.K[b, a] == c else 0)
            if coef: tab[(a, b)] = (c, coef)
    return tab
def contract(tab, w):
    out = {}
    for (a, b), (c, coef) in tab.items():
        d = w[a] + w[b] - w[c]
        if d < 0: return None
        if d == 0: out[(a, b)] = (c, coef)
    return out
def malcev_defects_tab(tab, n, Ev):
    def cbr(v1, v2):
        o = np.zeros(n, dtype=np.int64)
        for a in np.nonzero(v1)[0]:
            for b in np.nonzero(v2)[0]:
                if (a, b) in tab:
                    c, coef = tab[(a, b)]; o[c] += v1[a] * v2[b] * coef
        return o
    def Jf(x, y, z): return cbr(cbr(x, y), z) + cbr(cbr(y, z), x) + cbr(cbr(z, x), y)
    bad = 0
    for (a, b) in itertools.combinations_with_replacement(range(1, n), 2):
        x = Ev[a] + (Ev[b] if b != a else 0 * Ev[b])
        for yy in range(1, n):
            for zz in range(1, n):
                if not is_zero(Jf(x, Ev[yy], cbr(x, Ev[zz])) - cbr(Jf(x, Ev[yy], Ev[zz]), x)): bad += 1
    return bad, cbr
tabO = comm_table(O, 8); wO = {1: 2, 2: 2, 3: 2, 4: 3, 5: 1, 6: 1, 7: 1}
cO = contract(tabO, wO); EO2 = [O.e(i) for i in range(8)]
dO, cbrO = malcev_defects_tab(cO, 8, EO2)
Jx = cbrO(cbrO(EO2[5], EO2[6]), EO2[7]) + cbrO(cbrO(EO2[6], EO2[7]), EO2[5]) + cbrO(cbrO(EO2[7], EO2[5]), EO2[6])
check(f"1+3+3 filtration contraction of Im O with weights X:1, P:2, W:3 exists, is Malcev ({dO} defects), has [x,x] in P, [x,p] = 2 delta I, [p,p] = 0, I central, and Jacobiator [x1,x2,x3] = {Jx.tolist()} = 12 I (the R-flux / monopole algebra)",
      cO is not None and dO == 0 and np.array_equal(Jx, 12 * EO2[4]) and all(c in (1, 2, 3) for (a, b), (c, k) in cO.items() if a in (5, 6, 7) and b in (5, 6, 7)) and not any((a, b) in cO for a in (1, 2, 3) for b in (1, 2, 3)))
tabS = comm_table(Sd, 16)
wS = {1: 2, 2: 2, 3: 2, 4: 3, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1, 10: 1, 11: 1, 12: 2, 13: 2, 14: 2, 15: 2}
cS = contract(tabS, wS); dS_, cbrS = malcev_defects_tab(cS, 16, Eb)
V1 = [5, 6, 7, 8, 9, 10, 11]; V2 = [1, 2, 3, 12, 13, 14, 15]
fl = {}
for a, b, c in itertools.combinations(V1, 3):
    Jv = cbrS(cbrS(Eb[a], Eb[b]), Eb[c]) + cbrS(cbrS(Eb[b], Eb[c]), Eb[a]) + cbrS(cbrS(Eb[c], Eb[a]), Eb[b])
    if np.any(Jv): fl[(a, b, c)] = int(Jv[4])
check(f"Im S admits a Malcev filtration contraction extending it (weights e_8:1, P':1, W':2, X':2): {len(cS)} surviving brackets, {dS_} Malcev defects; shape V1 (7 coordinates) + V2 (7 momenta) + R e_4 (central), seven Heisenberg pairs, flux 3-form on the 7 lines of a Fano plane with components {sorted(set(abs(v) for v in fl.values()))}",
      cS is not None and dS_ == 0 and len(fl) == 7 and sorted(set(abs(v) for v in fl.values())) == [4, 12]
      and all(cS[(a, b)][0] in V2 for a in V1 for b in V1 if (a, b) in cS) and all(cS[(a, b)][0] == 4 for a in V1 for b in V2 if (a, b) in cS) and not any((a, b) in cS for a in V2 for b in V2))

# ---------------------------------------------------------------- C24 classification of contractions of Im O; the centre of S
log("\nC24. Contractions of Im O up to Fano collineations (4.7(vi)); the centre of S")
ccO = {}
for a in range(1, 8):
    for b in range(1, 8):
        if a == b: continue
        c = int(O.K[a, b]); coef = int(O.S[a, b]) - (int(O.S[b, a]) if O.K[b, a] == c else 0)
        if coef: ccO[(a, b)] = (c, coef)
linesO = set(frozenset((a, b, c)) for (a, b), (c, coef) in ccO.items())
Gcol = [pp for pp in itertools.permutations(range(1, 8)) if all(frozenset(pp[i - 1] for i in l) in linesO for l in linesO)]
def contr(w):
    sv = {}
    for (a, b), (c, coef) in ccO.items():
        d = w[a - 1] + w[b - 1] - w[c - 1]
        if d < 0: return None
        if d == 0: sv[(a, b)] = (c, coef)
    return sv
def njac(sv):
    def brf(v1, v2):
        o = np.zeros(8, dtype=np.int64)
        for a in np.nonzero(v1)[0]:
            for b in np.nonzero(v2)[0]:
                if (a, b) in sv:
                    c, coef = sv[(a, b)]; o[c] += v1[a] * v2[b] * coef
        return o
    return sum(1 for a, b, c in itertools.combinations(range(1, 8), 3) if not is_zero(brf(brf(EO[a], EO[b]), EO[c]) + brf(brf(EO[b], EO[c]), EO[a]) + brf(brf(EO[c], EO[a]), EO[b])))
def canonO(sv):
    edges = frozenset((a, b, sv[(a, b)][0]) for (a, b) in sv); best = None
    for pp in Gcol:
        key = tuple(sorted(frozenset((pp[a - 1], pp[b - 1], pp[c - 1]) for (a, b, c) in edges)))
        if best is None or key < best: best = key
    return best
orbs_pos = {}; orbs_all = {}
for w in itertools.product(range(0, 7), repeat=7):
    sv = contr(w)
    if not sv: continue
    k = canonO(sv)
    if k not in orbs_all: orbs_all[k] = njac(sv)
    if min(w) >= 1 and k not in orbs_pos: orbs_pos[k] = njac(sv)
nl_pos = [k for k, v in orbs_pos.items() if v > 0]; nl_all = [k for k, v in orbs_all.items() if v > 0]
check(f"contractions of Im O with weights in {{0..6}}: {len(orbs_all)} orbits of nonzero limits, {len(nl_all)} non-Lie (the trivial one, the su(2)-fixed one, a u(1)-fixed one, and R-flux); with strictly positive weights: {len(orbs_pos)} orbits, exactly {len(nl_pos)} non-Lie (R-flux)",
      len(collinears := Gcol) == 168 and len(nl_all) == 4 and len(nl_pos) == 1)
svR = contr((2, 2, 2, 3, 1, 1, 1))
def brR(v1, v2):
    o = np.zeros(8, dtype=np.int64)
    for a in np.nonzero(v1)[0]:
        for b in np.nonzero(v2)[0]:
            if (a, b) in svR:
                c, coef = svR[(a, b)]; o[c] += v1[a] * v2[b] * coef
    return o
xp = brR(EO[5], EO[1]); Jr = brR(brR(EO[5], EO[6]), EO[7]) + brR(brR(EO[6], EO[7]), EO[5]) + brR(brR(EO[7], EO[5]), EO[6])
check(f"locked ratio in the R-flux limit: [x_1,p_1] = {int(xp[4])} W and [x_1,x_2,x_3] = {int(Jr[4])} W, ratio {int(Jr[4]) // int(xp[4])}", int(Jr[4]) == 6 * int(xp[4]))
# centre of S: elements commuting with all basis units
Zc = np.vstack([Sd.Lb[i] - Sd.Rb[i] for i in range(16)])
nz, _ = exact_nullity(Zc)
check(f"the centre of S has dimension {nz}: it is R 1 (the unit is the only central element)", nz == 1)

# ---------------------------------------------------------------- C25 seam bundle holonomy; hypercharge on R-copies; the involution separating the doublet classes
log("\nC25. The seam bundle's canonical connection; Y on the R-copies; tau_16 tau_32 on A_6 (Section 11.7, 13.7)")
Bg2 = Matrix([vecmat(b).tolist() for b in basisD]).T
def coords_g2(X):
    sol = Bg2.solve_least_squares(Matrix(vecmat(X).tolist())); assert (Bg2 * sol - Matrix(vecmat(X).tolist())).is_zero_matrix; return sol
Mh = np.array([np.concatenate([D @ O.e(1), D @ O.e(2)]) for D in basisD]).T
hq = []
for v in Matrix(Mh.tolist()).nullspace():
    co = [nsimplify(c) for c in v]; den = 1
    for c in co: den = np.lcm(den, int(c.q))
    hq.append(sum(int(c * den) * D for c, D in zip(co, basisD)))
GramG = Matrix([[int(np.trace(X @ Y)) for Y in basisD] for X in basisD])
Hc = Matrix([[c for c in coords_g2(X)] for X in hq])
mq = []
for v in (Hc * GramG).nullspace():
    co = [nsimplify(c) for c in v]; den = 1
    for c in co: den = np.lcm(den, int(c.q))
    mq.append(sum(int(c * den) * D for c, D in zip(co, basisD)))
Bhm = Matrix([[c for c in coords_g2(Z)] for Z in hq + mq]).T
def proj_h(X): return Bhm.solve(coords_g2(X))[:len(hq), :]
check(f"g_2 = su(2)_q + m is reductive (dim {len(hq)} + {len(mq)}); the curvature values [m,m]_h of the canonical connection on G_2 -> G_2/SU(2)_q span su(2)_q (rank {Matrix.hstack(*[proj_h(comm(X, Y)) for X, Y in itertools.combinations(mq, 2)]).rank()}): full holonomy",
      len(hq) == 3 and len(mq) == 11 and all(proj_h(comm(H_, M_)).is_zero_matrix for H_ in hq for M_ in mq) and Matrix.hstack(*[proj_h(comm(X, Y)) for X, Y in itertools.combinations(mq, 2)]).rank() == 3)
YR = Sd.Rb[9] @ Sd.Rb[13] + Sd.Rb[10] @ Sd.Rb[14] + Sd.Rb[11] @ Sd.Rb[15]
AR, BR, CR = Sd.Rb[8] @ Sd.Rb[12], Sd.Rb[4] @ Sd.Rb[8], Sd.Rb[4] @ Sd.Rb[12]
check("on the R-type copies the hypercharge is Y_R = C Y_L C (conjugation), with Y_R^2 = -9 on Q, -1 on Qperp, Y_R|_Q = -3 L_4, commuting with colour, with the R-copy rotations and with tau",
      np.array_equal(Cj @ Y @ Cj, YR) and np.array_equal(YR @ YR @ PQ, -9 * PQ) and np.array_equal(YR @ YR @ PQc, -PQc) and np.array_equal(YR @ PQ, -3 * L4 @ PQ)
      and all(is_zero(comm(YR, D)) for D in colour) and all(is_zero(comm(YR, X)) for X in (AR, BR, CR)) and is_zero(comm(YR, tau)))
t16 = np.kron(np.diag([1, -1, 1, -1]).astype(np.int64), I16); t32 = np.kron(np.diag([1, 1, -1, -1]).astype(np.int64), I16)
def is_aut6(g): return all(np.array_equal(g @ A6.mul(E6b[i], E6b[j]), A6.mul(g @ E6b[i], g @ E6b[j])) for i in range(64) for j in range(64))
check("tau_16, tau_32 and tau_16 tau_32 are automorphisms of A_6; tau_16 tau_32 is +1 on the coloured class {L,Rbar} (copies 0,3) and -1 on {R,R} (copies 1,2)",
      is_aut6(t16) and is_aut6(t32) and is_aut6(t16 @ t32) and np.array_equal(t16 @ t32, np.kron(np.diag([1, -1, -1, 1]).astype(np.int64), I16)))
I32 = np.eye(32, dtype=np.int64); tauh5 = np.kron(np.eye(2, dtype=np.int64), tau); t16_5 = np.kron(np.diag([1, -1]).astype(np.int64), I16)
Zr = np.zeros((16, 16), dtype=np.int64); T1 = Cj @ R8 @ PQ; M1 = np.block([[Zr, -T1.T], [T1, Zr]])
defs = []
for sig in (I32, tauh5, t16_5, tauh5 @ t16_5):
    defs.append(sum(1 for i in range(32) for j in range(32) if not is_zero(M1 @ A5.mul(E5[i], E5[j]) - A5.mul(M1 @ E5[i], E5[j]) - A5.mul(sig @ E5[i], M1 @ E5[j]))))
check(f"the doublet generator on A_5 is not a sigma-twisted derivation for sigma in {{1, tau^, tau_16, tau^ tau_16}}: defects {defs} of 1024", all(d > 0 for d in defs))

# ---------------------------------------------------------------- C26 the seam bundle: curvature support, quaternionic structure, Yang-Mills (Theorem 3.8)
log("\nC26. The seam bundle G_2 -> G_2/SU(2)_q: curvature on m', quaternionic structure, Yang-Mills (Theorem 3.8)")
ipg = lambda X, Y: -int(np.trace(X @ Y))
PH8 = np.zeros((8, 8), dtype=np.int64)
for i in (4, 5, 6, 7): PH8[i, i] = 1
def nullint_g2(Mx):
    out = []
    for v in Matrix(Mx.tolist()).nullspace():
        co = [nsimplify(c) for c in v]; den = 1
        for c in co: den = np.lcm(den, int(c.q))
        out.append(sum(int(c * den) * D for c, D in zip(co, basisD)))
    return out
so4 = nullint_g2(np.array([np.concatenate([PH8 @ (D @ O.e(i)) for i in (1, 2, 3)]) for D in basisD]).T)
GramG2 = Matrix([[ipg(X, Y) for Y in basisD] for X in basisD])
def perp_in(space, sub):
    Cc = Matrix([[c for c in coords_g2(X)] for X in space]).T; Cs = Matrix([[c for c in coords_g2(X)] for X in sub]).T
    out = []
    for v in (Cs.T * GramG2 * Cc).nullspace():
        c = Cc * v; co = [nsimplify(x) for x in c]; den = 1
        for x in co: den = np.lcm(den, int(x.q))
        out.append(sum(int(x * den) * D for x, D in zip(co, basisD)))
    return out
pq = perp_in(so4, hq); mp = perp_in(basisD, so4); mfull = pq + mp
Bfull = Matrix([[c for c in coords_g2(Z)] for Z in hq + mfull]).T
def dec(X): return Bfull.solve(coords_g2(X))
Om = lambda X, Y: -dec(comm(X, Y))[:3, :]
check("so(4) = su(2)_q + su(2)_p (3+3) and m = su(2)_p + m' (3+8); the curvature Omega = -[.,.]_h vanishes on su(2)_p x m and has rank 3 on Lambda^2 m'",
      len(so4) == 6 and len(pq) == 3 and len(mp) == 8 and all(Om(X, Y).is_zero_matrix for X in pq for Y in mfull) and Matrix.hstack(*[Om(X, Y) for X, Y in itertools.combinations(mp, 2)]).rank() == 3)
Bmp = Matrix([[c for c in coords_g2(X)] for X in mp]).T
def ad_mp(H):
    cols = []
    for X in mp:
        c = coords_g2(comm(H, X)); sol = Bmp.solve_least_squares(c); assert (Bmp * sol - c).is_zero_matrix; cols.append(sol)
    return Matrix.hstack(*cols)
ads = [ad_mp(H) for H in hq]
check("su(2)_q acts on m' by three anticommuting complex structures (up to scale) and trivially on su(2)_p: m' is quaternionic and the three components of Omega are its Kaehler forms <X, ad(h_a) Y>/|h_a|^2",
      all((M * M + (-(M * M)[0, 0]) * Matrix.eye(8)).is_zero_matrix and (M * M)[0, 0] < 0 for M in ads) and (ads[0] * ads[1] + ads[1] * ads[0]).is_zero_matrix
      and all(is_zero(comm(H, X)) for H in hq for X in pq) and all(ipg(comm(X, Y), H) == ipg(X, comm(Y, H)) for H in hq for X in mp for Y in mp))
Gm = Matrix([[ipg(X, Y) for Y in mfull] for X in mfull]); Ginv = Gm.inv()
def h_part_of_comm(Ei, innerM):
    cm = Matrix(Ei.tolist()) * innerM - innerM * Matrix(Ei.tolist())
    sol = Bg2.solve_least_squares(Matrix(cm.reshape(64, 1))); return Bfull.solve(sol)[:3, :]
ym = True
for X in mfull:
    T = zeros(3, 1)
    for i in range(11):
        for j in range(11):
            if Ginv[i, j] == 0: continue
            d = dec(comm(mfull[j], X)); inner = sum((d[3 + k] * Matrix(vecmat(mfull[k]).tolist()) for k in range(11)), zeros(64, 1))
            T += Ginv[i, j] * h_part_of_comm(mfull[i], Matrix(inner).reshape(8, 8))
    ym &= T.is_zero_matrix
check("the canonical connection is Yang-Mills for the normal metric: sum_ij g^ij [E_i,[E_j,X]_m]_h = 0 for all X in m", ym)

# ---------------------------------------------------------------- C27 the composition-constant induction (Theorem 5.6)
log("\nC27. Base case and recursion of the lifting quadruple (x,y,b,d) (Theorem 5.6)")
xq = np.zeros(16, dtype=np.int64); yq = np.zeros(16, dtype=np.int64); bq = np.zeros(16, dtype=np.int64); dq = np.zeros(16, dtype=np.int64)
xq[1] = 1; xq[10] = 1; yq[7] = -1; yq[12] = 1; bq[2] = 1; bq[9] = -1; dq[4] = 1; dq[15] = 1
n2 = lambda v: int(v @ v)
def invariants(Aq, x, y, b, d, c2):
    return (x[0] == y[0] == b[0] == d[0] == 0 and n2(x) == n2(b) and n2(y) == n2(d)
            and n2(Aq.mul(x, y)) == c2 * n2(x) * n2(y) and n2(Aq.mul(d, x)) == c2 * n2(d) * n2(x)
            and np.array_equal(Aq.mul(d, b), Aq.mul(x, y)) and np.array_equal(Aq.mul(b, y), -Aq.mul(d, x))
            and int(x @ d) == int(x @ y) == int(b @ y) == int(b @ d) == 0)
check("base case n = 4: x = e_1+e_10, y = -e_7+e_12, b = e_2-e_9, d = e_4+e_15 are pure, |x|=|b|, |y|=|d|, |xy|^2 = 2|x|^2|y|^2, |dx|^2 = 2|d|^2|x|^2, db = xy, by = -dx, and <x,d> = <x,y> = <b,y> = <b,d> = 0", invariants(Sd, xq, yq, bq, dq, 2))
c2q = 2; xr, yr, br, dr = xq, yq, bq, dq; okrec = True
for nlev in range(4, 8):
    Aq = {4: A5, 5: A6, 6: A7}[nlev] if nlev < 7 else Alg(8)
    xr, yr, br, dr = np.concatenate([-xr, br]), np.concatenate([-yr, dr]), np.concatenate([br, xr]), np.concatenate([dr, yr]); c2q *= 2
    okrec &= invariants(Aq, xr, yr, br, dr, c2q)
check("the recursion (x,y,b,d) -> ((-x,b),(-y,d),(b,x),(d,y)) preserves all invariants with c^2 doubled, verified through A_8 (the general step is proved algebraically in Theorem 5.6)", okrec)

log("\n" + "=" * 70)
log(f"failures: {failures}")
open("exact_checks.txt", "w").write("\n".join(out) + "\n")
