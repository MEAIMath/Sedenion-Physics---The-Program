"""c30_open_items.py -- exact verification of the finite claims closing two open
items of the deductive edition (1.36): the Lie closure of 13.7(iii), block C30,
and the dimension of the A_5 zero-divisor stratum of Section 11 item 8, block C31.

Protocol of Section 0.3.  Closures are found modulo p = 2^31 - 1 and then
certified over Q: an exact reduced echelon basis (sympy, rational arithmetic)
is computed for the generated span, and every pairwise bracket is verified to
lie in it by exact reduction; dimensions of centre and derived algebra are
certified two-sidedly (exhibited exact elements below, mod-p rank above).
Block C31 uses exact ranks over Q throughout.  No floating point occurs.
"""
import numpy as np, sympy, time
t0 = time.time()
P = 2**31 - 1

# ---------------------------------------------------------------- tables
def cd_double(idx, sgn, cs):
    D = len(idx)
    i2 = np.zeros((2*D, 2*D), dtype=np.int64); s2 = np.zeros((2*D, 2*D), dtype=np.int64)
    for i in range(2*D):
        for j in range(2*D):
            if i < D and j < D:   i2[i,j]=idx[i,j];        s2[i,j]=sgn[i,j]
            elif i < D <= j:      q=j-D; i2[i,j]=idx[q,i]+D; s2[i,j]=sgn[q,i]
            elif j < D <= i:      p_=i-D; i2[i,j]=idx[p_,j]+D; s2[i,j]=cs[j]*sgn[p_,j]
            else:                 p_,q=i-D,j-D; i2[i,j]=idx[q,p_]; s2[i,j]=-cs[q]*sgn[q,p_]
    return i2, s2
idx, sgn = np.zeros((1,1),dtype=np.int64), np.ones((1,1),dtype=np.int64)
tabs = [(idx,sgn)]
for n in range(1, 6):
    cs = np.array([1]+[-1]*(len(idx)-1), dtype=np.int64)
    idx, sgn = cd_double(idx, sgn, cs)
    tabs.append((idx,sgn))
IDX16,SGN16 = tabs[4]; IDX32,SGN32 = tabs[5]
def Lmat(x, idx, sgn):
    D=len(x); M=np.zeros((D,D),dtype=np.int64)
    for i in range(D):
        if x[i]:
            for j in range(D): M[idx[i,j],j] += x[i]*sgn[i,j]
    return M
def Rmat(x, idx, sgn):
    D=len(x); M=np.zeros((D,D),dtype=np.int64)
    for j in range(D):
        if x[j]:
            for i in range(D): M[idx[i,j],i] += x[j]*sgn[i,j]
    return M
def e(i,D):
    v=np.zeros(D,dtype=np.int64); v[i]=1; return v
comm = lambda a,b: a@b-b@a

def rank_modp(M):
    A = (np.array(M,dtype=np.int64)%P).copy(); rows,cols=A.shape; r=0
    for c in range(cols):
        pr = next((rr for rr in range(r,rows) if A[rr,c]%P), None)
        if pr is None: continue
        A[[r,pr]]=A[[pr,r]]; A[r]=(A[r]*pow(int(A[r,c]),P-2,P))%P
        for rr in range(rows):
            if rr!=r and A[rr,c]: A[rr]=(A[rr]-A[rr,c]*A[r])%P
        r+=1
        if r==rows: break
    return r

results=[]
def ok(flag,msg):
    results.append(flag); print(("  [ok]  " if flag else "  [FAIL]")+" "+msg)

# ---------------------------------------------------------------- generators
Cj = np.diag([1]+[-1]*15).astype(np.int64)
R8 = Rmat(e(8,16),IDX16,SGN16); R12 = Rmat(e(12,16),IDX16,SGN16)
PQ = np.zeros((16,16),dtype=np.int64)
for i in (0,4,8,12): PQ[i,i]=1
T1=Cj@R8@PQ; T2=Cj@R12@PQ; Z16=np.zeros((16,16),dtype=np.int64)
M1=np.block([[Z16,-T1.T],[T1,Z16]]); M2=np.block([[Z16,-T2.T],[T2,Z16]]); M3=comm(M1,M2)
L16=Lmat(e(16,32),IDX32,SGN32); R16=Rmat(e(16,32),IDX32,SGN32)
tau5=np.diag(([1]*8+[-1]*8)*2).astype(np.int64)
l=lambda i: Lmat(e(i,32),IDX32,SGN32)
six5=[l(8)@l(12), l(4)@l(8), l(4)@l(12), tau5@l(8), tau5@l(12), tau5@l(4)@l(8)@l(12)]
# colour: stabiliser of e_4 among diagonal derivation lifts (as in C5), exactly over Q
IDX8,SGN8 = tabs[3]
LO=[Lmat(e(i,8),IDX8,SGN8) for i in range(8)]; RO=[Rmat(e(i,8),IDX8,SGN8) for i in range(8)]
Ds=[(LO[a]@LO[b]-LO[b]@LO[a])+(LO[a]@RO[b]-RO[b]@LO[a])+(RO[a]@RO[b]-RO[b]@RO[a])
    for a in range(1,8) for b in range(a+1,8)]
sel=[]; acc=[]
for d in Ds:
    t=acc+[d.flatten()]
    if rank_modp(np.array(t))==len(t): acc=t; sel.append(d)
    if len(sel)==14: break
cols=sympy.Matrix([[int(sel[k][i,4]) for k in range(14)] for i in range(8)])
colour=[]
for v in cols.nullspace():
    den=sympy.lcm([sympy.fraction(x)[1] for x in v]); vi=[int(x*den) for x in v]
    D8=sum(vi[k]*sel[k] for k in range(14))
    D16=np.zeros((16,16),dtype=np.int64); D16[:8,:8]=D8; D16[8:,8:]=D8
    colour.append(np.kron(np.eye(2,dtype=np.int64),D16))

# ---------------------------------------------------------------- closure machinery
def closure_mats(gens):
    rows,mats=[],[]
    def add(m):
        v=(m.flatten()%P).astype(np.int64)
        for (pv,r) in rows:
            if v[pv]%P: v=(v-v[pv]*r)%P
        nz=np.nonzero(v)[0]
        if len(nz)==0: return False
        piv=int(nz[0]); v=(v*pow(int(v[piv]),P-2,P))%P
        for k,(pv,r) in enumerate(rows):
            if r[piv]%P: rows[k]=(pv,(r-r[piv]*v)%P)
        rows.append((piv,v)); mats.append(m); return True
    frontier=[g for g in gens if add(g)]
    while frontier:
        new=[]
        for g in gens:
            for b in frontier:
                c=comm(g,b)
                if c.any() and add(c): new.append(c)
        frontier=new
    return mats

def certify_closed(mats, extra=()):
    """exact Q-certificate: rank of mats over Q equals len(mats); every pairwise
    bracket and every extra reduces to zero against the exact echelon basis."""
    n=len(mats)
    Msy=sympy.Matrix([[int(x) for x in m.flatten()] for m in mats])
    rref,piv=Msy.rref()
    if len(piv)!=n: return False
    E=[rref[i,:] for i in range(n)]
    def member(v):
        w=sympy.Matrix([[int(x) for x in v.flatten()]])
        for i,c in enumerate(piv):
            if w[0,c]!=0: w=w-w[0,c]*E[i]
        return all(x==0 for x in w)
    return all(member(comm(mats[i],mats[j])) for i in range(n) for j in range(i+1,n)) \
       and all(member(x) for x in extra)

# ================================================================ C30
print("C30. The Lie closure of the doublet with the native mixing operators (13.7(iii))")
G=[M1,M2,M3,L16,R16]
B17=closure_mats(G)
ok(len(B17)==17 and certify_closed(B17,extra=G),
   "dim< doublet su(2), L_16, R_16 > = 17 exactly: Q-independent basis, all 136 brackets and the generators in the span (exact echelon reduction)")
ok(all((m.T==-m).all() for m in B17), "the closure consists of skew operators: a compact Lie algebra")
# centre exactly 2
Csys=sympy.Matrix([[int(comm(B17[i],B17[k]).flatten()[c]) for i in range(17)]
                   for k in range(17)
                   for c in np.nonzero(sum(np.abs(comm(B17[i],B17[k])) for i in range(17)).flatten())[0][:40]])
ns=Csys.nullspace()
Zs=[]
for v in ns:
    den=sympy.lcm([sympy.fraction(x)[1] for x in v]); vi=[int(x*den) for x in v]
    Zs.append(sum(vi[i]*B17[i] for i in range(17)))
ok(len(Zs)==2 and all(not comm(Zm,B).any() for Zm in Zs for B in B17),
   "centre of dimension exactly 2: two exact central elements exhibited; mod-p bound 2 from the commuting system")
# derived exactly 15, direct sum with centre
br=[comm(B17[i],B17[j]) for i in range(17) for j in range(i+1,17)]
selb=[]; accb=[]
for b in br:
    t=accb+[b.flatten()]
    if rank_modp(np.array(t))==len(t): accb=t; selb.append(b)
    if len(selb)==15: break
ok(len(selb)==15 and rank_modp(np.array([x.flatten() for x in selb]+[Zm.flatten() for Zm in Zs]))==17,
   "derived algebra of dimension exactly 15, and centre + derived = the whole algebra (direct sum)")
# rank 3: commuting triple below, centralizer bound above
triple=None
for a in range(15):
    for b in range(a+1,15):
        if not comm(selb[a],selb[b]).any():
            for c in range(b+1,15):
                if not comm(selb[a],selb[c]).any() and not comm(selb[b],selb[c]).any():
                    if rank_modp(np.array([selb[a].flatten(),selb[b].flatten(),selb[c].flatten()]))==3:
                        triple=(a,b,c); break
            if triple: break
    if triple: break
import random
random.seed(1)
X=sum(random.randint(-3,3)*b for b in selb)
cen=17-rank_modp(np.array([comm(B17[i],X).flatten() for i in range(17)]))
ok(triple is not None and cen==5,
   f"rank of the semisimple part = 3: an exact commuting independent triple in the derived algebra, and a generic centralizer of dimension {cen} = 2 + 3 [mod-p]")
print("        => the closure is u(1)^2 (+) su(4): compact, centre 2, semisimple part of dimension 15 and rank 3 (the unique such algebra)")
ok(rank_modp(np.array([m.flatten() for m in B17]+[six5[0].flatten()]))==18,
   "the rotation A = L_8 L_12 is not in the closure: it differs from the direct sum su(2) (+) (so(1,3)_Q (+) colour) of the same dimension 17")
B81=closure_mats(G+six5+colour)
ok(len(B81)==81 and certify_closed(B81,extra=G+six5+colour),
   "dim< doublet, L_16, R_16, native so(1,3)_Q + colour > = 81 exactly: all 3240 brackets and the generators in the span (exact)")

# ================================================================ C31
print("\nC31. The zero-divisor stratum of A_5 has dimension 24 > 14 = dim Aut(A_5) (Section 11, item 8)")
z1 = 2*e(1,32)+e(2,32)+e(5,32)-e(25,32)+2*e(26,32)+e(30,32)
Ms = sympy.Matrix(Lmat(z1,IDX32,SGN32).tolist())
ok(Ms.rank()==28, "witness z1 = 2e1+e2+e5-e25+2e26+e30 (norm^2 = 12): rank L_{z1} = 28 exactly, corank 4")
K = np.array([[int(x) for x in v] for v in Ms.nullspace()],dtype=np.int64).T
def transmat(zz):
    Msz=sympy.Matrix(Lmat(zz,IDX32,SGN32).tolist())
    Kb=np.array([[int(x) for x in v] for v in Msz.nullspace()],dtype=np.int64).T
    rows=[]
    for d in range(1,32):
        Q4=Kb.T@Lmat(e(d,32),IDX32,SGN32)@Kb
        rows.append([Q4[0,1],Q4[0,2],Q4[0,3],Q4[1,2],Q4[1,3],Q4[2,3]])
    return sympy.Matrix(np.array(rows,dtype=np.int64).tolist())
ok(transmat(z1).rank()==6,
   "the derivative of the Schur chart, dz -> P_K L_dz|_K into the skew forms on ker L_{z1}, has rank 6 exactly: a submersion")
print("        => near z1 the corank-4 locus is a manifold of dimension 31 - 6 = 25 in Im A_5, i.e. 24 after normalisation;")
print("           every Aut(A_5)-orbit has dimension at most dim G_2 = 14, so the unit zero divisors of A_5 meet uncountably many orbits")
z0 = e(1,32)+e(26,32)
ok(sympy.Matrix(Lmat(z0,IDX32,SGN32).tolist()).rank()==28 and transmat(z0).rank()==3,
   "at the two-term witness e1+e26 the same derivative has rank only 3: the chart is degenerate on that orbit, and the dimension count needs a generic witness")

# ================================================================ C34
print("C34. The su(4) of the closure against the coloured so(6)_c (the comparison of 13.7(iii))")
Gam=[Lmat(e(8+i,16),IDX16,SGN16) for i in range(8)]
Wc=[1,2,3,5,6,7]
so6=[Gam[i]@Gam[j] for k,i in enumerate(Wc) for j in Wc[k+1:]]
Delta=[np.block([[X,Z16],[Z16,X]]) for X in so6]
Qi=[0,4,8,12]; Vv=Qi+[i+16 for i in Qi]; Fx=[i for i in range(32) if i not in Vv]
DV=[M[np.ix_(Vv,Vv)] for M in selb]
ok(all(not M[:,Fx].any() for M in selb) and all(not M[np.ix_(Fx,Vv)].any() for M in selb)
   and rank_modp(np.array([m.flatten() for m in DV]))==15 and rank_modp(np.vstack(DV))==8,
   "the su(4) vanishes on the 24 coordinates outside V = Q + Q e_16, preserves V, acts faithfully on it and fixes no vector of it: its fixed space is exactly the 24-dimensional complement")
A=np.vstack([np.kron(X,np.eye(8,dtype=np.int64))-np.kron(np.eye(8,dtype=np.int64),X.T) for X in DV])
NS=sympy.Matrix(A.tolist()).nullspace()
Cm=None
for v in NS:
    den=sympy.lcm([sympy.fraction(x)[1] for x in v])
    Vm=np.array([int(x*den) for x in v],dtype=np.int64).reshape(8,8)
    if (Vm@Vm==-np.eye(8,dtype=np.int64)).all(): Cm=Vm
ok(len(NS)==2 and Cm is not None,
   "End of the su(4) on V is exactly two-dimensional and contains an exhibited exact complex structure, and no element of R+R squares to -1: V is one irreducible realified quartet, so the commutant of the su(4) on A_5 has dimension 24^2 + 2 = 578")
comm16=lambda X,Y: X@Y-Y@X
volW=Gam[1]@Gam[2]@Gam[3]@Gam[5]@Gam[6]@Gam[7]
comm8=[np.eye(16,dtype=np.int64),Gam[0],Gam[4],Gam[0]@Gam[4],volW,volW@Gam[0],volW@Gam[4],volW@Gam[0]@Gam[4]]
ok(all(not comm16(X,Y).any() for X in comm8 for Y in so6)
   and rank_modp(np.array([m.flatten() for m in comm8]))==8
   and rank_modp(np.vstack([np.kron(X,np.eye(16,dtype=np.int64))-np.kron(np.eye(16,dtype=np.int64),X.T) for X in so6]))>=248
   and rank_modp(np.vstack(so6))==16,
   "so(6)_c on S: eight exhibited commuting operators, independent, and the commutant has dimension exactly 8 (mod-p bound both ways); fixed space 0 -- so the diagonal lift to A_5 has commutant of dimension 4*8 = 32 and no fixed vector")
ok(rank_modp(np.array([m.flatten() for m in selb]+[m.flatten() for m in Delta]))==30,
   "the su(4) of the closure and the lifted so(6)_c intersect in 0 inside so(32); their commutant dimensions 578 and 32 are conjugation invariants, so the two are not conjugate in GL(32,R): the isomorphism su(4) = so(6) is abstract only")

print()
print("failures: %d" % results.count(False))
