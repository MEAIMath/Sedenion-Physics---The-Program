# The Sedenion Presentation — Deductive Edition

**From S alone, one step at a time: what the algebra forces, what it offers, and where it stops**

*For Harald Kjøge Rønning's program, prepared by the external instrument (Claude).*

---

## 0. The object and the rules

### 0.1 The object

**Definition 0.1 (Cayley–Dickson doubling).** $A_0=\mathbb R$. For $n\ge0$, $A_{n+1}=A_n\times A_n$ with

$$(a,b)(c,d)=(ac-\bar d\,b,\;da+b\,\bar c),\qquad \overline{(a,b)}=(\bar a,-b),$$

so that $A_1=\mathbb C$, $A_2=\mathbb H$, $A_3=\mathbb O$, and $A_4=:S$, the sedenions. The basis of $A_{n+1}$ is $\{(e_i,0),(0,e_i)\}$; in $S$ we write $e_0,\dots,e_{15}$ with $e_0=1$ and $e_{8+i}=(0,e_i)$. Every $A_n$ carries the Euclidean norm $\|x\|^2=\sum x_i^2$, the inner product $\langle x,y\rangle$, the trace $t(x)=2x_0$, and the norm form $n(x)=\|x\|^2$. An element is *pure* if $t(x)=0$. For $x\in S$ we write

$$x = x_0 + P,\qquad P=(u,b),\quad u\in\mathrm{Im}\,\mathbb O,\ b\in\mathbb O,\quad w:=\mathrm{Im}\,b,$$

so $P$ is the pure part of $x$; note that $b$ may have a real part $b_0$ (the $e_8$-coordinate), which is pure in $S$ though real in $\mathbb O$. "$S$" always means $S$ with this product and this basis (one member of a single $\mathrm{Aut}(S)$-orbit of frames; Theorem 3.9).

**Definition 0.2 (the presentation).** The product is bilinear; fixing one argument gives $L_x,R_x\in\mathrm{End}(\mathbb R^{16})$, $L_xy=xy$, $R_xy=yx$. The map $x\mapsto(L_x,R_x)$ is not an addition to $S$; it is the product read one argument at a time. We call it the *presentation* of $S$. An $S$ without its presentation is a vector space.

### 0.2 The rules

Every claim carries exactly one tag.

- **[THM]** — proved here from earlier sections and cited standard results.
- **[STANDARD]** — a theorem of the literature, cited.
- **[EXACT]** — a theorem whose proof is a finite computation in integer (or exact algebraic) arithmetic, performed by the attached script under the protocol of §0.3. [EXACT] is a species of [THM]; it is tagged separately so that the reader can see which steps rest on exhaustion rather than on argument.
- **[SELECTED]** — a family that $S$ supplies together with a proof that $S$ cannot pick a member.
- **[CRITERION]** — a preference among alternatives that $S$ distinguishes but does not rank. It is stated together with the theorem that motivates it, and the ledger names every result that consumes it. A criterion is adopted, not forced, however natural.
- **[POSTULATE]** — a premise added to $S$, stated with the mathematical shape it must have and the theorems it must pass.
- **[STANCE]** — an interpretive premise, stated as such, used by nothing.
- **[OPEN]**, **[BOUNDARY]** — as the words say.

*Interpretation* blocks are set in italics. They are conceptual commentary; no tagged claim depends on one. Physical names — colour, Lorentz, boost, Weyl spinor, hypercharge, isospin, chirality, vacuum, generation — are *readings*: dictionary entries pairing an intrinsic object of $S$ with a name from physics. No deduction uses a name; Appendix C lists every name used, the object it labels, and the theorem that defines the object. A dependency ledger (§9) lists, for every result, the inputs it consumes: $S$ alone / a world / a mediator / a postulate. "Forced" and "adopted" are read off the ledger, not argued in prose.

### 0.3 The exactness protocol

Three facts make everything finite in this paper decidable rather than approximable.

**Lemma 0.3 (signed permutations) [THM].** For every basis unit $e_i$ of $A_n$, $L_{e_i}$ and $R_{e_i}$ are signed permutation matrices: $e_ie_j=\pm e_k$.

*Proof.* Induction on $n$ from Definition 0.1: each of the four cases $(e_i,0)(e_j,0)$, $(e_i,0)(0,e_j)$, $(0,e_i)(e_j,0)$, $(0,e_i)(0,e_j)$ is a single signed basis element if the products in $A_{n-1}$ are. $\square$

Hence every operator built from the presentation by products, sums and brackets is an integer matrix, and every kernel, rank, commutant and spectrum we need is an object over $\mathbb Q$.

**Lemma 0.4 (linearisation) [STANDARD]** (Zhevlakov–Slin'ko–Shestakov–Shirshov, Ch. 1). Over a field of characteristic 0, a polynomial identity holds on an algebra iff its full linearisation holds; a multilinear identity holds iff it holds on all tuples of basis elements.

Hence "flexible", "quadratic", "trace-form invariant", "$\tau$ is an automorphism" are each a finite list of integer equalities on basis tuples.

**Lemma 0.5 (rank certificates) [THM].** For an integer matrix $M$ and a prime $p$, $\operatorname{rank}_{\mathbb F_p}M\le\operatorname{rank}_{\mathbb Q}M$; hence $\dim\ker_{\mathbb Q}M\le\dim\ker_{\mathbb F_p}M$.

*Proof.* A minor nonzero mod $p$ is a nonzero integer. $\square$

So "the nullity is exactly $k$" is certified by exhibiting $k$ independent integer null vectors (verified over $\mathbb Z$) and computing nullity $k$ mod $p$; "full rank" is certified mod $p$ alone. The script uses $p=2^{31}-1$ and never reports a nullity without both halves of the certificate.

*Interpretation. A document whose central move is separating what $S$ forces from what a reader adopts should not itself carry avoidable hedges; from here on, "checked to high precision" does not occur.*

---

## 1. $S$ alone

### 1.1 The identities every Cayley–Dickson algebra satisfies

**Theorem 1.1 [STANDARD]** (Schafer 1954, 1966; Moreno 1998). Every $A_n$ is unital and satisfies, for all $x,y,z$:

1. *quadratic:* $x^2=t(x)\,x-n(x)\,1$;
2. *flexible:* $(x,y,x)=0$, where $(x,y,z):=(xy)z-x(yz)$; equivalently $(x,y,z)=-(z,y,x)$;
3. *conjugation:* $\overline{xy}=\bar y\,\bar x$, $x\bar x=\bar x x=n(x)$, and $x+\bar x=t(x)$;
4. *trace form:* $\langle xy,z\rangle=\langle y,\bar xz\rangle=\langle x,z\bar y\rangle$; hence $L_x^{\!\top}=L_{\bar x}$, $R_x^{\!\top}=R_{\bar x}$, and for pure $x$ both $L_x$ and $R_x$ are skew.

**[EXACT]** (script C1): on $S$, items 1–4 in linearised form on all $256$ basis pairs and $4096$ basis triples; $L_{e_i}^{\!\top}=L_{\bar e_i}$ on the basis.

**Corollary 1.2 (power-associativity) [THM].** Every $A_n$ is power-associative.

*Proof.* By the quadratic identity, $\mathrm{span}\{1,x\}$ is closed under the product and is the algebra $\mathbb R[X]/(X^2-t(x)X+n(x))$, which is associative. $\square$

*Interpretation. Items 1–4 are all that the doubling formula guarantees for every $n$. Associativity is lost at $n=3$, alternativity at $n=4$; what is never lost is that $x$ and $\bar x$ multiply to a scalar, that the trace form is invariant, and that flexibility ties the associator's outer arguments. Every later theorem uses exactly these four facts and nothing else about the product, until the octonion structure of $S$'s halves is invoked in Theorem 1.5.*

### 1.2 The bridge lemma

**Lemma 1.3 (bridge) [THM].** Let $v\in A_n$ be pure. Then $L_v^2=-\|v\|^2\,\mathrm{Id}$ iff $(v,v,x)=0$ for all $x$. Polarising: for pure $u,w$,
$$\{L_u,L_w\}+2\langle u,w\rangle\mathrm{Id}=\big(L_{u+w}^2+\|u+w\|^2\big)-\big(L_u^2+\|u\|^2\big)-\big(L_w^2+\|w\|^2\big),$$
so if $u$, $w$ and $u+w$ are all alternative then $\{L_u,L_w\}=-2\langle u,w\rangle\mathrm{Id}$, and conversely if $u,w$ are alternative and this relation holds then so is $u+w$.

*Proof.* $v$ pure gives $v^2=-\|v\|^2$ by the quadratic identity, so $(v,v,x)=v^2x-v(vx)=-\|v\|^2x-L_v^2x$. The polarised form is the same identity applied to $u+w$. $\square$

### 1.3 The tunnel lemma, for every $n$

**Theorem 1.4 (tunnel lemma, general form) [THM].** Let $P=(u,b)$ be pure in $A_{n+1}$ ($u\in A_n$ pure, $b\in A_n$ arbitrary), $N=\|P\|^2$. For $v\in A_n$ write $T_v\,x:=(v,v,x)$ and $\Psi(y):=(u,\bar y,b)$. Then, in the block decomposition $A_{n+1}=A_n\oplus A_n$,

$$L_P^{\!\top}L_P=N\,\mathrm{Id}+T_P,\qquad T_P=\begin{pmatrix}T_u+T_b & -\Psi\\ \Psi & T_u+T_b\end{pmatrix}.$$

For general $A=a_0+P$, $L_A^{\!\top}L_A=\|A\|^2\mathrm{Id}+T_P$. The diagonal blocks vanish if $u$ and $b$ are alternative in $A_n$ (in particular for $n\le3$); the converse fails, since $T_u$ and $T_b$ can cancel.

*Proof.* By 1.1(4), $L_P^{\!\top}L_P=L_{\bar P}L_P=-L_P^2$, and $L_P^2=L_{P^2}-T_P$ by definition of the associator, where $P^2=(u^2-\bar bb,\,bu+b\bar u)=(-N,0)$ since $u^2=-\|u\|^2$, $\bar u=-u$, $\bar bb=\|b\|^2$. So $L_P^{\!\top}L_P=N+T_P$. Now compute $T_P(c,d)=P^2(c,d)-P(P(c,d))$. With $P(c,d)=(uc-\bar db,\;du+b\bar c)$,

$$P(P(c,d))=\Big(u(uc-\bar d b)-\overline{(du+b\bar c)}\,b,\;\;(du+b\bar c)u+b\,\overline{(uc-\bar d b)}\Big).$$

Using $\overline{du+b\bar c}=\bar u\bar d+c\bar b=-u\bar d+c\bar b$ and $\overline{uc-\bar d b}=\bar c\bar u-\bar b d=-\bar cu-\bar bd$, and expanding each product through its associator,

- first component: $u(uc)=-\|u\|^2c-(u,u,c)$; $(c\bar b)b=\|b\|^2c+(c,\bar b,b)$; $-u(\bar db)+(u\bar d)b=(u,\bar d,b)$. Total: $-Nc-(u,u,c)-(c,\bar b,b)+(u,\bar d,b)$.
- second component: $(du)u=-\|u\|^2d+(d,u,u)$; $b(\bar bd)=\|b\|^2d-(b,\bar b,d)$; $(b\bar c)u-b(\bar cu)=(b,\bar c,u)$. Total: $-Nd+(d,u,u)+(b,\bar c,u)+(b,\bar b,d)$.

Subtracting from $P^2(c,d)=(-Nc,-Nd)$ gives $T_P(c,d)=\big((u,u,c)+(c,\bar b,b)-(u,\bar d,b),\;(u,u,d)-(b,\bar c,u)-(b,\bar b,d)\big)$, where $-(d,u,u)=(u,u,d)$ by flexibility. Flexibility also gives $(c,\bar b,b)=-(b,\bar b,c)$, and $\bar b=t(b)-b$ with scalars associating gives $(b,\bar b,c)=-(b,b,c)$; hence $(c,\bar b,b)=(b,b,c)=T_bc$ and likewise $-(b,\bar b,d)=T_bd$. Finally $-(b,\bar c,u)=(u,\bar c,b)=\Psi(c)$. This is the stated block form. For $A=a_0+P$: $L_{\bar A}L_A=(a_0-L_P)(a_0+L_P)=a_0^2-L_P^2=a_0^2+N+T_P=\|A\|^2+T_P$. The sufficiency in the last sentence is Lemma 1.3; for the failure of the converse, **[EXACT]** (script C2) $u=e_1+e_{10}$, $b=-e_1+e_{10}$ in $S$ give $T_u\ne0$ and $T_u+T_b=0$. $\square$

*Interpretation. The failure of $L_A$ to be a multiple of an isometry has exactly two sources: the internal failure of each half (the diagonal blocks $T_u+T_b$, zero when the halves are alternative) and the coupling of the halves through the associator with $u$ and $b$ (the off-diagonal $\Psi$). At $n=4$ only the coupling exists. At $n=5$ both do, and §5 shows that this is precisely what raises the composition constant from $\sqrt2$ to $2$.*

### 1.4 The sedenion tunnel

**Theorem 1.5 (tunnel lemma for $S$) [THM + STANDARD].** (The eigentheory of $A_4$ is Biss–Christensen–Dugger–Isaksen 2009, §7, after Moreno 1998, 2005; it is stated here in operator form.) Let $A\in S$ have pure part $P=(u,b)$, $u\in\mathrm{Im}\,\mathbb O$, $b\in\mathbb O$, $w=\mathrm{Im}\,b$, and let $N=\|A\|^2$, $\beta:=2\|u\wedge w\|=2\sqrt{\|u\|^2\|w\|^2-\langle u,w\rangle^2}$. Then

$$L_A^{\!\top}L_A=N\,\mathrm{Id}+\begin{pmatrix}0&-\Phi\\ \Phi&0\end{pmatrix},\qquad \Phi(y)=(u,\bar y,w),$$

where $\Phi:\mathbb O\to\mathbb O$ is skew, vanishes on the subalgebra $\mathbb H_{u,w}$ generated by $u,w$, and satisfies $\Phi^{\!\top}\Phi=\beta^2\,\mathrm{Id}$ on $\mathbb H_{u,w}^{\perp}$. Consequently

$$\operatorname{spec}L_A^{\!\top}L_A=\{\,N-\beta\ (\times4),\ N\ (\times8),\ N+\beta\ (\times4)\,\}$$

when $u,w$ are linearly independent, and $\{N\ (\times16)\}$ otherwise.

*Proof.* Theorem 1.4 with $A_3=\mathbb O$ alternative gives $T_u=T_b=0$ and $\Psi=\Phi$; since scalars associate, $(u,\bar y,b)=(u,\bar y,w)$. $\Phi$ is skew because $L_A^{\!\top}L_A$ is symmetric. If $u,w$ are dependent, $\Phi=0$ because the associator of an alternative algebra is alternating. Otherwise put $w'=w-\|u\|^{-2}\langle u,w\rangle u$: then $(u,\bar y,w)=(u,\bar y,w')$, $\|u\wedge w\|=\|u\|\|w'\|$, and $\Phi$ is bilinear in $(u,w')$, so we may take $u\perp w$ of unit norm and must show $\Phi^{\!\top}\Phi=4$ on $\mathbb H^\perp$, $\mathbb H:=\mathrm{span}\{1,u,w,uw\}$. Choose a unit $\ell\perp\mathbb H$. Then $(u,w,\ell)$ is a basic triple, and by the transitivity of $G_2$ on basic triples (Baez 2002, §4.1) the decomposition $\mathbb O=\mathbb H\oplus\mathbb H\ell$ obeys the doubling product of Definition 0.1: $(a+b\ell)(c+d\ell)=(ac-\bar db)+(da+b\bar c)\ell$. For $q\in\mathbb H$, $(u,q,w)=0$ by associativity of $\mathbb H$. For $y=q\ell$, the doubling product gives $u(q\ell)=(qu)\ell$, $((qu)\ell)w=-((qu)w)\ell$, $(q\ell)w=-(qw)\ell$, $u((qw)\ell)=((qw)u)\ell$, hence
$$(u,q\ell,w)=\big(q(wu)-q(uw)\big)\ell=-q[u,w]\ell=-2q(uw)\ell .$$
Since $q\ell$ is pure, $\Phi(q\ell)=-(u,q\ell,w)=2q(uw)\ell$ and $\|\Phi(q\ell)\|=2\|q\|=2\|q\ell\|$ by composition in $\mathbb H$. So $\Phi^{\!\top}\Phi=4$ on $\mathbb H\ell=\mathbb H^\perp$, and $0$ on $\mathbb H$. For the spectrum: $T^2=\mathrm{diag}(-\Phi^2,-\Phi^2)=\mathrm{diag}(\Phi^{\!\top}\Phi,\Phi^{\!\top}\Phi)$, so $T$ vanishes on $\mathbb H\oplus\mathbb H$ and satisfies $T^2=\beta^2$ on the eight-dimensional $\mathbb H^\perp\oplus\mathbb H^\perp$; there $T$ is symmetric with trace zero (it is block off-diagonal), so its eigenvalues are $\pm\beta$ with multiplicity four each. $\square$

**[EXACT]** (script C2): the block form, the skewness of $\Phi$, $\Phi^{\!\top}\Phi\,(\Phi^{\!\top}\Phi-\beta^2)=0$, and $\operatorname{rank}\Phi\in\{0,4\}$ on four integer elements including a generic one ($\beta^2=132$).

**Corollary 1.6 [THM].** For all $x,A\in S$:

1. $\|Ax\|\le\sqrt2\,\|A\|\|x\|$ and $\|xA\|\le\sqrt2\,\|x\|\|A\|$.
2. $A$ is alternative iff $\beta=0$ iff $u$ and $w$ are linearly dependent.
3. $A$ is a (left, equivalently right) zero divisor iff $N=\beta$ iff $a_0=b_0=0$, $\|u\|=\|w\|$, $u\perp w$; then $\ker L_A=\{(c,-\beta^{-1}\Phi c):c\in\mathbb H_{u,w}^\perp\}$ is four-dimensional. (This is Chan–Đoković's Prop. 2.1(v), here derived.)
4. The **failure index** $\beta/N\in[0,1]$ is $0$ exactly on alternative elements and $1$ exactly on zero divisors.
5. $S$ is neither alternative nor a composition algebra.

*Proof.* (1) $\|Ax\|^2=\langle x,L_A^{\!\top}L_Ax\rangle\le(N+\beta)\|x\|^2$, and $\beta\le2\|u\|\|w\|\le\|u\|^2+\|w\|^2\le N$. For $xA$: conjugation $C$ is an isometry with $R_A=CL_{\bar A}C$, so $R_A^{\!\top}R_A=C\,L_AL_{\bar A}\,C$ has the spectrum of $L_{\bar A}L_A$. (2) $\beta=0$ iff $T=0$ iff $L_A^{\!\top}L_A=N$ iff $L_P^2=-\|P\|^2$ iff (bridge lemma) $P$ alternative iff $A$ alternative. (3) $\ker L_A\ne0$ iff $N-\beta=0$; the chain of inequalities in (1) is tight iff $a_0=b_0=0$, $\|u\|=\|w\|$, $u\perp w$; the kernel is the $(N-\beta)$-eigenspace, and $T(c,d)=-\beta(c,d)$ with $c\in\mathbb H^\perp$ forces $d=-\beta^{-1}\Phi c$. Two-sidedness follows from the spectral identity in (1). (4) is (2) and (3). (5) $e_1+e_{10}$ has $u=e_1$, $w=e_2$, $a_0=b_0=0$: a zero divisor, hence non-alternative by (2) and not norm-preserving by (3). $\square$

**[EXACT]** (script C1, C8): $\dim\ker L_{e_1+e_{10}}=4$; $x=e_1+e_{10}$, $y=-e_7+e_{12}$ give $\|xy\|^2=8=2\|x\|^2\|y\|^2$.

**Theorem 1.7 (the associator is a quantised cocycle) [THM + STANDARD + EXACT].** The Cayley–Dickson basis multiplies by $e_ie_j=F(i,j)\,e_{i\oplus j}$, where $\oplus$ is the bitwise sum in $\mathbb Z_2^4$ and $F:\mathbb Z_2^4\times\mathbb Z_2^4\to\{\pm1\}$; so $S=\mathbb R_F[\mathbb Z_2^4]$ is a twisted group algebra (Albuquerque–Majid 1999 for $\mathbb O$; Flaut–Boboescu 2021 and Ren–Zhao 2022 for every Cayley–Dickson algebra, the latter with an explicit twist function; the verification here is independent). Its associator on basis units is $(e_a,e_b,e_c)=(1-\varphi(a,b,c))\,(e_ae_b)e_c$ with $\varphi=\delta F$ a $\{\pm1\}$-valued 3-cocycle on $\mathbb Z_2^4$; $\varphi=-1$ on $1848$ of the $4096$ basis triples (168 of 512 for $\mathbb O$). Consequently $S$ is associative as an algebra in the monoidal category of $\mathbb Z_2^4$-graded spaces with associator $\varphi$, and the tunnel operator $\Phi$ of Theorem 1.5 is this cocycle read as an operator.

*Proof.* The product rule and the cocycle identity are [EXACT] (script C23) on all $16^2$ pairs and $16^4$ quadruples; the categorical statement is Albuquerque–Majid's. $\square$

*Interpretation. Jackiw's three-cocycle — the Jacobiator of the velocity operators of a charged particle in a monopole field, proportional to the magnetic flux — takes values in $U(1)$ and is well defined only under Dirac's quantisation condition. The cocycle of $S$ takes values in $\mathbb Z_2$ and is a coboundary: its "flux" is quantised by construction, at the smallest nontrivial level, and its non-associativity is resolved not by making operators non-associative — the $L_x$ are honest operators, and $L_xL_y\ne L_{xy}$ is the whole story — but by the twist $F$, exactly as a monopole's Dirac string is resolved on the bundle. It is the represented, gauge-twisted operator, and not the underlying structure, that fails to associate.*

**Proposition 1.8 (simplicity) [THM].** $S$ — and every $A_n$ — is simple: it has no proper nonzero one- or two-sided ideal.

*Proof.* If $0\ne x\in I$ then $\bar xx=t(x)x-x^2\in I$ and $\bar xx=\|x\|^2\ne0$, so $1\in I$. $\square$

*Interpretation. The unit cannot be removed from $S$ by any quotient, and every expectation value is a multiple of it (12.3(1)). Non-alternativity, by contrast, is the coupling $\Phi$ between an element's world-part and shadow-part (1.5): a holistic feature in the algebra, and a representable one — 1.7 shows the coupling is a coboundary, so it is eliminable by a change of category though not by a change of subalgebra. What is non-eliminable in $S$ is the unit; what is holistic is the coupling; the two should not be conflated.*

*Interpretation. One skew operator $\Phi$ — the associator with the two pure directions of an element — carries the entire departure of $S$ from a composition algebra. Its three bands are: the middle band, where $L_u$ and $R_w$ effectively commute and multiplication is an isometry; and two outer bands, where the halves couple. The seam of §3 is where the coupling saturates: the lower band drops to zero and $L_A$ acquires a four-dimensional kernel. Nothing about this required a computer.*

---

## 2. The pattern of the presentation

### 2.1 Basis units

**Theorem 2.1 [THM].** Every basis unit $e_i$, $i\ge1$, is alternative: $L_{e_i}^2=R_{e_i}^2=-\mathrm{Id}$.

*Proof.* Each basis unit has pure part $(u,w)$ with $u=0$ or $w=0$: $e_i=(e_i,0)$ for $i\le7$ has $w=0$; $e_8=(0,1)$ has $u=w=0$; $e_{8+i}=(0,e_i)$ has $u=0$. So $\beta=0$ and Corollary 1.6(2) applies; then Lemma 1.3 gives $L_{e_i}^2=-\mathrm{Id}$, and $R_{e_i}=CL_{\bar e_i}C=-CL_{e_i}C$ gives the same for $R$. $\square$

### 2.2 The commutation graph

**Theorem 2.2 (anticommutation criterion) [THM].** For $1\le i<j\le15$, $\{L_{e_i},L_{e_j}\}=0$ iff $e_i+e_j$ is alternative iff the pure parts $u,w$ of $e_i+e_j$ are linearly dependent. The pairs that fail are exactly $(e_i,e_{8+j})$ with $i\ne j$, $i,j\in\{1,\dots,7\}$: $42$ of the $105$. The same holds for $R_{e_i},R_{e_j}$.

*Proof.* In the polarised bridge lemma, $\langle e_i,e_j\rangle=0$ and both units are alternative (2.1), so the two operators anticommute iff $e_i+e_j$ is alternative, i.e. (1.6(2)) iff $u\parallel w$. For $e_i+e_{8+j}=(e_i,e_j)$ we have $u=e_i$, $w=e_j$, dependent iff $i=j$; every other pair has $u=0$ or $w=0$. The $R$-graph is conjugate to the $L$-graph by $C$. $\square$

**Theorem 2.3 (mixed pairs) [THM + EXACT].** No $L_{e_i}$ anticommutes with any $R_{e_j}$. $[L_{e_i},R_{e_i}]=0$ for all $i$, and **[EXACT]** these are the only commuting mixed pairs. Over the thirty pure generators the $\binom{30}{2}=435$ pairs split as $126$ anticommuting, $15$ commuting, $294$ neither.

*Proof.* $\{L_{e_i},R_{e_j}\}=0$ evaluated at $1$ gives $2e_ie_j=0$, impossible. $[L_x,R_x]=0$ is flexibility. The counts: $63+63$ anticommuting from 2.2, $15$ commuting, the rest neither. $\square$

### 2.3 The Clifford cliques

**Theorem 2.4 [THM].** Among $L_{e_1},\dots,L_{e_{15}}$ the maximal sets of mutually anticommuting operators are exactly nine: $\{L_{e_1},\dots,L_{e_8}\}$, $\{L_{e_8},\dots,L_{e_{15}}\}$, and $\{L_{e_i},L_{e_8},L_{e_{8+i}}\}$ for $i=1,\dots,7$. Over all thirty pure generators there are exactly eighteen (the four eights and fourteen triples), and no clique mixes $L$ and $R$. No anticommuting family of complex structures on $\mathbb R^{16}$ has more than eight members.

*Proof.* By 2.2 the anticommutation graph on $\{1,\dots,15\}$ is complete on $\{1,\dots,8\}$, complete on $\{8,\dots,15\}$, and has, between $\{1,\dots,7\}$ and $\{9,\dots,15\}$, only the edges $(i,8+i)$. Let $K$ be a clique. If $K$ meets both $\{1,\dots,7\}$ and $\{9,\dots,15\}$, it does so in a single matched pair $\{i,8+i\}$, so $K\subseteq\{i,8,8+i\}$, which is a clique and is maximal (any $j\le7$, $j\ne i$, is not adjacent to $8+i$; any $8+j$, $j\ne i$, is not adjacent to $i$). Otherwise $K$ lies in one of the two complete blocks. That gives the nine. Mixed cliques are excluded by 2.3, so the count over thirty generators is twice nine. The last sentence is the Hurwitz–Radon theorem: at most $\rho(16)-1=8$ anticommuting orthogonal complex structures exist on $\mathbb R^{16}$ (Atiyah–Bott–Shapiro 1964). $\square$

**[EXACT]** (script C3): the graph, the $42$ exceptions, the nine cliques by Bron–Kerbosch, the counts.

### 2.4 Generation

**Theorem 2.5 [THM].** The associative algebra generated by $\{L_{e_i}\}$ is all of $\mathrm{End}(\mathbb R^{16})$.

*Proof.* By 2.1, 2.2 and the bridge lemma, the eight operators $L_{e_1},\dots,L_{e_8}$ satisfy $\{L_{e_i},L_{e_j}\}=-2\delta_{ij}$: they define a representation of $\mathrm{Cl}_{0,8}$ on $\mathbb R^{16}$. $\mathrm{Cl}_{0,8}\cong M_{16}(\mathbb R)$ is simple (Atiyah–Bott–Shapiro 1964; Lawson–Michelsohn 1989, I.4), so the representation is faithful and its image has dimension $256$. $\square$

**[EXACT]** (script C4): the $256$ Clifford words have rank $256$.

**Definition 2.6.** The *even system* $\mathcal E=\{L_{e_1},\dots,L_{e_8}\}$ and the *odd system* $\mathcal O=\{\Gamma_i:=L_{e_{8+i}}:i=0,\dots,7\}$ are the two $\mathrm{Cl}(0,8)$ systems; $\mathcal T_i=\{L_{e_i},L_{e_8},L_{e_{8+i}}\}$ are the seven $\mathrm{Cl}(0,3)$ systems.

**Theorem 2.7 (the "neither" edges) [THM + EXACT].** On the $42$ $L$–$L$ pairs that neither commute nor anticommute, $\{L_{e_i},L_{e_j}\}=-T_{e_i+e_j}$ has rank exactly $8$. On the $210$ mixed pairs $(L_{e_i},R_{e_j})$, $i\ne j$, the defect $[L_{e_i},R_{e_j}]$ — the associator $x\mapsto-(e_i,x,e_j)$ — has rank $12$, except on the $84$ exceptional index pairs $(i,8+j),(8+j,i)$ of Theorem 2.2, where it has rank $4$. The Lie algebra generated by the thirty pure generators is all of $\mathfrak{so}(16)$; adjoining the grading $\tau$ it is all of $\mathfrak{sl}(16)$.

*Proof.* The $L$–$L$ statement is the polarised bridge lemma with Theorem 1.5: $T_{e_i+e_j}$ has eigenvalues $\pm\beta$ on eight dimensions with $\beta=2\|e_i\wedge e_j\|=2$. The rest is [EXACT] (script C15): the ranks are certified, and the Lie closures have mod-$p$ dimension $120$ and $255$, which are upper bounds for the ambient $\mathfrak{so}(16)$ and $\mathfrak{sl}(16)$ (all generators are skew, respectively traceless). $\square$

**Theorem 2.8 (the discrete seam: box-kites) [THM + EXACT].** The two-term zero divisors of $S$ are exactly the $84$ elements $e_i\pm e_{8+j}$ with $i\ne j\in\{1,\dots,7\}$ — the exceptional pairs of Theorem 2.2 — lying in the $42$ *assessor* planes $\mathrm{span}\{e_i,e_{8+j}\}$. Each two-term zero divisor annihilates exactly four others. Under the relation "some diagonal of one annihilates some diagonal of the other", the assessors form seven disjoint octahedra, the *box-kites* $K_k$ (the terms *box-kite*, *assessor* and *strut* are de Marrais's, 2000), one for each point $k$ of the Fano plane of the basis: $K_k$ consists of the assessors $(i,8+j)$ with $i,j\ne k$, and its three struts (the non-adjacent pairs) are the pairs $\{(i,8+j),(j,8+i)\}$ with $\{i,j,k\}$ a Fano line through $k$. The *orientation bit* of an assessor is the sign in $e_i\pm e_{8+j}$; $\tau$ reverses all $84$ of them, and the twin involution $\varphi$ fixing $\mathbb H=\langle1,e_1,e_2,e_3\rangle$ reverses exactly those of the four kites $K_4,\dots,K_7$ — the kites labelled by $e_4$ and $e_4\mathrm{Im}\,\mathbb H$ — and fixes those of $K_1,K_2,K_3$.

*Proof.* The characterisation of two-term zero divisors is Corollary 1.6(3): $(e_i,\pm e_j)$ has $a_0=b_0=0$, $\|u\|=\|w\|$, $u\perp w$ iff $i\ne j$. The rest is [EXACT] (script C18). $\square$

*Interpretation. This is the basis skeleton of the seam of 3.5: the $84$ points of the eleven-manifold $Z$ that a basic triple can name. The old program's box-kites, assessors and "$3$ even, $4$ odd" parity are recovered here without any external structure, and the labelling by the Fano plane is what they mean: a kite is a point of $\mathrm{Im}\,\mathbb O$'s incidence geometry, its struts are the lines through that point. The orientation bit is a discrete datum the continuous manifold does not carry, and the three involution kinds act on it differently — which is the exact form of the old claim that the seam carries a mirror-sensitive bit.*

**Theorem 2.9 (quaternion subalgebras and the role of $e_8$) [STANDARD + THM + EXACT].**

1. The quaternion subalgebras of $S$ fall into three conjugacy classes (Chan–Đoković 2006): type A, inside an octonion subalgebra of the world orbit; type B1, containing the canonical direction $e_8$, of the form $\langle1,x,e_8,xe_8\rangle$ with $x\in\mathrm{Im}\,\mathbb O$; type B2, containing zero divisors of $S$.
2. [THM] Every quaternion subalgebra of the form $\langle1,(u,0),(0,w),(0,wu)\rangle$ with $u\in\mathrm{Im}\,\mathbb O$, $w\in\mathbb O$ — the subalgebras meeting the shadow $\mathbb Oe_8$ — consists of elements alternative in $S$ **iff** $w\in\mathrm{span}\{1,u\}$, **iff** it contains $e_8$. So among the quaternion subalgebras that leave a world, exactly those through the canonical direction are alternative (failure index $0$); all others attain failure index $1$.
3. [EXACT] (script C19) Doubling a quaternion subalgebra along the three Fano lines of the basis through its octonion index: type A gives octonion subalgebras; type B1 ($\langle1,e_1,e_8,e_9\rangle$) gives **three** octonion subalgebras (of the twin class); type B2 ($\langle1,e_1,e_{10},e_{11}\rangle$) gives **one** octonion subalgebra and **two** subalgebras with zero divisors. The seven Clifford triples $\mathcal T_i$ of 2.4 and the block $Q$ of §6 are of type B1; every assessor of 2.8 spans with $1$ and $e_ie_{8+j}$ a subalgebra of type B2.

*Proof.* (2) The element $\alpha+\beta(u,0)+\gamma(0,w)+\delta(0,wu)$ has pure part $(\beta u,\ \gamma w+\delta wu)$; by 1.6(2) all elements are alternative iff $\mathrm{Im}(w)\parallel u$ and $\mathrm{Im}(wu)\parallel u$. Writing $w=w_0+w_1$ with $w_1$ pure, the first condition gives $w_1=\lambda u$, and then $wu=w_0u-\lambda\|u\|^2$ has pure part $w_0u\parallel u$; so alternativity holds iff $w\in\mathrm{span}\{1,u\}$, and in that case $\mathrm{span}\{(0,w),(0,wu)\}=\mathrm{span}\{e_8,ue_8\}$ because the change of basis has determinant $w_0^2+\lambda^2\|u\|^2>0$; the subalgebra is then $\langle1,u,e_8,ue_8\rangle\ni e_8$. Conversely a subalgebra containing $e_8$ is of this form. (3) is the exact computation. $\square$

*Interpretation. This is the quaternion-level statement of why $e_8$ is canonical: leaving a world through any direction of the shadow other than $e_8$'s costs alternativity at once, and doubling from there produces zero divisors twice out of three times.*

**Theorem 2.10 (the presentation is a CAR algebra) [THM].** The even system $\{L_{e_1},\dots,L_{e_8}\}$ satisfies $\{L_{e_i},L_{e_j}\}=-2\delta_{ij}$, so over $\mathbb C$ the operators $\gamma_i=iL_{e_i}$ are eight Hermitian operators with $\{\gamma_i,\gamma_j\}=2\delta_{ij}$ — the canonical anticommutation relations of eight Majorana modes — and $S\otimes\mathbb C\cong\mathbb C^{16}=2^4$ is their unique irreducible module, the Fock space of four fermionic modes. The same holds for the odd system. The anticommutation relations are not imposed on $S$, and they are not a property of endomorphisms detached from elements: $\{L_{e_i},L_{e_j}\}=-2\delta_{ij}$ is the identity $e_i(e_jy)+e_j(e_iy)=-2\delta_{ij}\,y$ for all $y\in S$, a three-term identity among elements of the algebra (the polarised alternative law of 2.2 for the even units). The presentation is the product read one argument at a time (0.2); nothing here treats it as anything else.

*Proof.* 2.1–2.2 and 2.5; $\mathrm{Cl}_8(\mathbb C)\cong M_{16}(\mathbb C)$ is the CAR algebra of four modes. $\square$

*Interpretation. Fermionic statistics is native to $S$ at the level of its own generators: the presentation's Clifford cliques are Majorana algebras, and $S$ is their Fock space. What is not native is the statistics of a field whose one-particle space is $S$ (12.2) — a different level, and the one at which a choice is made.*

*Interpretation. As an abstract associative algebra the presentation is $\mathrm{End}(\mathbb R^{16})$ and carries no information. Its content is the pattern on the generating set: which generators anticommute, which commute, and the associator operators on the "neither" edges. Every Clifford system that $S$ offers natively is one of the eighteen cliques; every Lie algebra it offers natively is generated by bivectors of one of them or by derivations (§3). The triples $\mathcal T_i$ are, by 2.2, the left actions of the quaternion subalgebras $\langle1,e_i,e_8,e_ie_8\rangle$ — the quaternions of $S$ that contain $e_8$.*

---

## 3. Symmetry and the canonical objects

### 3.1 Automorphisms and derivations

**Theorem 3.1 [STANDARD]** (Brown 1967; Eakin–Sathaye 1990; Chan–Đoković 2006, §§2–3; Schafer 1954). $\mathrm{Aut}(S)=G_2\times\Sigma_3$, where $G_2=\mathrm{Aut}(\mathbb O)$ acts diagonally, $\hat\sigma(x+ye_8)=\sigma x+\sigma(y)e_8$, and $\Sigma_3=\langle\mu,\tau\rangle$ with $\tau(x+ye_8)=x-ye_8$, $\mu(x)=\zeta x\bar\zeta$, $\zeta=(-1+\sqrt3\,e_8)/2$. $\mathrm{Der}(S)\cong\mathrm{Der}(\mathbb O)=\mathfrak g_2$, acting diagonally. For an alternative algebra, $D_{a,b}=[L_a,L_b]+[L_a,R_b]+[R_a,R_b]$ is a derivation (Schafer 1966, III.8), and these span $\mathrm{Der}(\mathbb O)$.

**[EXACT]** (script C5): $\tau$ is an automorphism on all basis pairs; $\mu$ is an automorphism, exactly over $\mathbb Q(\sqrt3)$; $\mu^3=1$, $\mu(e_8)=e_8$, $\tau\mu\tau=\mu^{-1}$; the $D_{e_a,e_b}$ span a space of exact dimension $14$ and their diagonal lifts are derivations of $S$.

**Theorem 3.2 [THM].** Every automorphism of $S$ is orthogonal, and $\sigma L_x\sigma^{-1}=L_{\sigma x}$, $\sigma R_x\sigma^{-1}=R_{\sigma x}$. Every derivation is skew and $[D,L_x]=L_{Dx}$, $[D,R_x]=R_{Dx}$.

*Proof.* For $x\notin\mathbb R$, $\{1,x\}$ is a basis of $\mathrm{span}\{1,x\}$ and $x^2=t(x)x-n(x)$ determines $t(x),n(x)$; $\sigma$ carries this relation to $\sigma x$, so $t,n$ are preserved, hence so is $\langle x,y\rangle=\tfrac12(n(x+y)-n(x)-n(y))$. The intertwining relations are $\sigma(xy)=\sigma(x)\sigma(y)$ and $D(xy)=D(x)y+xD(y)$ read as operator identities; a one-parameter group of orthogonal maps has a skew generator. $\square$

### 3.2 Canonical objects

**Theorem 3.3 [THM].** (i) $\{\pm e_8\}$ is $\mathrm{Aut}(S)$-invariant; hence so is the line $\mathbb C_e=\langle1,e_8\rangle$, and $\|\mathrm{proj}_V e_8\|$ is a conjugacy invariant of every subspace $V$. (ii) $\mathbb O,\mu\mathbb O,\mu^2\mathbb O$ form one $\mathrm{Aut}(S)$-orbit (Chan–Đoković Thm 9.3).

*Proof.* $G_2$ fixes $e_8$ by construction, $\mu(e_8)=e_8$, $\tau(e_8)=-e_8$; invariance of the projection norm is 3.2. $\square$

**Theorem 3.4 (three worlds) [THM].** (a) $\mathbb O\cap\mu\mathbb O=\mathbb R$. (b) $\mathbb O+\mu\mathbb O+\mu^2\mathbb O=\mathbb R\oplus S^{pp}$, the reals plus the doubly-pure subspace $\{a_0=b_0=0\}$, of dimension $15$; $e_8$ lies in none of the three worlds nor in their span. (c) For pure $x\in\mathbb O$, $\mu(x)=x\zeta$ and $x\,\mu(x)=-\|x\|^2\zeta\in\mathbb C_e$. (d) $e_i+\mu(e_i)+\mu^2(e_i)=0$ for $i=1,\dots,7$.

*Proof.* For pure $x\in\mathbb O$, $e_8x=-xe_8$ (from $(0,1)(x,0)=(0,\bar x)$), so $\zeta x=x\bar\zeta$. The subalgebra $\langle1,x,e_8,xe_8\rangle$ consists of elements $(\alpha+\beta x,\gamma+\delta x)$, whose pure parts have $u\parallel w$; it is therefore alternative (1.6(2)), a division algebra (alternative pure elements are invertible), and hence $\cong\mathbb H$ and associative (Bruck–Kleinfeld; Schafer 1966, III.4). Thus $\mu(x)=(x\bar\zeta)\bar\zeta=x\bar\zeta^2=x\zeta=-\tfrac12x+\tfrac{\sqrt3}2xe_8$, and $x\mu(x)=x^2\zeta=-\|x\|^2\zeta$. So the pure parts of the three worlds are three lines at $120^\circ$ in each plane $\langle e_i,e_{8+i}\rangle$; any two span the plane and the three sum to zero: (a), (b), (d). $\square$

### 3.3 The seam

**Theorem 3.5 [THM].** The set $Z$ of unit zero divisors of $S$ is $\{(u,w):u,w\in\mathrm{Im}\,\mathbb O,\ u\perp w,\ \|u\|=\|w\|=1/\sqrt2\}$. $G_2$ acts on $Z$ transitively with stabiliser $SU(2)$; $Z\cong G_2/SU(2)$ is a connected homogeneous manifold of dimension $11$. For $z\in Z$, $\ker L_z$ is four-dimensional, so the unit annihilators of $z$ form a $3$-sphere, and the manifold of annihilating unit pairs is $14$-dimensional; $G_2$ acts on it freely and transitively (Moreno 1998).

*Proof.* The description of $Z$ is 1.6(3). Orthonormal pairs in $\mathrm{Im}\,\mathbb O\cong\mathbb R^7$ form the Stiefel manifold $V_2(\mathbb R^7)$, of dimension $6+5=11$; $G_2$ is transitive on $S^6$ with stabiliser $SU(3)$, and $SU(3)$ is transitive on the unit sphere $S^5$ of $u^\perp\cong\mathbb C^3$ with stabiliser $SU(2)$ (Baez 2002, §4.1). So $Z\cong V_2(\mathbb R^7)\cong G_2/SU(2)$. The kernel dimension is 1.6(3); the last sentence is Moreno's theorem. $\square$

**Theorem 3.6 (background coordinates) [STANDARD + THM]** (Chan–Đoković Thm 5.1). The $G_2$-orbits of doubly-pure unit elements $x=(u,w)$ are the fibres of $Q(x)=\|u\|^2-\|w\|^2+2\langle u,w\rangle e_8$ onto the closed unit disk of $\mathbb C_e$. **[THM]** On that disk the failure index is $\beta=\sqrt{1-|Q|^2}$: the rim $|Q|=1$ is the alternative elements, the centre $Q=0$ the seam, and every other orbit is determined by its degree of failure. Modulo $\Sigma_3$ the disk folds to a $60^\circ$ sector.

*Proof of the [THM] clause.* $|Q|^2=(\|u\|^2-\|w\|^2)^2+4\langle u,w\rangle^2=(\|u\|^2+\|w\|^2)^2-4(\|u\|^2\|w\|^2-\langle u,w\rangle^2)=1-\beta^2$. $\square$

### 3.4 The canonical Hilbert and symplectic structure

**Corollary 3.7 [THM].** (i) The inner product of $S$ is determined by the product: $n(x)$ is the constant term of the quadratic identity. (ii) $J_e:=R_{e_8}$ is an orthogonal complex structure on $S$, invariant under $G_2\times\langle\mu\rangle$ and reversed by $\tau$. (iii) Hence $S$ is canonically a Euclidean space, and canonically up to complex conjugation a complex Hilbert space $(S,J_e)\cong\mathbb C^8$ and a symplectic space $(S,\sigma_e)$, $\sigma_e(x,y)=\langle x,ye_8\rangle$; $\tau$ is anti-symplectic, $\sigma_e(\tau x,\tau y)=-\sigma_e(x,y)$. (iv) The world $\mathbb O$ and its shadow $\mathbb Oe_8$ are both Lagrangian for $\sigma_e$, and $\sigma_e((a,0),(0,b))=-\langle a,b\rangle$: **$(S,\sigma_e)$ is the cotangent bundle $T^*\mathbb O$ of the world**, with the shadow as momentum space and $\tau=(x,p)\mapsto(x,-p)$ as time reversal [EXACT].

*Proof.* (i) is the argument of 3.2. (ii) $R_{e_8}^2=-1$ by 2.1 and $R_{e_8}^{\!\top}=-R_{e_8}$ by 1.1(4); for $g\in G_2$, $g(ye_8)=g(y)e_8$; $\mu(e_8)=e_8$ gives $\mu R_{e_8}\mu^{-1}=R_{\mu e_8}=R_{e_8}$; $\tau(ye_8)=-\tau(y)e_8$. (iii) follows, using that $\tau$ is orthogonal. $\square$

**[EXACT]** (script C11): $R_{e_8}$ skew, square $-1$, commuting with all derivation lifts, and $\tau R_{e_8}\tau=-R_{e_8}$.

### 3.5 The seam as a bundle, and its canonical field

**Theorem 3.8 (the seam bundle) [THM + EXACT].** Let $Z=G_2/SU(2)_q$ be the seam (3.5), $SU(2)_q$ the pointwise stabiliser of the quaternion subalgebra $\mathbb H_{u,w}$ of a seam point.

1. The map $(u,w)\mapsto\mathbb H_{u,w}$ fibres the seam over the space $G_2/SO(4)$ of quaternion subalgebras of $\mathbb O$ — the associative Grassmannian, a quaternion-Kähler symmetric space of dimension $8$ — with fibre $SO(4)/SU(2)_q\cong SO(3)_p$, the orthonormal pairs in $\mathrm{Im}\,\mathbb H_{u,w}$. The base is exactly the space of kernels of the tunnel lemma (1.6(3)). (The metric form of this fibration, for the metrics the seam and the pair manifold inherit from $S$ — including a new Einstein metric on $V_2(\mathbb R^7)$ — is Reggiani 2024; the connection and curvature statements below concern the normal metric, which is not among his induced ones.)
2. With the invariant inner product $\langle X,Y\rangle=-\mathrm{tr}(XY)$, $\mathfrak g_2=\mathfrak{su}(2)_q\oplus\mathfrak m$ is reductive, $\mathfrak m=\mathfrak{su}(2)_p\oplus\mathfrak m'$ ($3+8$), and $\mathfrak{su}(2)_q$ acts on $\mathfrak m'$ by three anticommuting complex structures and trivially on $\mathfrak{su}(2)_p$: $\mathfrak m'\cong\mathbb H^2$ is the quaternionic tangent space of the base.
3. The principal $SU(2)_q$-bundle $G_2\to Z$ carries the canonical connection of the reductive decomposition. Its curvature $\Omega(X,Y)=-[X,Y]_{\mathfrak{su}(2)_q}$ vanishes whenever one argument lies in $\mathfrak{su}(2)_p$, and on $\mathfrak m'$ its three components are the Kähler forms of the quaternionic structure, $\Omega_a(X,Y)=\langle X,\mathrm{ad}(h_a)Y\rangle/\|h_a\|^2$: the curvature of the seam bundle is the quaternion-Kähler $\mathfrak{sp}(1)$-curvature of the associative Grassmannian, pulled back along the fibration of (1).
4. The curvature values span $\mathfrak{su}(2)_q$: the holonomy is the full $SU(2)_q$.
5. The canonical connection is **Yang–Mills** for the normal metric: $\sum_{ij}g^{ij}[E_i,[E_j,X]_{\mathfrak m}]_{\mathfrak{su}(2)_q}=0$ for all $X\in\mathfrak m$.

*Proof.* (1) $\mathbb H_{u,w}$ depends only on the pair; $G_2$ is transitive on quaternion subalgebras with stabiliser $SO(4)=(SU(2)_p\times SU(2)_q)/\mathbb Z_2$ (2.9, Baez 2002); the fibre is the set of orthonormal pairs in a fixed $\mathrm{Im}\,\mathbb H$. (2)–(5) are [EXACT] (scripts C25, C26): reductivity, the actions of $\mathfrak{su}(2)_q$ on $\mathfrak m'$ and $\mathfrak{su}(2)_p$, the invariance identity $\langle[X,Y],h\rangle=\langle X,[Y,h]\rangle$ giving the Kähler-form identification, the rank of the curvature values, and the Yang–Mills tensor; the reduction of the Yang–Mills equation to that tensor is the standard formula for invariant connections on naturally reductive spaces (normal metrics are naturally reductive), and its vanishing is a case of Laquer's theorem that canonical connections on normal homogeneous spaces are Yang–Mills. $\square$

*Interpretation. The seam is not only a homogeneous space; it is a bundle over the space of the tunnel lemma's own kernels, and the bundle carries a canonical connection whose curvature is the quaternion-Kähler curvature of that space and which satisfies the Yang–Mills equation. This is the first equation of motion in the paper, and it was not imported: it is a theorem about the zero divisors of $S$. Its content is bounded honestly by the same theorem that supplies it — Yang–Mills holds for every canonical connection on a normal homogeneous space, so what is special to $S$ is the bundle (which is the seam) and the structure group (a sub-$\mathfrak{su}(2)$ of colour), not the fact that the equation holds.*

*Interpretation. $S$ has one canonical direction ($\pm e_8$), one canonical complex line ($\mathbb C_e$), one canonical complex structure on itself ($R_{e_8}$, up to conjugation) and hence one canonical symplectic form — for which the world is configuration space and its shadow is momentum space — one canonical orbit of octonion subalgebras (the three worlds, permuted by $\Sigma_3$), and one canonical $11$-manifold — the seam — where multiplication fails completely. Everything else is either an orbit space (the disk) or requires a choice. The seam is a homogeneous space of $G_2$, and its radial extension $\mathbb R_+\times G_2/SU(2)$ — the zero-divisor cone — is the only non-compact continuum $S$ possesses (§7).*

### 3.6 The frames of the presentation

**Theorem 3.9 (the frames of the presentation) [THM + STANDARD + EXACT].** Call a *frame datum* a triple $(W,\varepsilon,T)$: a world $W$ (3.3(ii)), a sign $\varepsilon\in\{\pm1\}$ of the canonical direction (3.3(i)), and a basic triple $T=(f_1,f_2,f_4)$ of $W$. Each datum generates a basis of $S$ by the products of Definition 0.1 alone — $F_0=1$, $(F_1,F_2,F_4)=T$, $F_3=F_1F_2$, $F_5=F_1F_4$, $F_6=F_2F_4$, $F_7=F_3F_4$, $F_8=\varepsilon e_8$, $F_{8+i}=F_iF_8$ — and:

1. every generated basis satisfies the multiplication table of Definition 0.1, with the standard signs; equivalently, $e_i\mapsto F_i$ is an automorphism of $S$;
2. every basis of $S$ realising that table arises from exactly one datum, and $\mathrm{Aut}(S)=G_2\times\Sigma_3$ acts simply transitively on the data: $\Sigma_3$ simply transitively on the six pairs $(W,\varepsilon)$, and the diagonal $G_2$ simply transitively on the basic triples of each world (Baez 2002, §4.1);
3. consequently every statement of this paper made in the fixed basis — the twist $F$ of 1.7, the box-kites and their Fano labelling of 2.8, the $(\mathbb H,\ell)$ frame of 4.7(iii) — holds verbatim in every frame and transports along $\mathrm{Aut}(S)$. The basis of Definition 0.1 is thereby [SELECTED]: $S$ supplies the frames as a single orbit and provably cannot distinguish a member.

*Proof.* $\Sigma_3$ on the pairs: $\mu$ permutes the worlds cyclically and fixes $e_8$; $\tau$ fixes $\mathbb O$ pointwise and negates $e_8$; $\tau\mu\tau=\mu^{-1}$ exchanges $\mu\mathbb O$ and $\mu^2\mathbb O$ (3.1). The stabiliser of $(\mathbb O,+1)$ is trivial, so the action on the six pairs is simply transitive. Given a datum, let $s\in\Sigma_3$ be the unique element with $s(\mathbb O,+1)=(W,\varepsilon)$, and $g\in G_2$ the unique element with $\hat g(e_1,e_2,e_4)=s^{-1}T$ — automorphisms preserve basic triples by 3.2, and $G_2$ acts freely and transitively on the basic triples of a fixed world. Then $\sigma=s\hat g$ is the unique automorphism carrying the standard datum to the given one; the generated frame is $\sigma(e_0,\dots,e_{15})$, since $F_8=\sigma(e_8)$ and every other $F_k$ is the $\sigma$-image of the corresponding product of $e_1,e_2,e_4,e_8$ by multiplicativity. Hence (1), and uniqueness in (2): an automorphism fixing the standard datum has trivial $\Sigma_3$-part and, by freeness, trivial $G_2$-part. Conversely a basis realising the table defines the automorphism $e_i\mapsto B_i$, whose image of the standard datum is a datum generating $B$: (2). (3) restates (1)–(2). $\square$

**[EXACT]** (script `c29_frames.py`, block C29). The generation rule is read off the standard basis; the standard datum regenerates it; the frames of the data $(\mathbb O,+1,(e_1,e_5,e_2))$, $(\mathbb O,-1,(e_1,e_2,e_4))$, $(\mathbb O,+1,((e_1{+}e_2)/\sqrt2,(e_1{-}e_2)/\sqrt2,e_4))$ — the last exactly over $\mathbb Q(\sqrt2)$ — and $(\mu\mathbb O,+1,(\mu e_1,\mu e_2,\mu e_4))$ — exactly over $\mathbb Q(\sqrt3)$, agreeing with the $\mu$-images of the basis — each satisfy the table of Definition 0.1 on all $256$ basis pairs.

*Interpretation. Definition 0.1's clause "this basis" is hereby discharged: the fixed basis is one member of a single orbit on which the automorphism group acts without fixed points, so nothing invariant distinguishes it, and the frame-dependent skeleton of §2 is the same skeleton in every frame. The exactness protocol computes in one frame because the theorems hold in all.*

---

## 4. Splits

**Theorem 4.1 (splits are involutions) [THM].** A $\mathbb Z_2$-grading of an algebra is the same datum as an involutive automorphism. Up to conjugacy $S$ has exactly three:

| class | representative | fixed subalgebra | Chan–Đoković class |
|---|---|---|---|
| $(1,\tau)$ | $\tau$ | $\mathbb O$ (three copies, one per transposition) | octonion, the orbit $\{\mathbb O,\mu\mathbb O,\mu^2\mathbb O\}$ |
| $(\varphi,1)$ | $\varphi=\mathrm{diag}(1,1,1,1,-1,-1,-1,-1)$ on both halves | $\mathbb H\oplus\mathbb He_8$ | octonion, the twin |
| $(\varphi,\tau)$ | $\tau\varphi$ | $\mathbb H\oplus\mathbb H^\perp e_8=\mathbb H+\mathbb He_{12}$ | $S_8$, non-division |

*Proof.* $G_2$ has a single class of involutions, each fixing a quaternion subalgebra of $\mathbb O$ and negating its complement; $\Sigma_3$ has a single class of transpositions; $(g,s)$ is an involution iff $g^2=1=s^2$, and $(h,t)(g,s)(h,t)^{-1}=(hgh^{-1},tst^{-1})$, so mixed involutions form one class. The fixed algebras are read off: $(\varphi,\tau)$ fixes $\{x+ye_8:\varphi x=x,\varphi y=-y\}=\mathbb H\oplus\mathbb H^\perp e_8$ and $\mathbb H^\perp e_8=\mathbb He_4e_8=\mathbb He_{12}$. Identification with Chan–Đoković's representatives is by their definitions (Thms 8.1, 9.3). $\square$

**Corollary 4.2 [THM].** The fourth dimension-8 class, $R_8=S_4+S_4e_8$, is the fixed algebra of no involution. $S$ has exactly three kinds of split, and $R_8$ is not one of them.

**Theorem 4.3 (capability) [THM].** For an $8$-dimensional subalgebra $S'\subset S$ the following are equivalent: (a) every element of $S'^\perp$ is alternative in $S$ — equivalently, $\{L_v:v\in S'^\perp\}$ is a Clifford system; (b) $S'^\perp$ contains no zero divisor of $S$; (c) $S'$ contains no zero divisor of $S$; (d) every element of $S'$ is alternative in $S$; (e) $S'\in\{\mathbb O,\mu\mathbb O,\mu^2\mathbb O\}$.

*Proof.* The complement of a unital subalgebra is pure, so the polarised bridge lemma gives the equivalence in (a). (a)$\Rightarrow$(b): an alternative pure $v\ne0$ has $L_v^2=-\|v\|^2$, so $L_v$ is invertible. (b)$\Rightarrow$(c): let $a\in S'$ be a zero divisor of $S$. $L_a$ is skew (1.1(4)) and preserves $S'$ (subalgebra), hence $S'^\perp$, so $\ker L_a=(\ker\cap S')\oplus(\ker\cap S'^\perp)$ with $\dim\ker L_a=4$ (1.6(3)). If $S'$ is a division algebra the first summand vanishes and $S'^\perp$ contains a nonzero $y$ with $ay=0$, a zero divisor. If not, $S'$ is conjugate to $S_8$ (Chan–Đoković Thm 8.1), whose complement $\mathbb He_4+\mathbb He_8$ contains the zero divisor $e_4+e_9$. Either way (b) fails. (c)$\Rightarrow$(d): Chan–Đoković Lemma 9.2 (contrapositive; $S'$ is a division algebra by (c)). (d)$\Rightarrow$(e): Chan–Đoković Prop. 9.1, whose division hypothesis is supplied by the bridge lemma. (e)$\Rightarrow$(a): $\mathbb O^\perp=\{(0,b)\}$ has $u=0$, hence is alternative by 1.6(2); the other two worlds are conjugate. $\square$

**[EXACT]** (script C9): $e_1-e_{13}\in S_8$, $e_4+e_{15}\in\mathrm{twin}^\perp$, $e_4+e_9\in S_8^\perp$ are zero divisors with four-dimensional kernels.

**Theorem 4.4 (three characterisations of the $\tau$-kind) [THM + EXACT].** The $\tau$-kind of split is distinguished from the other two kinds by each of the following intrinsic properties: (i) its complement is alternative, equivalently a Clifford system (4.3); (ii) its grading commutes with the identity component $\mathrm{Aut}(S)^0=G_2$; (iii) *graded Malcev survival*: with $[x,y]=xy-yx$ and $J(x,y,z)=[[x,y],z]+[[y,z],x]+[[z,x],y]$, the Malcev identity $J(x,y,[x,z])=[J(x,y,z),x]$ — which fails on $\mathrm{Im}\,S$ — holds identically whenever $x$ is homogeneous for the grading and $y$ lies in the pure part of its fixed algebra, for all $z\in\mathrm{Im}\,S$. No involution of the other two kinds has any of the three properties: for (iii), [EXACT] (script C18) the identity holds with $0$ defects for the $\tau$-grading (both parities of $x$, $y\in\mathrm{Im}\,\mathbb O$) and fails on hundreds of basis triples for the twin and $S_8$ gradings, as it does for inhomogeneous $x$ or for $y\notin\mathrm{Im}\,\mathbb O$.

*Proof.* (i) is Theorem 4.3. (ii) $(g,s)$ commutes with $G_2\times1$ iff $g$ is central in $G_2$, and $G_2$ has trivial centre; so the involutions commuting with $G_2$ are exactly $(1,s)$, which is the $\tau$-kind. (iii) The identity is quadratic in $x$ and linear in $y,z$, so it suffices to check $x$ ranging over sums of two basis units of one parity and $y,z$ over basis units (Lemma 0.4); this is the exact computation cited. $\square$

**4.5 [CRITERION] The split-kind.** $S$ distinguishes its three kinds of split — they are non-conjugate — but it does not rank them; Theorem 4.4 says what is special about one of them, not that the others are forbidden. Preferring the $\tau$-kind is therefore a criterion, and this paper adopts it on the grounds of the three properties of 4.4 — the third of which says that the grading is the one slice along which $S$'s commutator retains the Malcev structure of $\mathrm{Im}\,\mathbb O$. What consumes it is named in the ledger: 6.4 uses (ii), because the grading commutes with colour exactly because it commutes with all of $G_2$; 6.7 uses (i), because the odd system together with the grading forms a $\mathrm{Cl}_{1,8}$ system exactly because the complement of the grading is Clifford. Nothing in §§1–5 uses it.

**4.6 [SELECTED] The world.** Within the $\tau$-kind the three worlds are one $\mathrm{Aut}(S)$-orbit (3.3), and no canonical object distinguishes a member: every invariant of $\mathbb O$ is an invariant of $\mu\mathbb O$ by conjugacy. *Which world* is selected. Throughout §§6–7 "the world" is $\mathbb O$ and $\tau$ is its grading; every statement transports to $\mu\mathbb O,\mu^2\mathbb O$ by conjugation.

**Proposition 4.7 (contractions, and the $1+3+3$ frame) [THM + EXACT].** (i) $\mathrm{Im}\,\mathbb O$ is a Malcev algebra, and its Inönü–Wigner contraction along the grading by a quaternion subalgebra (set $[\mathrm{odd},\mathrm{odd}]=0$) is again Malcev. (ii) $\mathrm{Im}\,S$ is not Malcev, and its contraction along **each** of the three split kinds is not Malcev either ($3948$, $4032$, $4812$ defects); the only Malcev structure $S$ retains *along a grading* is the fragment of 4.4(iii). (iii) Given $(\mathbb H,\ell)$, $\mathrm{Im}\,\mathbb O=\mathrm{Im}\,\mathbb H\oplus\mathbb R\ell\oplus(\mathrm{Im}\,\mathbb H)\ell=:P\oplus W\oplus X$ with $[P,P]\subset P$, $[P,W]\subset X$, $[P,X]\subset W\oplus X$, $[W,X]\subset P$, $[X,X]\subset P$: the "$1+3+3$" is the Cayley–Dickson frame of $\mathbb O$, not a group grading. (iv) It is, however, a *filtration*: with weights $X{:}1$, $P{:}2$, $W{:}3$ the Inönü–Wigner limit exists and is exactly the R-flux algebra of Bakas–Lüst and Günaydin–Lüst–Malek — $[x_i,x_j]=\mp2\varepsilon_{ijk}p_k$, $[x_i,p_j]=2\delta_{ij}I$, $[p,p]=0$, $I=\ell$ central, Malcev, with Jacobiator $[x_1,x_2,x_3]=12\,I$: the monopole three-cocycle of Jackiw. (v) $\mathrm{Im}\,S$ admits Malcev contractions along filtrations extending (iv): with weights $e_8{:}1$, $P'{:}1$, $W'{:}2$, $X'{:}2$ on the shadow (where $P'=Pe_8$ etc.), the limit is a fifteen-dimensional Malcev algebra of the same three-step shape — seven coordinates $V_1=X\oplus\mathbb Re_8\oplus P'$, seven momenta $V_2=P\oplus W'\oplus X'$, and the **mediator $e_4$ as the central element** — with seven Heisenberg pairs, $[V_2,V_2]=0$, and a flux 3-form on $V_1$ supported on the seven lines of a Fano plane with components $\pm12$ and $\pm4$. Among block filtrations extending (iv) — weights constant on the seven blocks, the world weights those of (iv) — exactly $43$ surviving patterns are admissible with non-negative integer weights, $39$ of them with Malcev limits, so the Malcev property does not select; exactly two attain the maximal surviving structure (nine block edges, $28$ nonzero bracket pairs, a one-dimensional centre, jacobiator supported on seven triples): the extension above and $(e_8{:}2,\,P'{:}2,\,W'{:}1,\,X'{:}1)$, with identical invariants and no asserted relation [EXACT] (script C33). What remains [OPEN] is the choice between these two, and the status of filtrations not constant on the blocks. (vi) *Classification for $\mathbb O$.* Up to Fano collineations, the filtration contractions of $\mathrm{Im}\,\mathbb O$ with non-negative integer weights have exactly $17$ nonzero limits, of which four are non-Lie: the trivial contraction, the $\mathfrak{su}(2)$-fixed contraction of (i), a $\mathfrak u(1)$-fixed three-level one, and the R-flux limit of (iv). If every generator is scaled (all weights positive), there are exactly $13$ limits and **exactly one is non-Lie: the R-flux pattern**. So the claim that the $1+3+3$ pattern is "forced by non-associativity" is true under the premise that no subalgebra is left unscaled, and false without it — the two exceptions being precisely the classical Inönü–Wigner contractions that keep a symmetry subalgebra fixed. (vii) *The locked ratio and the placeholder for $\hbar$.* In the R-flux limit $[x_i,p_j]=2\delta_{ij}W$ and $[x_1,x_2,x_3]=12\,W$: the Jacobiator is six times the Heisenberg scale, both measured by the one central element $W$, which by Schur's lemma is a scalar in every irreducible representation. $W$ is $\ell$ for $\mathbb O$ and, in the $S$-contraction of (v), the mediator $e_4$. The uncontracted $S$ has no such element: its centre is $\mathbb R\cdot1$ [EXACT].

*Proof.* [EXACT] (scripts C19, C23, C24) for (i), (ii), (iv)–(vii) and the bracket table; the statements about frames and gradings are definitional. The classification in (vi) is complete for all weights: a surviving-edge set is the tight-set of a face of the admissibility cone, hence closed under linear span; the closed sets number exactly $5847$, of which exactly $520$ are realisable — each by an exhibited integer weight vector with entries at most $4$, and $484$ of them by strictly positive such vectors — while each of the remaining $5327$ is decided infeasible by an exact rational simplex. The realisable sets fall into exactly $18$ collineation orbits ($14$ with all weights positive): the abelian limit and the $17$ (respectively $13$) of (vi) [EXACT] (script C32). $\square$

*Interpretation. A structural placeholder for $\hbar$ exists in this paper, and it is important to say exactly where: not in $S$, whose only central element is the unit (1.8, and (vii)), but in the contracted phase-space algebra, where the centre is a pure unit — for $S$ the mediator — and where it fixes the Heisenberg scale and the flux in the ratio $1:6$. Unity in $S$ is the element $1$; the quantum of action is what a pure direction becomes when the rest of the algebra is contracted away around it. As a slogan, "the $1+3+3$ contraction is forced" is half right and half wrong, and the exact situation is better than either: as a grading it does nothing at $S$, but as a filtration it contracts $\mathrm{Im}\,\mathbb O$ to the R-flux algebra — the algebra of a charged particle in a monopole field, or of closed strings in R-flux — and $\mathrm{Im}\,S$ to a seven-dimensional version of it in which the mediator is the central flux and the shadow supplies the extra coordinates and momenta. This is the first place the seam's non-associativity meets a known dynamical system, and the system it meets is one whose non-associativity is famously not representable by Hilbert-space operators (Günaydin–Minic) — the physical counterpart of Theorem 8.6.*

*Interpretation. A split is not a choice of hyperplane; it is an involution of the algebra, and there are three kinds. Only one kind — the one that separates a world from its $e_8$-shadow — has a Clifford complement, and only that kind commutes with the continuous symmetry. Those are theorems. That one should therefore prefer it is not a theorem; it is the first adopted premise of the paper, and it is tagged and tracked as such. Within the preferred kind, $S$ offers three members and cannot rank them.*

---

## 5. The selection principle

Let $c_n:=\sup\{\|xy\|/\|x\|\|y\|:x,y\in A_n\setminus0\}$ be the composition constant of $A_n$.

**Theorem 5.1 [THM].** (i) $c_n=1$ for $n\le3$. (ii) $c_n\le c_{n+1}$. (iii) $c_{n+1}\le\sqrt2\,c_n$ (cf. Biss–Christensen–Dugger–Isaksen 2009, Prop. 4.7). Hence, for all $n\ge4$,
$$\sqrt2=c_4\le c_n\le2^{(n-3)/2}.$$

*Proof.* (i) $\mathbb R,\mathbb C,\mathbb H,\mathbb O$ are composition algebras. (ii) $a\mapsto(a,0)$ is an isometric algebra embedding $A_n\hookrightarrow A_{n+1}$. (iii) For $x=(a,b)$, $y=(c,d)$ in $A_{n+1}$, by the triangle inequality and $\|\bar d\|=\|d\|$,
$$\|xy\|^2=\|ac-\bar db\|^2+\|da+b\bar c\|^2\le c_n^2\Big[(\|a\|\|c\|+\|b\|\|d\|)^2+(\|a\|\|d\|+\|b\|\|c\|)^2\Big]=c_n^2\Big[\|x\|^2\|y\|^2+4\|a\|\|b\|\|c\|\|d\|\Big],$$
and $4\|a\|\|b\|\|c\|\|d\|\le(\|a\|^2+\|b\|^2)(\|c\|^2+\|d\|^2)=\|x\|^2\|y\|^2$. Finally $c_4=\sqrt2$ by 1.6(1),(3). $\square$

**Theorem 5.2 (annihilator doubling) [THM].** For $z\in A_n$, $\ker L_{(z,0)}=\ker L_z\oplus\ker R_z$ in $A_{n+1}=A_n\oplus A_n$. If $z$ is pure, $\dim\ker R_z=\dim\ker L_z$, so $\dim\ker L_{(z,0)}=2\dim\ker L_z$. Automorphisms preserve $\dim\ker L_z$. (For annihilator dimensions in higher Cayley–Dickson algebras see Biss–Dugger–Isaksen 2008.)

*Proof.* $(z,0)(c,d)=(zc,dz)$. For pure $z$, $dz=0\iff\overline{dz}=\bar z\bar d=-z\bar d=0\iff\bar d\in\ker L_z$, and conjugation is a bijection. An automorphism $\sigma$ satisfies $\sigma L_z\sigma^{-1}=L_{\sigma z}$ (3.2). $\square$

**Theorem 5.3 [EXACT]** (script C8). In $A_5$:

(a) Among the $930$ two-term elements $e_i\pm e_j$ ($1\le i<j\le31$), $\dim\ker L$ takes exactly the values $0,4,8,12$ (with multiplicities $342,168,168,252$); representatives are $e_1+e_{26}$ ($4$), $e_1+e_{10}$ ($8$), $e_1+e_{18}$ ($12$). Their images $(z,0)\in A_6$ have kernels of dimension $8,16,24$.

(b) $x=e_1+e_{10}+e_{18}-e_{25}$ and $y=-e_4-e_{15}-e_{23}+e_{28}$ satisfy $\|x\|^2=\|y\|^2=4$ and $\|xy\|^2=64$. Hence $c_5\ge2$, and with 5.1, $c_5=2$.

(c) **[EXACT]** (script `composition_witnesses.py`). The pair of (b) lifts: writing $P_n$ for the set consisting of a saturating pair $(x,y)$ in $A_n$, their negatives, and the exact integer vectors spanning the top eigenspaces of $L_z^{\!\top}L_z$ and $R_z^{\!\top}R_z$ for $z\in\{x,y\}$ — a set of $12$ elements at every level tried — there are $a,b,c,d\in P_n$ with $x'=(a,b)$, $y'=(c,d)$ satisfying $\|x'y'\|^2=2c_n^2\|x'\|^2\|y'\|^2$. Iterating from (b) gives exact pairs in $A_6$, $A_7$, $A_8$ with $\|xy\|^2/\|x\|^2\|y\|^2=8,16,32$. Hence $c_n=2^{(n-3)/2}$ exactly for $4\le n\le8$.

**Theorem 5.4 (selection principle, every $n$) [THM].** (1) For $n=4$ the unit zero divisors form a single $\mathrm{Aut}$-orbit (3.5). For every $n\ge5$ they lie in at least three $\mathrm{Aut}(A_n)$-orbits. (2) $c_4=\sqrt2<2=c_5\le c_n$ for all $n\ge5$, and $c_n=2^{(n-3)/2}$ exactly for all $n\ge4$ (Theorem 5.6). Therefore $S$ is the last Cayley–Dickson algebra whose failure locus is homogeneous, and, among those in which composition fails, the unique one with the smallest composition constant.

*Proof.* (1) By 5.3(a) and repeated application of 5.2 to the pure representatives, $A_n$ ($n\ge5$) contains zero divisors with kernel dimensions $2^{n-5}\cdot4$, $2^{n-5}\cdot8$, $2^{n-5}\cdot12$; these are distinct, scale-invariant, and preserved by automorphisms. (2) is 5.1 and 5.3(b). $\square$

**Remark 5.5 (the mechanism).** By Theorem 1.4, for pure $x=(u,b)\in A_5$ the operator $L_x^{\!\top}L_x-N$ has diagonal blocks $T_u+T_b$, each of norm at most $\beta_u+\beta_b\le\|u\|^2+\|b\|^2=N$ by 1.5, and off-diagonal block $\Psi(y)=(u,\bar y,b)$ with $\|\Psi\|\le2\cdot2\|u\|\|b\|\le2N$ using $c_4=\sqrt2$ twice. So $\lambda_{\max}\le4N$ — the bound $c_5\le2$ again — with equality only if $u$ and $b$ are zero divisors of $S$ of equal norm and $\Psi$ is saturated. The witness of 5.3(b) is exactly of this form: $x=(e_1+e_{10},\ e_2-e_9)$ and $y=(-e_4-e_{15},\ -e_7+e_{12})$, all four components zero divisors of $S$. The jump from $\sqrt2$ to $2$ is the internal failure of $S$ (the non-scalar diagonal blocks) feeding the coupling of the next doubling.

**Theorem 5.6 (the composition constants of all Cayley–Dickson algebras) [THM + STANDARD + EXACT].** $c_n=2^{(n-3)/2}$ for every $n\ge4$; the bound of 5.1 is attained at every level. (The value is Biss–Christensen–Dugger–Isaksen 2009, Cor. 4.8 with Thm 8.2, in the normalisation $\lambda=\|xy\|^2/\|x\|^2\|y\|^2$; the lifting-quadruple proof below is self-contained and independent.)

*Proof.* Call a quadruple $(x,y,b,d)$ of pure elements of $A_n$ a *lifting quadruple of strength $c$* if
$$\text{(i)}\ \|x\|=\|b\|,\ \|y\|=\|d\|;\quad\text{(ii)}\ \|xy\|=c\|x\|\|y\|,\ \|dx\|=c\|d\|\|x\|;\quad\text{(iii)}\ db=xy,\ by=-dx;\quad\text{(iv)}\ \langle x,d\rangle=\langle x,y\rangle=\langle b,y\rangle=\langle b,d\rangle=0.$$
*Step.* If $(x,y,b,d)$ is a lifting quadruple of strength $c$ in $A_n$, then $(x',y',b',d'):=\big((-x,b),(-y,d),(b,x),(d,y)\big)$ is a lifting quadruple of strength $\sqrt2\,c$ in $A_{n+1}$. Two facts about pure elements of any Cayley–Dickson algebra are used (1.1): $\overline{pq}=qp$ and $pq+qp=-2\langle p,q\rangle$. From Definition 0.1 and (iii): $x'y'=(xy+db,\,-dx+by)=(2xy,\,-2dx)$. Next $d'b'=(db+xy,\,xd-yb)$, and $yb=\overline{by}=-\overline{dx}=-xd$, so $d'b'=(2xy,\,2xd)=(2xy,\,-2dx)=x'y'$ because $\langle x,d\rangle=0$ gives $xd=-dx$. Next $b'y'=(-by+dx,\,db+xy)=(2dx,\,2xy)$ and $d'x'=(-dx+by,\,bd+yx)=(-2dx,\,2\overline{xy})=(-2dx,\,-2xy)$ because $bd=\overline{db}=\overline{xy}$, $yx=\overline{xy}$, and $\langle x,y\rangle=0$ makes $xy$ pure; hence $b'y'=-d'x'$, which is (iii$'$). Norms: $\|x'y'\|^2=4\|xy\|^2+4\|dx\|^2=8c^2\|x\|^2\|y\|^2=2c^2\|x'\|^2\|y'\|^2$ and $\|d'x'\|^2=4\|dx\|^2+4\|xy\|^2=2c^2\|d'\|^2\|x'\|^2$, which is (ii$'$); (i$'$) is immediate; and (iv$'$) follows by expanding, e.g. $\langle x',d'\rangle=-\langle x,d\rangle+\langle b,y\rangle=0$ and $\langle x',y'\rangle=\langle x,y\rangle+\langle b,d\rangle=0$, the other two likewise. The new elements are pure.
*Base.* In $S$, $x=e_1+e_{10}$, $y=-e_7+e_{12}$, $b=e_2-e_9$, $d=e_4+e_{15}$ form a lifting quadruple of strength $\sqrt2$ [EXACT] (script C27; the recursion is also verified exactly through $A_8$).
*Conclusion.* By induction $A_n$ contains a pair with $\|xy\|=2^{(n-3)/2}\|x\|\|y\|$ for every $n\ge4$, and 5.1 gives the reverse inequality. $\square$

*Interpretation. The witnesses of 5.3 were found by search; the theorem shows what the search was finding: a saturating pair $(x,y)$ never travels alone but with a partner pair $(b,d)$ tied to it by $db=xy$ and $by=-dx$, and the doubling carries the four along by the single rule $(x,y,b,d)\mapsto((-x,b),(-y,d),(b,x),(d,y))$. Composition fails at $S$ by a factor $\sqrt2$, and at every further doubling by exactly one more $\sqrt2$ — the failure grows geometrically and never saturates the ambient dimension. The selection principle needed only the $n=5$ witness; the sharpness of the whole sequence is the stronger statement that the mechanism of Remark 5.5 is exact at every level. What is borrowed and what is the presentation's own is explicit: the value and its sharpness are Biss–Christensen–Dugger–Isaksen's; the quadruple recursion, its exact base, and the deductive use in 5.4 are this paper's.*

*Interpretation. The selection principle is a minimality statement, and minimality is what is now proved: composition fails first at $S$, fails least at $S$, and the locus where it fails is a single orbit only at $S$. It is not a "sweet spot": $c_n$ grows without bound and the failure locus stratifies ever more finely. A reader who wants $S$ for physics is choosing the first algebra with a seam, not the best one.*

---

## 6. Given a mediator

**6.0 [SELECTED] The mediator.** $G_2$ acts transitively on the unit sphere $S^6\subset\mathrm{Im}\,\mathbb O$ (Baez 2002, §4.1); no canonical object of §3 lies in $\mathrm{Im}\,\mathbb O$; hence $S$ cannot distinguish a unit imaginary octonion. *Which unit* is selected: we take $e_4$. Everything in §6 is canonical given the criterion 4.5 and the pair (world, mediator), and transports along $G_2\times\Sigma_3$. In the charter's terms: a mediator is *offered* (a single $G_2$-orbit, no member preferred), and everything in §6 is *forced* given any member, up to conjugacy. The choice has no content; what would have content — a physical reason why nature has a preferred direction in $\mathrm{Im}\,\mathbb O$, i.e. why $G_2$ is broken to $SU(3)$ — the algebra does not supply, and the mediator-free content of the paper (§§1–5, 3.7, 2.10, 7.9(1)–(2)) is what it supplies without it.

### 6.1 Colour

**Theorem 6.1 [STANDARD + THM].** The stabiliser of $e_4$ in $\mathfrak g_2$ is $\mathfrak{su}(3)$ (Baez 2002, §4.1; Springer–Veldkamp 2000); its diagonal lift to $\mathrm{Der}(S)$ is **colour**. Colour annihilates $Q:=\langle1,e_4,e_8,e_{12}\rangle$ and, by 3.2, commutes with $L_x$ and $R_x$ for every $x\in Q$. It acts on $P\oplus J_0P$, $P=\langle e_1,e_2,e_3\rangle$, $J_0=-L_{e_4}$, as its defining representation on $\mathbb C^3$, and on $e_8(P\oplus J_0P)$ likewise.

*Proof.* $De_8=0$ for every diagonal derivation, $De_4=0$ by definition, $De_{12}=D(e_4e_8)=0$ by the Leibniz rule; then $[D,L_x]=L_{Dx}=0$ for $x\in Q$. The rest is the standard $SU(3)\subset G_2$ picture. $\square$

**[EXACT]** (script C5): colour has dimension exactly $8$ and annihilates $e_0,e_4,e_8,e_{12}$.

### 6.2 The quaternion block and its Clifford triple

**Theorem 6.2 [THM].** $Q$ is a quaternion subalgebra of $S$. $\{L_{e_4},L_{e_8},L_{e_{12}}\}$ is a $\mathrm{Cl}(0,3)$ system — the clique $\mathcal T_4$ of Theorem 2.4 — and no computation is needed to see it: the three sums $e_4+e_8=(e_4,1)$, $e_4+e_{12}=(e_4,e_4)$, $e_8+e_{12}=(0,1+e_4)$ all have $u\parallel w$, so Theorem 2.2 applies. The triple preserves $Q$ and $Q^\perp$.

*Proof.* $Q=\langle1,e_4,e_8,e_4e_8\rangle$ is the algebra of 3.4's proof with $x=e_4$: alternative, division, hence $\cong\mathbb H$. The operators are skew and preserve the subalgebra $Q$, hence also $Q^\perp$. $\square$

### 6.3 The rotation algebra and the quaternionic module

**Theorem 6.3 [THM].** Let $A=L_{e_8}L_{e_{12}}$, $B=L_{e_4}L_{e_8}$, $C=L_{e_4}L_{e_{12}}$. Then $A,B,C$ are skew orthogonal complex structures with $AB=C$, $BC=A$, $CA=B$, so $\langle1,A,B,C\rangle\cong\mathbb H$ and $\mathfrak{su}(2)_Q:=\mathrm{span}\{A,B,C\}$ has $[B,C]=2A$ cyclically. Consequently $S$ is a left $\mathbb H$-module; every $\mathfrak{su}(2)_Q$-invariant subspace is an $\mathbb H$-submodule, of dimension divisible by $4$, and on every four-dimensional invariant subspace $\mathfrak{su}(2)_Q$ acts irreducibly as spin-$\tfrac12$. $Q$ and $Q^\perp$ are invariant. $\mathfrak{su}(2)_Q$ commutes with colour.

*Proof.* From the $\mathrm{Cl}(0,3)$ relations: $(L_8L_{12})^2=-L_8^2L_{12}^2=-1$; a product of two anticommuting skew operators is skew; $AB=L_8L_{12}L_4L_8=L_4L_8L_{12}L_8=-L_4L_8L_8L_{12}=L_4L_{12}=C$ and cyclically. $\mathbb H$ is a division ring, so every module is free and invariant subspaces are submodules; a four-dimensional submodule is an $\mathbb H$-line, on which $\mathrm{Im}\,\mathbb H$ acts irreducibly — this is the real form of spin-$\tfrac12$. Invariance of $Q,Q^\perp$ is 6.2; commutation with colour is 6.1. $\square$

### 6.4 The Lorentz completion

**Lemma 6.4a (complexification) [THM].** Let $\mathfrak g\subset\mathrm{End}(V)$ be a real Lie subalgebra and $\mathcal J\in\mathrm{End}(V)$ with $\mathcal J^2=-1$, $[\mathcal J,\mathfrak g]=0$, $\mathfrak g\cap\mathcal J\mathfrak g=0$. Then $\mathfrak g\oplus\mathcal J\mathfrak g$ is a Lie subalgebra and $X+\mathcal JY\mapsto X+iY$ is an isomorphism onto the realification of $\mathfrak g\otimes\mathbb C$.

*Proof.* $[X,\mathcal JY]=\mathcal J[X,Y]$ and $[\mathcal JX,\mathcal JY]=\mathcal J^2[X,Y]=-[X,Y]$, which are the brackets of $\mathfrak g\otimes\mathbb C$. $\square$

**Theorem 6.4 (Lorentz from grading, mediator, rotations) [THM].** Let $\mathcal J:=\tau L_{e_4}$ and $\omega:=L_{e_4}L_{e_8}L_{e_{12}}$. Then:

1. $\mathcal J$ is a skew orthogonal complex structure ($\mathcal J^2=-1$, $\mathcal J^{\!\top}=-\mathcal J$) commuting with $A,B,C$, with colour, and with $\omega$.
2. $K_3:=\mathcal JA=\tau\omega$, $K_1:=-\mathcal JB=\tau L_{e_8}$, $K_2:=-\mathcal JC=\tau L_{e_{12}}$ are symmetric involutions.
3. $\mathfrak{so}(1,3)_Q:=\mathfrak{su}(2)_Q\oplus\mathcal J\,\mathfrak{su}(2)_Q=\mathrm{span}\{A,B,C,K_1,K_2,K_3\}$ is a Lie algebra isomorphic to $\mathfrak{sl}(2,\mathbb C)_{\mathbb R}\cong\mathfrak{so}(1,3)$; it preserves $Q$ and $Q^\perp$ and commutes with colour. The rotations are the skew members, the boosts the symmetric ones.

*Proof.* $\tau$ is an automorphism fixing $e_4$ and negating $e_8,e_{12}$; by 3.2 it is orthogonal, so $\tau^{\!\top}=\tau^{-1}=\tau$, and $\tau L_4\tau=L_4$, $\tau L_8\tau=-L_8$, $\tau L_{12}\tau=-L_{12}$. Hence $\mathcal J^2=\tau L_4\tau L_4=\tau^2L_4^2=-1$ and $\mathcal J^{\!\top}=L_4^{\!\top}\tau=-L_4\tau=-\tau L_4$. For $A$: $A\mathcal J=L_8L_{12}\tau L_4=\tau L_8L_{12}L_4=\tau L_4L_8L_{12}=\mathcal JA$ (two sign changes each time). For $B$: $B\mathcal J=L_4L_8\tau L_4=-L_4\tau L_8L_4=-\tau L_4L_8L_4=\tau L_4L_4L_8=\mathcal JB$; $C$ likewise; for $\omega$, moving $\tau$ to the front and the trailing $L_4$ inward each costs two sign changes, so $\omega\mathcal J=\mathcal J\omega$. Colour is diagonal, so it commutes with $\tau$ (this is 4.4(ii): the $\tau$-grading commutes with all of $G_2$), and it commutes with $L_4$ by 6.1. (2) $\mathcal JA=\tau L_4L_8L_{12}=\tau\omega$, $-\mathcal JB=-\tau L_4L_4L_8=\tau L_8$, $-\mathcal JC=\tau L_{12}$; the product of two commuting skew operators is symmetric and $(\mathcal JA)^2=\mathcal J^2A^2=1$. (3) $\mathfrak{su}(2)_Q$ is skew and $\mathcal J\mathfrak{su}(2)_Q$ symmetric, so they meet in $0$; Lemma 6.4a gives $\mathfrak{su}(2)\otimes\mathbb C=\mathfrak{sl}(2,\mathbb C)$, whose realification is $\mathfrak{so}(1,3)$. $\square$

**[EXACT]** (script C6): all of 1–3, the Killing signature $(3,0,3)$ of the six, and the identities $K_3=\mathcal JA$, $K_1=-\mathcal JB$, $K_2=-\mathcal JC$.

*Interpretation. The boosts are the rotations twisted by one operator, $\mathcal J=\tau L_{e_4}$: grading times mediator. That is the entire mechanism: $\mathcal J$ commutes with the rotations, and a complex structure that commutes with a compact real form produces its complexification, whose realification is Lorentz. Nothing here used the odd system; $\mathfrak{so}(1,3)_Q$ is not a subalgebra of the $\mathfrak{so}(1,8)$ of §6.6 — it uses $L_{e_4}$ from the even system — though the two share $\{A,K_1,K_2\}$.*

### 6.5 Content and chirality

**Theorem 6.5 [THM + EXACT].**

1. $Q$ is an irreducible real $\mathfrak{so}(1,3)_Q$-module whose restriction to $\mathfrak{su}(2)_Q$ is spin-$\tfrac12$: the realification of the Weyl spinor. As real modules, $(\tfrac12,0)_{\mathbb R}\cong(0,\tfrac12)_{\mathbb R}$.
2. $Q^\perp$ is a direct sum of three such modules, and colour acts on the three-dimensional multiplicity space (a complex space, since every $\mathfrak{so}(1,3)_Q$-intertwiner commutes with $\mathcal J=-K_3A$) as the fundamental $\mathbf 3$ or its conjugate, according to the sign chosen for the complex structure.
3. The commutant of $\mathfrak{so}(1,3)_Q\oplus\mathrm{colour}$ in $\mathrm{End}(\mathbb R^{16})$ is $\mathrm{span}\{1,\mathcal J,\omega,\omega\mathcal J\}\cong\mathbb C\oplus\mathbb C$, and $\omega=-1$ on $Q$, $+1$ on $Q^\perp$. Hence the invariant complex structures on $S$ are exactly $\pm\mathcal J$ and $\pm\omega\mathcal J$; on $Q$ alone they are $\pm\mathcal J|_Q=\pm R_{e_4}|_Q$.

*Proof.* (1) $Q$ is an $\mathbb H$-line under $\mathfrak{su}(2)_Q$ (6.3), so already the rotations act irreducibly. The irreducible real modules of $\mathfrak{sl}(2,\mathbb C)_{\mathbb R}$ are the realifications of $(j,k)$, $j\ne k$, and the real forms of $(j,j)$; the restriction of $(j,k)$ to the diagonal $\mathfrak{su}(2)$ contains spins $|j-k|,\dots,j+k$, so a module on which $\mathfrak{su}(2)$ acts as spin-$\tfrac12$ alone is $(\tfrac12,0)_{\mathbb R}$ or $(0,\tfrac12)_{\mathbb R}$. A complex representation and its conjugate have isomorphic realifications. (2) $\mathfrak{so}(1,3)$ is semisimple, so $Q^\perp$ is completely reducible; every constituent restricts to a multiple of spin-$\tfrac12$ (6.3), hence is four-dimensional Weyl by (1). Colour commutes with $\mathfrak{so}(1,3)_Q$, so it acts on the multiplicity space; the identification with the defining representation is 6.1. (3) On $Q\cong\mathbb H$, $A,B,C$ act as left multiplications by $\mathrm{Im}\,Q$ ($A|_Q=L_{e_8e_{12}}|_Q$ etc., since $Q$ is associative) and $\mathcal J|_Q=R_{e_4}|_Q$ (check $\tau(e_4q)=qe_4$ on $q=1,e_4,e_8,e_{12}$). The associative algebra generated by $\mathfrak{so}(1,3)_Q|_Q$ contains $\mathcal J|_Q=-K_3A$ and $L_{\mathbb H}$, hence $L_{\mathbb H}\cdot R_{\mathbb C_{e_4}}\cong\mathbb H\otimes_{\mathbb R}\mathbb C\cong M_2(\mathbb C)$, whose commutant in $M_4(\mathbb R)$ is $R_{\mathbb C_{e_4}}=\mathrm{span}\{1,R_{e_4}\}|_Q$. On all of $S$ the commutant is certified **[EXACT]** (script C6): nullity $4$ mod $p$, and $1,\mathcal J,\omega,\omega\mathcal J$ commute exactly and are independent. $\omega|_Q=-1$ because $\omega(1)=e_4(e_8e_{12})=e_4e_4$ in the associative $Q$; $\omega|_{Q^\perp}=+1$ is **[EXACT]**. The complex structures in $\mathbb C\oplus\mathbb C$ are the four sign choices. $\square$

**Corollary 6.6 (chirality is a sign) [THM + SELECTED].** $S$ supplies, per colour component, one real Weyl-type spinor and no independent second one — that is [THM]. Whether it is "left" or "right" is the sign of the complex structure used to read it, and by 6.5(3) the sign can be chosen independently on $Q$ and on $Q^\perp$ ($\mathcal J$ versus $\omega\mathcal J$). *Handedness, blockwise,* is [SELECTED] at this stage; once the Pati–Salam $\mathfrak{so}(6)_c$ is admitted (criterion 6.11), 6.7(6) fixes the block-relative sign and only one overall sign remains.

*Interpretation. A real four-dimensional Lorentz spinor does not know its handedness; it acquires one when a complex structure is chosen, and $S$ offers exactly two candidates on each block. "Left-handed doublet, right-handed singlet" is a sentence one may write after choosing $\mathcal J$ on $Q^\perp$ and $\omega\mathcal J$ on $Q$; the algebra does not write it.*

### 6.6 The odd system: $\mathfrak{so}(1,8)$, the grading, and a hypercharge

**Theorem 6.7 [THM + EXACT].** Let $\Gamma_i=L_{e_{8+i}}$, $i=0,\dots,7$ (the odd system).

1. $\{\tau,\Gamma_0,\dots,\Gamma_7\}$ pairwise anticommute with $\tau^2=1$, $\Gamma_i^2=-1$: a $\mathrm{Cl}_{1,8}$ system. Its bivectors — $28$ skew $\Gamma_i\Gamma_j$ and $8$ symmetric $\tau\Gamma_i$ — span $\mathfrak{so}(1,8)$.
2. $\tau$ is the unique operator, up to scale, anticommuting with the whole odd system; and $\tau=\pm\Gamma_0\cdots\Gamma_7$.
3. Colour acts on the index space $\mathbb R^{1,8}=\mathbb R\tau\oplus\mathbb R\Gamma_0\oplus\mathbb R\Gamma_4\oplus W$, $W\cong\mathbb C^3$, trivially on the first three summands and by its defining representation on $W$. The centraliser of colour in $\mathfrak{so}(1,8)$ is
$$\mathfrak{so}(1,2)\oplus\mathfrak u(1)=\mathrm{span}\{A,K_1,K_2\}\oplus\mathbb R\,Y,\qquad Y:=\Gamma_1\Gamma_5+\Gamma_2\Gamma_6+\Gamma_3\Gamma_7 .$$
4. $Y^2=-9$ on a four-dimensional subspace and $-1$ on its twelve-dimensional complement; **[EXACT]** the former is $Q$, $Y|_Q=3R_{e_4}|_Q$, and $Y$ commutes with all of $\mathfrak{so}(1,3)_Q$, with $\tau$ and with colour. In the commutant of 6.5(3), $Y=\mathcal J(2-\omega)$.
5. **[STANDARD]** Under $\mathfrak{so}(6)\cong\mathfrak{su}(4)\supset\mathfrak{su}(3)\oplus\mathfrak u(1)$ the spinor $\mathbf 4$ branches as $\mathbf 3_{1}\oplus\mathbf 1_{-3}$, the $B-L$ pattern of the lepton-as-fourth-colour embedding (Pati–Salam 1974). Item 6 says with respect to which complex structure $Y$ exhibits it.
6. *The spinor complex structure.* Let $W$ be the orthogonal complement, in the odd index space $\mathrm{span}\{\Gamma_0,\dots,\Gamma_7\}\cong\mathbb O$, of the colour-fixed subspace, which is exactly $\mathrm{span}\{\Gamma_0,\Gamma_4\}$ [EXACT] (script C17); $W$ is canonical given the mediator, and $\mathfrak{so}(6)_c:=\Lambda^2W\subset\mathfrak{so}(1,8)$ is its bivector algebra. Equivalently — and this is why it is the natural object to ask about — $\mathfrak{so}(6)_c$ is the centraliser in $\mathfrak{so}(1,8)$ of $\{A,K_1,K_2\}$, the $\mathfrak{so}(1,2)$ that $\mathfrak{so}(1,3)_Q$ and $\mathfrak{so}(1,8)$ share (item 3, 7.2) [EXACT] (script C20): it is everything in the odd Lorentz algebra that commutes with the Lorentz piece colour already commutes with. (In the dictionary of Appendix C this is the Pati–Salam $\mathfrak{so}(6)\cong\mathfrak{su}(4)$; nothing below uses the name.) Colour lies inside it: every colour derivation equals its own bivector $\tfrac14\sum_{ij}(D_0)_{ij}\Gamma_i\Gamma_j$. The commutant of $\mathfrak{so}(6)_c$ is eight-dimensional with centre spanned by $1$ and
$$\omega\mathcal J=-\tau\Gamma_0\Gamma_4,$$
an operator built from the odd system and the grading alone; so $\pm\omega\mathcal J$ are the only complex structures for which $S$ is an isotypic $\mathfrak{su}(4)$-module ($\mathbf 4\oplus\mathbf 4$ or its conjugate), and $\mathcal J$ does not commute with $\mathfrak{so}(6)_c$. The complex structures commuting with $\mathfrak{so}(1,3)_Q$, colour and $\mathfrak{so}(6)_c$ together are exactly $\pm\omega\mathcal J$. Relative to $\omega\mathcal J$, $Y=-3i$ on $Q$ and $+i$ on $Q^\perp$ — the traceless branching of item 5, as an element of $\mathfrak{su}(4)$ must be; relative to $\mathcal J$ the pattern is $(3i,\,i)$, of trace $12i$, which is not a branching of the $\mathbf 4$. Finally, $\mathfrak{so}(6)_c$ does **not** commute with $\mathfrak{so}(1,3)_Q$: of the six, exactly $A,K_1,K_2$ commute with it [EXACT] (script C14), in agreement with item 3. So $S$ is a module for $\mathfrak{so}(1,3)_Q\oplus\mathrm{colour}\oplus\mathfrak u(1)_Y$ and for $\mathfrak{su}(4)$ separately, not jointly; the full Pati–Salam algebra is not a Lorentz-commuting internal symmetry of $S$.

*Proof.* (1) The $\Gamma_i$ anticommute by 2.2 (all their pure parts have $u=0$) and square to $-1$ by 2.1; $\tau$ anticommutes with each $L_{e_{8+i}}$ because $\tau$ negates $e_{8+i}$ (3.2). Bivectors of a Clifford system of signature $(1,8)$ span $\mathfrak{so}(1,8)$ (Lawson–Michelsohn 1989, I.6). (2) If $M$ anticommutes with every $\Gamma_i$ then $M\tau$ commutes with every $\Gamma_i$, i.e. lies in the commutant of the $\mathrm{Cl}_{0,8}\cong M_{16}(\mathbb R)$-module $\mathbb R^{16}$, which is the unique irreducible module and is of real type, so $M\tau\in\mathbb R$. The volume-element identity is [EXACT]. (3) By 3.2, $[D,\Gamma_i]=L_{(0,D_0e_i)}$, so colour acts on $\mathrm{span}\{\Gamma_i\}\cong\mathbb O$ through $D_0$, fixing $\Gamma_0\leftrightarrow1$ and $\Gamma_4\leftrightarrow e_4$ and acting on $W\leftrightarrow P\oplus J_0P$ as $\mathfrak{su}(3)$; it fixes $\tau$. As a colour-module, $\mathfrak{so}(1,8)\cong\Lambda^2(V_0\oplus W)=\Lambda^2V_0\oplus(V_0\otimes W)\oplus\Lambda^2W$ with $V_0$ the fixed three-space; $\Lambda^2V_0$ is invariant, $V_0\otimes W$ has no invariants, and the invariants of $\Lambda^2W=\Lambda^2_{\mathbb R}\mathbb C^3=\Lambda^{1,1}\oplus(\Lambda^{2,0}\oplus\Lambda^{0,2})_{\mathbb R}$ are the centre of $\mathfrak u(3)$, i.e. the bivector of the complex structure of $W$, which is $J_0$ on $P\oplus J_0P$, pairing $(e_1,e_5),(e_2,e_6),(e_3,e_7)$ [EXACT]; that bivector is $Y$. $\Lambda^2V_0=\mathrm{span}\{\Gamma_0\Gamma_4,\tau\Gamma_0,\tau\Gamma_4\}=\{A,K_1,K_2\}$. (4) The three summands of $Y$ commute pairwise, are skew, and square to $-1$; on $\mathbb C\otimes\mathbb R^{16}$ their joint eigenvalues are $(\varepsilon_1i,\varepsilon_2i,\varepsilon_3i)$; conjugation by $\Gamma_1$ flips $\varepsilon_1$ and fixes $\varepsilon_2,\varepsilon_3$ (it anticommutes with $\Gamma_1\Gamma_5$ and commutes with the other two), so all eight sign patterns have the same complex multiplicity, $2$. $Y$ has eigenvalue $(\varepsilon_1+\varepsilon_2+\varepsilon_3)i$: $\pm3i$ on two patterns (real dimension $4$), $\pm i$ on six (real dimension $12$). The remaining identifications are [EXACT] (script C7), including $Y=\mathcal J(2-\omega)$, which says $Y|_Q=3\mathcal J|_Q$ and $Y|_{Q^\perp}=\mathcal J|_{Q^\perp}$. (5) is the cited branching rule. (6) $\omega\mathcal J=L_4L_8L_{12}\tau L_4=\tau L_4L_8L_{12}L_4=-\tau L_8L_{12}=-\tau\Gamma_0\Gamma_4$. For colour: with $M_{jk}$ defined by $[D,\Gamma_k]=\sum_jM_{jk}\Gamma_j$ (3.2), the bivector $B=\tfrac14\sum M_{ij}\Gamma_i\Gamma_j$ satisfies the same relations, so $D-B$ commutes with the whole odd system, hence with $\mathrm{Cl}_{0,8}\cong M_{16}(\mathbb R)$, hence is a scalar, and being skew is $0$. The commutant and the two readings of $Y$ are [EXACT] (script C12); the trace statement is $\mathrm{tr}(\mathcal JY)=-24$, $\mathrm{tr}(\omega\mathcal J\,Y)=0$. $\square$

*Interpretation. The odd system carries the Lorentz algebra of a nine-dimensional spacetime, in which colour commutes with only $\mathfrak{so}(1,2)\oplus\mathfrak u(1)$ . The $\mathfrak{so}(1,3)$ that physics needs is not there; it is in 6.4, built with one operator from the even system. What the odd system does contribute is the hypercharge $Y$, whose $3:1$ pattern is not a coincidence of the algebra but the standard $B-L$ pattern of $SU(4)\supset SU(3)\times U(1)$; and $Y$ turns out to be an element of the commutant of 6.5(3), $Y=\mathcal J(2-\omega)$, a specific mixture of the two invariant complex structures. Item 6 says which of the two is the spinor's own: $\omega\mathcal J$, made from the odd system and the grading, is the $i$ of the Pati–Salam $\mathfrak{su}(4)$, and only relative to it is $Y$'s pattern the $B-L$ branching. The "$3:1$" alone is a ratio of magnitudes; the sign between the blocks is where the physics is, and $S$ fixes it once $\mathfrak{so}(6)_c$ is admitted.*

### 6.7 The commutant theorem: the two readings are exclusive

**Theorem 6.8 [THM].** No Lie algebra of operators on $S$ commutes with both $\mathfrak{so}(1,3)_Q$ and colour except subalgebras of $\mathfrak u(1)\oplus\mathfrak u(1)=\mathrm{span}\{\mathcal J,\omega\mathcal J\}$. In particular there is no $\mathfrak{su}(2)$ on $S$ commuting with both.

*Proof.* The commutant is $\mathbb C\oplus\mathbb C$ (6.5(3)), which is commutative. $\square$

**Corollary 6.9 (exclusivity of readings) [THM].** The six operators of 6.4 admit two readings: Lorentz ($\mathfrak{su}(2)_Q$ = rotations, $Q$ = a Weyl spinor, $Q^\perp$ = three) and internal ($\mathfrak{su}(2)_Q$ = an isospin, $Q$ = a doublet). They cannot both be held on $S$, because the second reading requires an additional $\mathfrak{su}(2)$ commuting with the first and with colour, and none exists. Carrying a Lorentz index and an isospin index together needs at least $32$ real dimensions ($\mathbb C\otimes S$ or $S\oplus S$). The canonical complex line $\mathbb C_e$ does not help: $S$ is a right $\mathbb C_e$-space ($R_{e_8}^2=-1$, [EXACT]), but a complex structure adds no dimensions. *Which reading* is [STANCE].

**6.10 [SELECTED] The real form.** $\mathfrak{so}(1,3)_Q$ is a real form of $\mathfrak{sl}(2,\mathbb C)$ chosen by a complex structure; the candidates are $\pm\mathcal J$ and $\pm\omega\mathcal J$ (6.5(3)). If the Pati–Salam $\mathfrak{so}(6)_c$ is admitted (criterion 6.11), 6.7(6) removes the block-relative sign: the structure is $\pm\omega\mathcal J$, and what remains selected is the overall sign — $\mathbf 4$ versus $\bar{\mathbf 4}$, particle versus antiparticle. The boost direction within each $\mathfrak{so}(1,2)\subset\mathfrak{so}(1,3)$ and the sign of $\tau$ (hence of every $K_i$) are two further binary selections; the algebra supplies the pairs, not the members.

**6.11 [CRITERION] The spinor complex structure.** $S$ supplies two invariant complex-structure pairs on itself, $\pm\mathcal J$ and $\pm\omega\mathcal J$ (6.5(3)), and distinguishes them without ranking them. This paper prefers $\pm\omega\mathcal J$ wherever a single structure carries the module identifications of §§6.6–6.7 and §12, on the grounds of 6.7(6): $\omega\mathcal J$ is built from the odd system and the grading alone, and it is the unique pair for which $S$ is an isotypic $\mathfrak{so}(6)_c$-module — $\mathfrak{so}(6)_c$ being itself canonical given a world and a mediator, the centraliser in $\mathfrak{so}(1,8)$ of the $\mathfrak{so}(1,2)$ that colour already commutes with. Admitting $\mathfrak{so}(6)_c$ as the algebra the structure must serve is the adopted preference. The criterion is scoped: $\mathcal J$ remains the structure of the skeleton of §10, which is insensitive to the choice (10.2(3)), and the quantisations of §§7–8 name their structures explicitly; 8.7 compares the two without preferring either. What consumes the criterion is named in the ledger: 6.6, 6.10, 12.1, 12.4.

**Theorem 6.12 (the vacuum of the presentation) [THM + EXACT].** Let $V_E=\mathrm{span}\{L_{e_1},\dots,L_{e_8}\}\subset\mathrm{End}(S)$ be the space of even Clifford generators (2.10), with the Euclidean structure in which they are orthonormal. Colour acts on $V_E$ by commutators, $X\mapsto[D,X]$, and preserves it (3.2).

1. The colour-fixed subspace of $V_E$ is exactly $\mathrm{span}\{L_{e_4},L_{e_8}\}$; on its orthogonal complement $W_E$ colour acts by its irreducible six-dimensional real representation, which is of complex type. Hence (Schur) the commutant of colour in $\mathrm{End}(V_E)$ is $\mathrm{End}(\mathbb R^2)\oplus\mathbb C$, and $W_E$ carries **exactly two** complex structures commuting with colour, $\pm J_W$; they are $L_x\mapsto\pm L_{e_4x}$. The fixed plane carries exactly two complex structures, its two orientations. So a colour-invariant complex structure $J$ on the generator space is determined up to two signs, and no basis enters.
2. For any such $J$, the operators $a(v)=\tfrac12(L_v+iL_{Jv})$, $v\in V_E$, satisfy the CAR of four fermionic modes on $S\otimes\mathbb C$, and the vacuum — the line annihilated by all $a(v)$ — is canonical given $J$. For the four sign choices the vacua are, up to conjugation, the two real planes
$$(1-e_8)\,\mathbb C_{e_4}\quad\text{and}\quad(1+e_8)\,\mathbb C_{e_4},$$
both inside the singlet block $Q$, exchanged by $\tau$.

*Proof.* [EXACT] (script C21): the fixed plane, the dimension $6$ of the commutant, the identification of the $W_E$-part with $\mathrm{span}\{1,J_W\}$, the basis-free vacuum condition $(L_v+iL_{Jv})\Omega=0$ for all $v\in V_E$, and the four resulting planes. The uniqueness in (1) is Schur's lemma: a complex structure in $\mathrm{span}\{1,J_W\}$ is $a+bJ_W$ with $a=0$, $b=\pm1$. $\square$

*Interpretation. Read $S$ as the Fock space of its own generators. The generators do not carry labels; they carry the action of colour, and that action pairs them — it fixes two, and on the other six admits exactly one complex structure up to sign. The vacuum this defines is not somewhere in the sixteen dimensions but in the singlet block, along $1\mp e_8$ and its $\mathbb C_{e_4}$-multiples. The phrase "$e_8$ in the role of $1$" is a mnemonic for the fact that $L_{e_4}$ and $L_{e_8}$ are the two generators colour leaves alone; the theorem uses the fact and not the mnemonic. This is the second canonical state $S$ supplies given a mediator (with $1\in Q$, 10.2(4)), and the first that is a vacuum in any sense.*

**Theorem 6.13 (where the three-space is) [THM + EXACT].** Given a mediator, the colour-fixed subspace of $\mathbb O$ is $\mathrm{span}\{1,e_4\}$, and colour acts on the remaining six dimensions of $\mathrm{Im}\,\mathbb O$ as one complex three-space $\mathbb C^3$, mixing any real form $P$ with its partner $X=Pe_4$: no colour-invariant real three-space lies in $\mathrm{Im}\,\mathbb O$. The three-space rotated by $\mathfrak{su}(2)_Q$ — its adjoint, the Bloch directions of 6.3 — is $\mathrm{Im}\,Q=\mathrm{span}\{e_4,e_8,e_{12}\}$ (on $Q$, $A=L_{e_4}$, $B=L_{e_{12}}$, $C=-L_{e_8}$), which is colour-blind and has **one direction in the world and two in the shadow**. The shadow itself is the isometric image of the world under $R_{e_8}$, with $1\mapsto e_8$.

*Proof.* [EXACT] (script: colour-fixed subspace of $\mathbb O$; non-invariance of $P$ and $X$; the identification of $A,B,C$ on $Q$; $R_{e_8}$ on $\mathbb O$). $\square$

*Interpretation. The seven imaginary dimensions of the world are, given a mediator, colour space; the colour-blind three-space that spin rotates is not inside them but straddles world and shadow. The R-flux coordinates $X$ of 4.7 are a real three-space emergent from the Fano geometry, and they are coloured. The doubling from $\mathbb O$ to $S$ is what first produces a three-space that colour does not touch.*

*Interpretation. Every entry of this section is the conclusion of a two-line argument whose inputs are visible: a world, a mediator, and the four identities of §1.1. The reader who disputes the physics is disputing 6.0 and 6.10, not the mathematics between them.*

---

## 7. The seed of dynamics

### 7.1 The symplectic criterion

**Theorem 7.1 [THM].** Let $J$ be an orthogonal complex structure on a Euclidean space $V$ and $\sigma_J(x,y)=\langle x,Jy\rangle$. Then $X\in\mathfrak{sp}(\sigma_J)$ iff $X^{\!\top}J+JX=0$. Hence a skew $X$ (a rotation) is symplectic iff $[X,J]=0$, and a symmetric $X$ (a boost or squeeze) iff $\{X,J\}=0$.

*Proof.* $\sigma_J(Xx,y)+\sigma_J(x,Xy)=\langle x,(X^{\!\top}J+JX)y\rangle$. $\square$

*Interpretation. Quantisation is the choice of $J$. The theorem says which pieces of a Lie algebra of the presentation survive it: exactly those that respect $J$ in the sense appropriate to their symmetry type. This turns "does Lorentz survive quantisation?" into commutation relations, which §§7.3–7.5 settle.*

### 7.2 Squeezes

**Theorem 7.2 [THM].** The Lie algebras generated by bivectors of the Clifford cliques of §2 ($\mathfrak{so}(8)$ for the eights, $\mathfrak{so}(3)$ for the triples) consist of skew operators and generate compact groups. The symmetric generators of §6 — $\tau\Gamma_i$, $K_1,K_2,K_3$, and the odd Clifford volume $\omega$ — are involutions, and $e^{tX}=\cosh t+X\sinh t$ is hyperbolic, with eigenvalues $e^{\pm t}$ on the $\pm1$ eigenspaces. The eight $\tau\Gamma_i$ are the boosts of $\mathfrak{so}(1,8)$ (6.7); $K_1,K_2$ are among them and $K_3=\tau\omega$ is a boost of $\mathfrak{so}(1,3)_Q$ that is not in $\mathfrak{so}(1,8)$.

*Proof.* Bivectors of anticommuting skew operators are skew (6.3). A symmetric involution $X$ has $e^{tX}=\cosh t+X\sinh t$. $\tau\Gamma_i$ is symmetric because $\tau$ and $\Gamma_i$ anticommute; $K_1=\tau\Gamma_0$, $K_2=\tau\Gamma_4$. That $K_3\notin\mathfrak{so}(1,8)$: $K_3$ commutes with colour, so if it lay in $\mathfrak{so}(1,8)$ it would lie in the centraliser $\mathrm{span}\{A,K_1,K_2,Y\}$ of 6.7(3); being symmetric it would be a combination of $K_1,K_2$, contradicting the linear independence of $K_1,K_2,K_3$ (6.4). The same argument with skewness shows $B,C\notin\mathfrak{so}(1,8)$ (a combination of $A$ and $Y$ commutes with $A$, while $[B,A]=-2C\ne0$), so $\mathfrak{so}(1,3)_Q\cap\mathfrak{so}(1,8)=\mathrm{span}\{A,K_1,K_2\}$. **[EXACT]** (script C7): adjoining any of $B$, $C$, $K_3$ to the $36$ bivectors raises the rank from $36$ to $37$; adjoining $A$ does not. $\square$

### 7.3 Lorentz survives quantisation on the singlet block

**Theorem 7.3 [THM].** On $Q$: $\mathcal J|_Q=R_{e_4}|_Q$, $\mathfrak{su}(2)_Q|_Q=L_{\mathrm{Im}\,Q}$, and the boosts are $R_{e_4}L_{\mathrm{Im}\,Q}$ up to sign. Let $J_\theta:=R_{\cos\theta\,e_8+\sin\theta\,e_{12}}|_Q$. Then for every $\theta$, $J_\theta$ is an orthogonal complex structure on $Q$ and $\mathfrak{so}(1,3)_Q|_Q\subset\mathfrak{sp}(\sigma_{J_\theta})$. Conversely, an orthogonal complex structure $J$ on $Q$ with $\mathfrak{so}(1,3)_Q|_Q\subset\mathfrak{sp}(\sigma_J)$ is one of the $J_\theta$. The member $J_e:=R_{e_8}|_Q$ is canonical up to sign: it is the right action of the canonical unit of 3.3, and $\tau$, which fixes the world and the mediator, carries it to $-J_e$ — the sign is the selection of 6.10.

*Proof.* $Q\cong\mathbb H$ is associative, so $R_x$ commutes with every $L_y$ on $Q$, and $R_xR_y=R_{yx}$. $R_{e_8}$ and $R_{e_{12}}$ commute with $L_{\mathrm{Im}\,Q}$ (the rotations) and anticommute with $R_{e_4}$ because $e_4e_8=-e_8e_4$, $e_4e_{12}=-e_{12}e_4$; hence they anticommute with the boosts $R_{e_4}L_y$. By 7.1 the rotations and the boosts are symplectic. Conversely, $J$ must commute with $L_{\mathrm{Im}\,Q}$, so $J\in\mathrm{End}_{\mathbb H}(\mathbb H)=R_{\mathbb H}$, $J=R_q$ with $q$ a unit imaginary; anticommuting with $R_{e_4}$ forces $q\perp e_4$, i.e. $q=\cos\theta\,e_8+\sin\theta\,e_{12}$. $\square$

**[EXACT]** (script C6): on $Q$, $R_{e_8}$ and $R_{e_{12}}$ commute with $A,B,C$ and anticommute with $K_1,K_2,K_3$.

### 7.4 It does not survive on the coloured block without breaking colour

**Theorem 7.4 [THM + EXACT].** Every orthogonal complex structure on $Q^\perp$ that commutes with $\mathfrak{su}(2)_Q$ and with colour is $\pm\mathcal J|_{Q^\perp}$. For these, no boost of $\mathfrak{so}(1,3)_Q$ is symplectic. Hence there is no quantisation of $Q^\perp$ that keeps the rotations, keeps colour, and keeps the boosts.

*Proof.* The commutant of $\mathfrak{su}(2)_Q\oplus\mathrm{colour}$ on $S$ is certified [EXACT] (script C6) to be six-dimensional, with exhibited basis $1_Q,R_{e_4}|_Q,R_{e_8}|_Q,R_{e_{12}}|_Q,1_{Q^\perp},\mathcal J|_{Q^\perp}$; its restriction to $Q^\perp$ is $\mathrm{span}\{1,\mathcal J\}$, whose complex structures are $\pm\mathcal J$. The boosts are $\mathcal J\cdot$(rotations) and commute with $\mathcal J$, so by 7.1 they are not symplectic. $\square$

### 7.5 Quantising with a rotation

**Theorem 7.5 [THM + EXACT].** For $J$ in the sphere $\{aA+bB+cC:a^2+b^2+c^2=1\}$ of 6.3, and for $J_0=-L_{e_4}$, the symplectic part of $\mathfrak{so}(1,3)_Q$ is $\mathfrak{so}(1,2)\cong\mathfrak{sl}(2,\mathbb R)$. For $J$ in the sphere it consists of $J$ itself and the two boosts $\mathcal J\cdot$(rotations orthogonal to $J$); for $J=A$, and likewise for $J_0$, these are $A,K_1,K_2$ [EXACT]; the general point of the sphere follows by conjugation with $\exp\mathfrak{su}(2)_Q$, which preserves $\mathfrak{so}(1,3)_Q$ and acts transitively on the sphere.

*Proof.* For $J=A$: $B,C$ anticommute with $A$ (not symplectic), $A$ commutes ($\checkmark$); $\mathcal JB,\mathcal JC$ anticommute with $A$ since $\mathcal J$ commutes and $B,C$ anticommute ($\checkmark$); $\mathcal JA$ commutes (not). $\square$

*Interpretation. Two regimes. Quantise the singlet block with the canonical $J_e=R_{e_8}$ — the right action of the one direction $S$ singles out — and the full Lorentz algebra survives. Quantise any block with a rotation, and only a $(1+2)$-dimensional Lorentz algebra survives; quantise the coloured block with anything that keeps colour, and no boost survives. The first regime is the more interesting one, because the operator that makes it work is canonical.*

### 7.6 Finite-mode no-go, and the canonical squeeze

**Theorem 7.6 [THM].** Let $(V,\sigma_J)$ be a finite-dimensional symplectic space, $\mathcal H$ its Fock representation, and $X\in\mathfrak{sp}(\sigma_J)$ symmetric with respect to the Euclidean structure and invertible (a boost or squeeze; every boost of §6 is an involution, hence invertible). Let $U(t)=e^{itH}$ be the metaplectic implementation of $e^{tX}$. Then $H$ has purely absolutely continuous spectrum; there is no eigenvector, no invariant density matrix, and no Gibbs state $e^{-\beta H}/\mathrm{Tr}\,e^{-\beta H}$ for any $\beta\ne0$.

*Proof.* $X$ symmetric with $XJ=-JX$ is diagonalisable with eigenvalues $\pm\lambda_k$, and $J$ maps the $\lambda_k$-eigenspace onto the $-\lambda_k$-eigenspace; $E_+:=\bigoplus_{\lambda>0}E_\lambda$ is Lagrangian (isotropic because $JE_+=E_-\perp E_+$, and of half dimension because $X$ is invertible). In the Schrödinger realisation on $L^2(E_+)$, $e^{tX}$ acts by $x_k\mapsto e^{\lambda_kt}x_k$, so $H=\sum_k\lambda_k\cdot\tfrac12(x_kp_k+p_kx_k)$, a sum of commuting dilation generators, each unitarily equivalent by the Mellin transform to multiplication by the coordinate on $L^2(\mathbb R)\oplus L^2(\mathbb R)$ (Folland 1989, Ch. 4). Its spectrum is absolutely continuous, so it has no eigenvectors; an invariant density matrix would have finite-dimensional $H$-invariant eigenspaces, hence eigenvectors of $H$; and $e^{-\beta H}$ is not compact, let alone trace class. $\square$

**Remark 7.8 (what a domain wall would select) [THM + EXACT].** Each boost is a symmetric involution commuting with colour, so it splits every colour-isotypic block into two eigenspaces of equal dimension: $K_1=\tau L_{e_8}$ splits $Q^\perp$ into a $+1$ and a $-1$ eigenspace of dimension $6$ each, both colour triplets, and $\tau$ exchanges them since $\tau K_1\tau=-K_1$. A Jackiw–Rebbi construction — a first-order operator along a scale coordinate with $K_1$ as a mass term whose sign changes across a wall — would localise normalisable zero modes on exactly one of the two triplets, and the grading would map the wall's modes to the anti-wall's. This is the kinematic content of a domain-wall triplet; the wall itself is a Hamiltonian, i.e. inserted dynamics, and belongs with boundary (b), not here.

**Theorem 7.9 (the canonical squeeze, the seam, and the failure disk) [THM + EXACT].**

1. $K_1=\tau L_{e_8}$ is built from the two canonical objects of §3 alone, so it is canonical up to sign given a world, with no mediator; it commutes with $G_2$. It preserves the doubly-pure subspace $S^{pp}=\{a_0=b_0=0\}$, on which it is the swap $(u,w)\mapsto(w,u)$, and it maps the seam $Z$ to itself.
2. Along its flow every seam point moves off the seam radially in the background disk of 3.6: with $\|u\|^2=\|w\|^2=n$, the image of $(u,w)$ under $e^{tK_1}$ has $N=2n\cosh2t$, $\beta=2n$, hence failure index $\beta/N=1/\cosh2t$ and disk coordinate $|Q|=\tanh2t$; the three bands of the tunnel lemma are $4n\sinh^2t$, $2n\cosh2t$, $4n\cosh^2t$. The flow is $G_2$-equivariant and therefore descends to the radial flow of the disk: the seam is $t=0$, the alternative rim is $t=\infty$, and **the rapidity of the canonical squeeze measures the failure of multiplication exactly: $\beta/N=\operatorname{sech}2t$ and $|Q|=\tanh2t$, each strictly monotone in the rapidity for $t\ge0$**.
3. The mediator-dependent boosts behave differently: $K_2=\tau L_{e_{12}}$ moves the mediator-orthogonal part of the seam along the seam and carries mediator-aligned seam points out of $S^{pp}$; $K_3$ acts like $K_1$ on the mediator-orthogonal part.
4. All six generators of $\mathfrak{so}(1,3)_Q$ are traceless, so the group they generate is unimodular on $S$ and its pullback (Koopman) action on $L^2(S)$ is **unitary**, boosts included; the boost generators there have continuous spectrum, and $S$ sits inside as the non-normalisable linear functionals $x\mapsto\langle\xi,x\rangle$, on which the action is the squeeze — exactly the configuration Corollary 8.8 says any unitary realisation must have.
5. $K_1$ is symplectic for the canonical form $\sigma_e$ (8.4), so $\dot x=K_1x$ is a *classical Hamiltonian flow* on the canonical symplectic space $(S,\sigma_e)$, with Hamiltonian the quadratic form $H(x)=\tfrac12\langle x,K_1R_{e_8}x\rangle$; $K_1R_{e_8}$ is a symmetric traceless involution, so $H$ has signature $(8,8)$ — an inverted-oscillator pair on every mode, with no minimum. This is the classical content of the seed: a Hamiltonian, but not one with a ground state, which is why its quantisation (7.6) has no invariant state and why a state must come from elsewhere.
6. The orbit of the canonical flow through a seam point $(u,w)$ is the $e_8$-diameter of the background disk: $Q(t)=\tanh(2t)\,e_8$, running from the alternative element $(u-w,-(u-w))$ at $t=-\infty$ through the seam at $t=0$ to the alternative element $(u+w,u+w)$ at $t=+\infty$; $\tau$ reverses the parameter and maps the orbit of $(u,w)$ to that of $(u,-w)$. The non-associative content along the flow is therefore **transient**: it is maximal at the seam and decays as $\operatorname{sech}2t$ in both directions, the flow being eternal and reversible while what it carries is not [EXACT].
7. In the cotangent coordinates of the world (3.7(iv): $x_i=a_i$, $p_i=-b_i$), $K_1R_{e_8}$ is diagonal and the Hamiltonian of (5) reads
$$H=\sum_{i=1}^{7}\tfrac12\big(x_i^2-p_i^2\big)-\tfrac12\big(x_0^2-p_0^2\big)\qquad[\text{EXACT}],$$
a sum of eight inverted oscillators with signature $(7,1)$, the real direction of the world carrying the opposite sign. Each $\tfrac12(x^2-p^2)$ is unitarily equivalent, by the $45^\circ$ symplectic rotation, to the dilation generator $\tfrac12(xp+px)$; so on $L^2(\mathbb O)$ the canonical squeeze is $\sum_{i=1}^7D_i-D_0$, seven Berry–Keating–Connes "$xp$" Hamiltonians minus one. The flow exchanges position and momentum up to conjugation, $K_1(a,b)=(-\bar b,-\bar a)$.

*Proof.* (1) $L_{e_8}(u,w)=(w,-u)$ from Definition 0.1 and $\tau$ negates the second half; $\tau$ and $e_8$ are canonical by 4.4(ii) and 3.3; $[D,\tau]=0$ and $De_8=0$. (2) $e^{tK_1}(u,w)=(cu+sw,\,cw+su)$ with $c=\cosh t$, $s=\sinh t$; then $\|u'\|^2=\|w'\|^2=(c^2+s^2)n$, $\langle u',w'\rangle=2csn$, so $\|u'\wedge w'\|^2=(c^2-s^2)^2n^2=n^2$ and $N'=2(c^2+s^2)n=2n\cosh2t$; Theorem 3.6 gives $|Q|$. (3) and the exact instances of (1)–(2) are [EXACT] (script C22). (4) Traces are [EXACT]; a volume-preserving linear flow acts unitarily on $L^2$ by pullback; a hyperbolic linear flow on $L^2(\mathbb R^m)$ has Lebesgue spectrum. $\square$

*Interpretation. What this theorem supplies must be stated exactly, because it is easy to overread: a canonical generator, a canonical carrier, a canonical classical Hamiltonian of indefinite signature, and a canonical flow on the orbit space. It does not supply a dynamics in the physical sense — an algebra of observables with a state the flow preserves or makes thermal — and K3a is not answered by it. The seed of dynamics has, after all, a canonical member and a canonical meaning. $K_1$ needs only the world; its flow is the one-parameter motion from the seam to the alternative rim, and its rapidity measures the degree to which multiplication fails, $\beta/N=\operatorname{sech}2t$. Read as a stance, the scale line is the radius of the failure disk, and "time is the grading" has this exact form: the grading times the canonical unit is the generator whose parameter fixes the failure index. And the carrier that Corollary 8.8 demanded — infinite-dimensional, unitary boosts, continuous spectrum, no invariant finite piece — is not a field theory to be built; it is $L^2(S)$, functions on $S$ itself. What is still absent is an algebra and a state — and by (7) the problem of supplying them is the problem that has been open for the $xp$ Hamiltonian since Berry–Keating and Connes: a self-adjoint realisation with the right spectral and thermal structure. That is a known wall, not a new one, and $S$ arrives at it with a definite signature $(7,1)$ and a definite conjugation $\tau$.*

**7.7 [BOUNDARY].** The presentation supplies squeezes (7.2), decides exactly which of them survive each quantisation (7.3–7.5), and proves that no state on finitely many modes is invariant under any of them (7.6); §8.6–8.8 sharpen this to: no squeeze is unitarisable, and no carrier containing $S$ as an invariant piece can turn a squeeze into a modular flow. It supplies a canonical squeeze and its classical Hamiltonian, up to sign (7.9); it does not supply the sign, a temperature, a state, or a Hamiltonian with a ground state. Its one non-compact continuum is the zero-divisor cone $\mathbb R_+\times G_2/SU(2)$ of 3.5, and whether a squeeze-invariant state exists on functions over that cone — the angular part being the branching of $L^2(G_2/SU(2))$ under $SU(2)$, the radial part the dilation generator on $L^2(\mathbb R_+,dr/r)$ — is the question K3a, [OPEN].

*Interpretation. "The seed of dynamics" is now three theorems and a boundary. The seed is real: hyperbolic one-parameter groups exist, come from the grading, and are exactly the boosts. The boundary is equally real: nothing in $S$ converts a boost into a flow of states on a finite Fock space, and a thermal reading — whatever its merits — must live on the infinite-dimensional cone, where the algebra has not yet been asked.*

---

## 8. Representation

**8.1 [THM].** The presentation is the regular bi-representation $x\mapsto(L_x,R_x)$ of $S$ on itself; it is not chosen.

**8.2 [STANDARD + THM].** By 3.7, $S$ is canonically — up to sign — a symplectic space $(S,\sigma_e)$. Its CCR algebra has, up to unitary equivalence, a unique irreducible representation (Stone–von Neumann): the Fock space $\mathcal F_e$ of eight modes, the sign ambiguity being complex conjugation of the Fock structure; by 3.7(iv) it is also realised as $L^2(\mathbb O)$, functions on the world, with the shadow acting by differentiation. Given the passage to a CCR (or CAR, 12.2) algebra, the representation is therefore a theorem of $S$, not a choice; a different complex structure $J$ is chosen only when one wants $J$ adapted to a *selected* Lorentz structure (7.3–7.5). The passage itself — forming the Weyl or Clifford algebra of the one-particle space to obtain composites — is **[CRITERION]**: it is the standard way to make many-particle states from a one-particle space, adopted here; what $S$ forces is the one-particle symplectic and Hilbert structure (3.7). §13 shows that $S$ also has a *native* composite, its own doubling, with different content. $S$ has no tensor product; composite systems appear only here, as many-particle states.

**8.3 (one-particle implementation) [THM].** A linear $X$ on $S$ has a Bogoliubov implementation on the Fock space of $\sigma_J$ iff $X\in\mathfrak{sp}(\sigma_J)$; this is 7.1 applied to 7.3–7.5:

| quantisation | implemented part of $\mathfrak{so}(1,3)_Q$ | colour |
|---|---|---|
| $J=A$ (or $J_0=-L_{e_4}$) on $S$ | $\{A,K_1,K_2\}\cong\mathfrak{so}(1,2)$ | kept |
| $J=\pm\mathcal J$ or $\pm\omega\mathcal J$ on $S$ | rotations only | kept |
| canonical $J_e=R_{e_8}$ on $S$ | all six on $Q$; $\{C,K_1,K_3\}\cong\mathfrak{so}(1,2)$ on $Q^\perp$ | kept |
| any colour-invariant $J$ on $Q^\perp$ | rotations only | kept |

**Theorem 8.4 (the canonical quantisation) [THM + EXACT].** On the canonical Fock space $\mathcal F_e$ of 8.2: (i) $G_2\times\langle\mu\rangle$ acts symplectically and is implemented unitarily (metaplectic representation); $\tau$ acts anti-symplectically and is implemented antiunitarily (Wigner), and its implementer fixes the Fock vacuum $\Omega_e$. The vacuum state $\omega_e(W(f))=e^{-\|f\|^2/4}$ is invariant under all of $\mathrm{Aut}(S)$, $\tau$ acting antilinearly. (ii) Given a world and a mediator, colour is implemented; on $Q$ the whole of $\mathfrak{so}(1,3)_Q$ is implemented (7.3); on $Q^\perp$ exactly the subalgebra $\mathrm{span}\{C,K_1,K_3\}\cong\mathfrak{so}(1,2)$ is; no bivector of either $\mathrm{Cl}(0,8)$ system is symplectic for $\sigma_e$, and of the eight boosts $\tau\Gamma_i$ exactly $\tau\Gamma_0=K_1$ is.

*Proof.* (i) is 3.7(ii)–(iii) with the metaplectic representation and Wigner's theorem (Bargmann 1964); an antiunitary of the one-particle space second-quantises to an antiunitary fixing $\Omega_e$, and $\omega_e$ depends on $f$ only through $\|f\|$, which every automorphism preserves (3.2). (ii) Colour commutes with $R_{e_8}$ by 3.2 since $De_8=0$. The rest is [EXACT] (script C11), including the brackets $[C,K_1]=2K_3$, $[C,K_3]=-2K_1$, $[K_1,K_3]=-2C$. $\square$

**Theorem 8.6 (no finite-dimensional modular dynamics from the seed) [THM + EXACT].**

1. Every squeeze of §7 is $e^{tX}$ with $X$ a symmetric involution of trace zero, so $e^{tX}$ has eigenvalues $e^{t}$ and $e^{-t}$, each of multiplicity $8$. A unitary operator has eigenvalues of modulus one. Hence no squeeze is unitary for any Hilbert structure on $S$, real or complex, and the same holds on every finite-dimensional space to which it is extended by a direct sum.
2. Consequently, for every complex structure $J$ on $S$, a boost is at most one of: $J$-linear, $J$-symplectic. It is never both, since $J$-linear and $\sigma_J$-symplectic together mean $J$-unitary.
3. A modular group $\Delta^{it}$ is unitary — on the one-particle space in the standard-subspace formulation of Tomita–Takesaki theory (Rieffel–van Daele 1977; Longo 2008), and on the GNS space in general. Hence no squeeze is the modular flow of any standard subspace of $(S,J_e)$, nor of any quasi-free state on the CCR algebra of $S$ (whose GNS modular group acts on the finite-dimensional purified one-particle space); and by 7.6 no squeeze is the modular group $\mathrm{Ad}(\rho^{it})$ of a faithful normal state on the Fock algebra. The seed cannot become modular dynamics on any finite-dimensional carrier.
4. $\tau$ is an antiunitary involution of $(S,J_e)$ fixing $\Omega_e$; it is the modular conjugation $J_H$ of every standard subspace $H\subset(S,J_e)$ whose modular operator $\Delta_H=e^{K}$ has $\tau K\tau=-K$. The $J_e$-linear operators commuting with $\tau$ form a $64$-dimensional space [EXACT], so this family of standard subspaces has $32$ real parameters and no canonical member.

*Proof.* (1)–(2) as stated; the trace and involution properties are [EXACT] (script C13). (3) is (1) with the cited unitarity. (4) is 8.4(i) and the standard-subspace correspondence $H\leftrightarrow(J_H,\Delta_H)$ with $J_H\Delta_HJ_H=\Delta_H^{-1}$. $\square$

**Corollary 8.8 (where the flow must live) [THM].** Let $U(t)$ be a unitary one-parameter group on a Hilbert space $\mathcal H$ of any dimension, $X$ a squeeze of $S$, and $V\subseteq S$ a nonzero $e^{tX}$-invariant subspace. There is no nonzero real-linear map $\iota:V\to\mathcal H$ with $U(t)\iota=\iota\,e^{tX}|_V$. Hence a squeeze of $S$ can be realised as a unitary — in particular as a modular — flow only on a carrier in which no mode of $S$ is carried along the flow: $U$ has no finite-dimensional invariant subspace on which it is conjugate to the squeeze, and its generator has no eigenvector realising a squeeze eigenvalue. In Bisognano–Wichmann the boost generator has spectrum $\mathbb R$ on an infinite-dimensional one-particle space; that is the minimum any construction on the cone (K3a) must reproduce, and by 8.6(4) it must place $\tau$ in the seat of the modular conjugation.

*Proof.* $\iota(V)$ would be a finite-dimensional $U$-invariant subspace on which $U(t)$ is unitary for the restricted inner product, hence has eigenvalues of modulus one, yet is conjugate to $e^{tX}|_V$, which has an eigenvalue $e^{\pm t}$ ($V$ meets at least one of the $\pm1$ eigenspaces of $X$, since $V$ is $X$-invariant). $\square$

*Interpretation. This is the precise reason Bisognano–Wichmann's identification of a modular flow with a boost needs a quantum field: a boost is unitary on a one-particle space only if that space is infinite-dimensional and the boost mixes every mode with infinitely many others. $S$ has the boost and the antiunitary involution in the right places, and cannot have the flow; 8.8 says that no carrier in which $S$ sits as an invariant piece can have it either. That forbids every shortcut through finitely many modes, and states in one line why K3a is the only place left.*

**Theorem 8.7 (the two complex structures) [THM + EXACT].** The canonical structure $J_e=R_{e_8}$ and the Lorentz-adapted structure $\omega\mathcal J$ satisfy
$$[R_{e_8},\omega\mathcal J]=-2R_{e_{12}}P_Q ,$$
where $P_Q$ is the orthogonal projection onto $Q$. They commute on $Q^\perp$, where $R_{e_8}\omega\mathcal J$ is a symmetric involution splitting $Q^\perp=V_+\oplus V_-$ into two six-dimensional colour-invariant subspaces with $R_{e_8}=+\omega\mathcal J$ on $V_+$ and $-\omega\mathcal J$ on $V_-$; the rotation $C$ preserves $V_\pm$, the boosts $K_1,K_3$ exchange them, and $A,B$ preserve neither. On $Q$ the two structures do not commute. No complex structure on $S$ makes $\mathfrak{so}(1,3)_Q$ both linear and symplectic (8.6(2)): $R_{e_8}$ is the one for which $\mathfrak{so}(1,3)_Q$ is symplectic on $Q$ (7.3), $\omega\mathcal J$ the one for which $\mathfrak{so}(1,3)_Q\oplus\mathrm{colour}\oplus\mathfrak{so}(6)_c$ is linear (6.7(6)).

*Proof.* On $Q$, $\omega\mathcal J=-R_{e_4}$ and $[R_{e_8},-R_{e_4}]=-(R_{e_{12}}+R_{e_{12}})$ by associativity of $Q$; the rest is [EXACT] (script C13). $\square$

*Interpretation. The "tension" between the forced quantisation and the physically adapted complex structure is Theorem 8.6(2) made concrete: since no boost can be unitary on $S$, every complex structure must give up either implementability or linearity for the boosts, and the two natural structures give up different ones. Off the singlet block they even agree up to conjugation — the canonical quantisation reads one colour triplet as the Pati–Salam structure and the other as its conjugate, the boosts exchanging the two. Nothing on $S$ can reconcile them, and nothing should be expected to: the reconciliation is the unitary boost of a field theory, which lives on the cone.*

**Theorem 8.9 (the states $S$ supplies, and the state it does not) [THM + EXACT].** On the canonical Fock algebra of $(S,\sigma_e)$:

1. $S$ supplies pure states: the vacuum $\omega_e$ (8.4) and, given a mediator, the vector state of $1\in Q$ and the vacuum of the presentation (6.12). Pure states are not faithful and have no modular flow.
2. $S$ supplies the normalised trace on any finite-dimensional block; it is faithful and invariant under everything, and its modular flow is trivial.
3. $S$ supplies a canonical one-parameter family of **faithful states with nontrivial modular flow**: the Gibbs states $\omega_\beta=e^{-\beta N}/\mathrm{Tr}\,e^{-\beta N}$, $\beta\in(0,\infty)$, of the number operator $N=d\Gamma(1)$ of the canonical complex structure $R_{e_8}$ — canonical because $R_{e_8}$ is (3.7), positivity of $N$ fixing its sign. Their modular flow is the phase rotation $\Gamma(e^{tR_{e_8}})$: compact and periodic, with the canonical complex structure itself as generator. The temperature $\beta$ is not supplied.
4. $S$ supplies **no** state whose modular flow is a squeeze, on any finite carrier (7.6, 8.6), and its canonical compact generators other than $R_{e_8}$ do not help: the metaplectic generator of the rotation $C$ (the only member of $\mathfrak{su}(2)_Q$ symplectic for $\sigma_e$ on all of $S$, 8.4) is unbounded below, since $-R_{e_8}C$ is a symmetric involution of trace $-12$ [EXACT], so it has no Gibbs state.

So the precise sense in which "a state must be added" is this: $S$ deduces its states, their probabilities (10.3(2)), and a canonical thermal family whose time is periodic; what it cannot deduce is a temperature, and a state whose time is the seed.

*Proof.* (1)–(2) are standard. (3) $N=d\Gamma(h)$ with $h=1$ on the one-particle space; $e^{-\beta N}$ is trace class on finitely many modes; the modular group of a Gibbs state is $\mathrm{Ad}(e^{it\beta N})$, and $e^{itN}=\Gamma(e^{itR_{e_8}})$ in the real picture. (4) 7.6 and [EXACT] (script C22 block, trace of $-R_{e_8}C$). $\square$

*Interpretation. The claim that a state "cannot be deduced and must be added, like an outcome" is half true, and the half that is false is instructive. Unlike an outcome, a state is a functional, and $S$ has plenty: pure ones, the trace, and a canonical thermal family whose clock is the phase of its own complex structure. What $S$ lacks is a state whose clock is the canonical squeeze — the seed, whose rapidity fixes the failure index — and that lack is a theorem. The one datum in the thermal family that is genuinely added from outside is the temperature; in the program's terms, the temperature is where the pre-algebraic first touches the algebra without adding an outcome.*

### 8.5 Necessity: what cannot be removed from $S$

The question "is $S$ without its split, its seed of dynamics, or its representation inconsistent?" has a precise form, because an algebra cannot be inconsistent — it either determines a structure or it does not. Write $X\prec S$ if $X$ is *definable* from the product of $S$, i.e. every isomorphism of $S$ carries $X$ to $X$ (up to a stated finite ambiguity). Then "$S$ without $X$" is not $S$: any object lacking $X$ is not isomorphic to $S$. If instead $S$ determines only a family containing $X$, "$S$ without $X$" is simply $S$ before a selection.

**Theorem 8.5 (necessity) [THM].**

1. *Split.* The set of $\mathbb Z_2$-gradings of an algebra is the set of its involutive automorphisms, hence $\prec S$. For $S$ it has three conjugacy classes (4.1), and the class $\{\tau,\mu\tau\mu^{-1},\mu^2\tau\mu^{-2}\}$ is canonical (4.4(ii)): three gradings, definable as a set, permuted by $\Sigma_3$. An algebra with a different set of gradings is not $S$. Only the member is selected (4.6), and only the preference for the kind is adopted (4.5).
2. *Seed of dynamics.* The symmetric involutions $\tau\Gamma_i$ are products of two definable objects — a canonical grading and the Clifford system of its complement (4.4(i)) — hence $\prec S$ with the same $\Sigma_3$ ambiguity, and they generate with the odd bivectors the non-compact $\mathfrak{so}(1,8)$ (6.7). Any structure all of whose definable one-parameter groups are compact is not $S$. The strong reading — that $S$ carries a dynamics, a flow on states — is false, and provably: no finite-mode state is squeeze-invariant (7.6). The standard theorem that turns an algebra with a state into a dynamics is Tomita–Takesaki (the modular flow of a faithful state; Connes–Rovelli's thermal time), and it does not deliver the seed here for a definite reason: the faithful states $S$ does supply have trivial or compact modular flow — the trace and the Gibbs family of 8.9(2)–(3) — and its one canonical vector $1$ is not even separating for $\mathcal A_0$, since $\mathcal A_0\cdot1=Q$ [EXACT]. That failure is the exact content of the boundary 7.7, and 8.6 shows it is not an accident of the states at hand: no finite-dimensional carrier can turn a squeeze into a modular flow, because squeezes are not unitarisable.
3. *Representation.* At every level the representation is $\prec S$: the presentation is the product itself (0.2); the Euclidean structure (3.7(i)); the complex structure $R_{e_8}$ and the symplectic form $\sigma_e$, up to sign (3.7(ii)); the Fock representation, up to conjugation (8.2). "$S$ without its representation" is $\mathbb R^{16}$. What is *not* $\prec S$: a Lorentz-adapted complex structure ($\mathcal J$ and $\omega\mathcal J$ need a world and a mediator, and differ from $R_{e_8}$), a state, an outcome (10.3).

4. *Doubling.* The conjugation is definable from the product alone: for $x\notin\mathbb R$, $t(x)$ and $n(x)$ are the coefficients of the quadratic identity $x^2=t(x)\,x-n(x)\,1$ (3.2), and $\bar x=t(x)-x$. The doubling of Definition 0.1 applied to $S$ therefore consumes the product of $S$ and nothing else, and involves no choice; in the sense in which the Fock representation is definable — clause 3: a canonical construction, not a subset — $A_5=S\times S$ and, by iteration, every $A_n$, $n\ge4$, is $\prec S$. The invariance content is a lift: every $\sigma\in\mathrm{Aut}(S)$ commutes with conjugation (3.2), so $\hat\sigma(a,b):=(\sigma a,\sigma b)$ satisfies
$$\hat\sigma\big((a,b)(c,d)\big)=\big(\sigma a\,\sigma c-\overline{\sigma d}\,\sigma b,\;\sigma d\,\sigma a+\sigma b\,\overline{\sigma c}\big)=\hat\sigma(a,b)\,\hat\sigma(c,d),$$
and $\sigma\mapsto\hat\sigma$ is an injective homomorphism $\mathrm{Aut}(S)\to\mathrm{Aut}(A_5)$. Derivations lift as $\widehat D=D\oplus D$: $D1=0$ and skewness (3.2) give $D\bar x=-Dx=\overline{Dx}$, and Leibniz for $\widehat D$ follows by expanding the doubled product term by term. Two bounds keep the clause honest. The lift is not claimed surjective, and $\hat\mu$ is not the $\mu$ of $A_5$, which is defined through $e_{16}$: the lifted $\Sigma_3$ acts within the copies (13.7(iv)). And the same argument applies at every level: the tower is definable from each $A_n$ and, along Definition 0.1 itself, from $\mathbb R$. Definability is blind to the base point; what this clause establishes is that ascending consumes no new data, while the naming of $S$ rests where it always did — on §5 and on the stance 10.1. Likewise not $\prec S$ is a preferred level of the tower: the products of the doublings distinguish none (13.3), and which carrier is physical is [OPEN] (13.5(v)).

*Proof.* Each clause cites the theorem that proves definability or its failure; the two lift identities of clause 4 are the displayed computation and the term-by-term expansion stated there. $\square$

**[EXACT]** (script `c28_doubling.py`, block C28). *As consistency instances of Definition 0.1:* the doubling of the $S$-table, with the conjugation read off the table by the quadratic identity, reproduces the $A_5$ table entry by entry ($2\times1024$ signed entries); iterating the same doubling from $\mathbb R$ reproduces $A_1,\dots,A_6$. *As instances of clause 4:* $D\bar x=\overline{Dx}$ on $\mathbb O$ for all $21$ generators $D_{a,b}$; $\hat\tau=\tau\oplus\tau$ is an automorphism of $A_5$ and all $21$ generator lifts satisfy Leibniz, on all $1024$ basis pairs; $\hat\mu=\mu\oplus\mu$ is an automorphism of $A_5$ exactly over $\mathbb Q(\sqrt3)$, with $\hat\mu^3=1$, $\hat\mu(e_8)=e_8$, and $\hat\mu$ commuting with conjugation.

*Interpretation. The ledger's tags already encode this — [THM] means definable, [SELECTED] means a definable family with an undefinable member, [POSTULATE] means undefinable — and Theorem 8.5 collects it for the four structures the program cares about. The split and the representation are theorems of $S$ down to the finest level that makes sense (a set of three gradings; a Fock space up to conjugation). The seed of dynamics is a theorem of $S$; dynamics is not, and the theorem that would supply it (Tomita–Takesaki) is blocked: the faithful states $S$ supplies have the wrong modular flow (8.9), and no finite carrier admits one with the right flow (8.6) — which is why the only remaining route is a state on the infinite-dimensional cone (K3a). The closest existing results are: Brown and Eakin–Sathaye for (1); Stone–von Neumann and Wigner for (3); Eakin–Sathaye again for the lifts of (4); and, for (2), the non-applicability of Tomita–Takesaki, which is itself a precise statement.*

*Interpretation. Clause 4 closes in the ledger what 13.5 argued in prose: the doublings consume only $S$. It does not — and by the regress noted inside the clause cannot — promote $S$ over the other levels; that remains §5's selection principle and the charter's stance. Every consumption of a doubling in §13 is henceforth a consumption of $S$.*

*Interpretation. The old table's entry "$B,C,K_3$ cannot be implemented" was true for the quantisation it assumed. The new row is the singlet block with its canonical complex structure, where nothing is lost. What is lost there is colour, but only because colour is already trivial on $Q$.*

---

## 9. Dependency ledger

| result | consumes | tag |
|---|---|---|
| 1.1 identities | $S$ | STANDARD + EXACT |
| 1.3 bridge, 1.4–1.6 tunnel, bounds, zero divisors | $S$; 1.5 also Biss–Christensen–Dugger–Isaksen 2009 | THM (1.5 also STANDARD) |
| 1.7 twisted group algebra, $\mathbb Z_2$ cocycle | $S$ (uses the basis; canonical up to conjugacy, 3.9); Albuquerque–Majid, Flaut–Boboescu, Ren–Zhao | THM + STANDARD + EXACT |
| 2.1–2.5 pattern, cliques, generation | $S$ | THM (+EXACT) |
| 2.7–2.9 neither edges, box-kites, quaternion types | $S$ (2.8 uses the basis; canonical up to conjugacy, 3.9) | THM + EXACT (+STANDARD) |
| 2.10 the presentation is a CAR algebra | $S$ | THM |
| 6.12 the vacuum of the presentation | world, mediator | THM + EXACT |
| 3.1–3.6 symmetry, canonical objects, seam, disk | $S$ | STANDARD + THM |
| 3.7 canonical Hilbert and symplectic structure | $S$ | THM |
| 3.8 the seam bundle and its Yang–Mills connection | $S$; Laquer | THM + EXACT + STANDARD |
| 3.9 the frames of the presentation | $S$; Baez (basic triples) | THM + STANDARD + EXACT |
| 4.1–4.3 splits, capability | $S$ | THM (+STANDARD) |
| 4.4 three characterisations of the $\tau$-kind | $S$ | THM + EXACT |
| 4.7 contractions and the $(\mathbb H,\ell)$ frame | $\mathbb O$, $S$ | THM + EXACT |
| 4.5 the split-kind | $S$ + a preference (4.4(i) or (ii)) | CRITERION |
| 4.6 the world | $S$, 4.5 | SELECTED |
| 5.1–5.4 selection principle | $A_n$, exact $A_5$ data | THM + EXACT |
| 5.6 $c_n=2^{(n-3)/2}$ for all $n$ | $A_n$; base case in $S$; Biss–Christensen–Dugger–Isaksen 2009 | THM + STANDARD + EXACT |
| 6.0 the mediator | a world | SELECTED |
| 6.1 colour | world, mediator | STANDARD + THM |
| 6.2–6.4 $Q$, $\mathfrak{su}(2)_Q$, $\mathfrak{so}(1,3)_Q$ | world, mediator; 6.4 also 4.5 via 4.4(ii) | THM |
| 6.5 content; 6.6 chirality | world, mediator; 6.6 also 6.11 | THM / SELECTED |
| 6.7 $\mathfrak{so}(1,8)$, $\tau$, $Y$ | world, mediator, 4.5 via 4.4(i) | THM + EXACT + STANDARD |
| 6.8–6.9 commutant, exclusivity | world, mediator | THM |
| 6.10 real form, signs | world, mediator, 6.11 | SELECTED |
| 6.11 the spinor complex structure | 6.7(6) | CRITERION |
| 7.1–7.6 dynamics | world, mediator, a complex structure | THM |
| 7.8 what a domain wall would select | world, mediator | THM + EXACT |
| 7.9 the canonical squeeze and the failure disk | world (no mediator) | THM + EXACT |
| 7.7 | — | BOUNDARY |
| 8.2 canonical Fock representation | $S$; Stone–von Neumann | STANDARD + THM + CRITERION |
| 8.3 implementation | world, mediator, $J$ | THM |
| 8.4 canonical quantisation | $S$ (i); world, mediator (ii); 8.2 (the Fock criterion) | THM + EXACT |
| 8.5 necessity | 3.2, 4.1, 4.4, 6.7, 7.6, 3.7, 8.2, 10.3 | THM |
| 8.6 no finite-dimensional modular dynamics | $S$; Tomita–Takesaki (standard subspaces) | THM + EXACT + STANDARD |
| 8.7 the two complex structures | world, mediator, 3.7, 6.7(6) | THM + EXACT |
| 8.8 where the flow must live | 8.6 | THM |
| 8.9 the states $S$ supplies | $S$; world for (1); 8.2 (the Fock criterion) | THM + EXACT |
| 12.1 $S$ in Standard-Model terms | 6.5, 6.7, 6.11; SM content | THM + STANDARD |
| 12.2 statistics | $S$ (both canonical); 8.2 (the Fock criterion) | SELECTED |
| 12.3 the lone scalar; complexification of the state | $S$; $\mathbb C_e$; world, mediator | THM + EXACT |
| 12.4 no isospin in $S$, $\mathrm{End}(S)$, Fock$(S)$ | 6.5, 6.8, 6.11, 8.2 (the Fock criterion); plethysm | THM + EXACT |
| 12.5 the seam's $\mathfrak{su}(2)$ | 3.5; $SO(4)\subset G_2$ | THM + STANDARD |
| 12.4 table, 12.6 | all boundaries | BOUNDARY |
| 13.1 the two presentations as modules | $S$, world, mediator | THM + EXACT |
| 13.2 native action on the doublings | 13.1, the doublings $\prec S$ (8.5(4)) | THM + EXACT |
| 13.3 the product breaks the doublet | 13.2, 8.5(4) | THM + EXACT |
| 13.4 content of $A_6$ | 13.2, 8.5(4); reading | THM (+ reading) |
| 13.7 finite questions of the doublings | 13.2, 8.5(4) | THM + EXACT |
| 13.5–13.6 | — | commentary on method |
| 14.0 the continuum is native | $S$; 1.1, 1.8, 3.7, 4.7(vii), 12.3(1) | THM |
| 14.1 the modular postulate K3a | — (consumed by 14.2–14.3 only) | POSTULATE |
| 14.2 type III$_1$, uniqueness, homogeneity | 14.1; Wiesbrock, Araki–Zsidó, Haagerup, Connes–Størmer | THM + STANDARD |
| 14.3, 14.4 | 13.5, 14.1 | BOUNDARY / STANCE |
| 10.1 charter | — | STANCE |
| 10.2 the skeleton | criterion, selections, $\mathcal J$ | THM + EXACT |
| 10.3 the hollow | 10.2; Gleason, Kochen–Specker, Bell; 8.2 (the Fock criterion) for (3c) | THM + STANDARD |
| 10.4 settlement | a probability space added to $S$ | POSTULATE |
| 10.5 | — | BOUNDARY |
| 10.6 generations, seam, time | — | STANCE |

Nothing tagged THM in §§1–5 consumes anything but $S$ (and $A_n$ in §5). Nothing tagged THM in §§6–8 and §10 consumes anything but the criteria 4.5, 6.11 and 8.2, the two selections 4.6 and 6.0 and, in §§7–8 and §10, a complex structure. No THM consumes a POSTULATE or a STANCE.

---

## 10. Postulates and stances

The charter comes last, because a charter is not something $S$ forces.

**10.1 [STANCE] The charter.** *$S$ with its presentation is the only ontological primitive; physics is what the presentation forces, offers, or forbids; forced structure is physics, offered structure is a family, forbidden structure is a prediction.* Nothing above uses this sentence. It is the reason the ledger exists.

### 10.2 The skeleton and the hollow

Fix the criterion 4.5, the selections 4.6, 6.0 and 6.10, and the complex structure $\mathcal J$, so that $(S,\mathcal J)\cong\mathbb C^8$ with $Q\cong\mathbb C^2$ and $Q^\perp\cong\mathbb C^3\otimes M$, $M\cong\mathbb C^2$ the multiplicity space of 6.5(2). An operator is *$\mathcal J$-linear* if it commutes with $\mathcal J$ and *colour-singlet* if it commutes with colour; an *event* is a $\mathcal J$-linear orthogonal projection, a *context* a maximal commuting set of $\mathcal J$-Hermitian operators. The question of this subsection is: given all of this, what does $S$ contain, and what does it provably not contain?

**Theorem 10.2 (the skeleton) [THM + EXACT].**

1. Every $\mathcal J$-linear operator on $S$ — hence every observable, event and context of $\mathbb C^8$ — lies in the associative algebra generated by the presentation. This is completeness, not structure: by 2.5 that algebra is all of $\mathrm{End}(\mathbb R^{16})$, so nothing is excluded at this level, and the clause's role is to exhaust the algebraic data — $\psi$, $n$ and the presentation — for 10.3(1); the structure of the skeleton is clauses 2–4.
2. For $n\in S^2$ (the sphere of 6.3), "up" and "down" along $n$ on $Q$ are the two eigenplanes of the symmetric, traceless involution $J_n\mathcal J$; on them $J_n=\mp\mathcal J$. Reversing the selected sign of $\mathcal J$ (6.10) exchanges the two labels.
3. The colour-singlet operators form $\mathrm{End}_{\mathbb R}(Q)\oplus(\mathbb H\otimes\mathbb C)|_{Q^\perp}$, of real dimension $24$. The $\mathcal J$-linear colour-singlet operators form
$$\mathcal A_0=\mathrm{End}_{\mathbb C}(Q)\oplus\mathrm{End}_{\mathbb C}(M)\cong M_2(\mathbb C)\oplus M_2(\mathbb C),$$
each factor spanned over $\mathbb R$ by $\{1,\mathcal J,A,B,C,\mathcal JA,\mathcal JB,\mathcal JC\}$ restricted to the block, with $\mathcal J$ central and $A,B,C$ the quaternion units; $\mathfrak{so}(1,3)_Q$ acts through both factors as the Weyl representation. The colour-blind one-particle observables of $S$ are exactly two qubit algebras. ($\mathcal A_0$ is unchanged if $\mathcal J$ is replaced by $\omega\mathcal J$: colour-singlet operators preserve the blocks, on which $\omega=\mp1$.) The sum is direct, not tensor: $\mathcal A_0$ describes two separate sectors, not a pair of qubits that could be entangled — the projector $1_Q$ onto the singlet block is itself an element of $\mathcal A_0$ — and entanglement first appears at the Fock level (8.2). The centre of $\mathcal A_0$ is $\mathbb C\oplus\mathbb C=\mathrm{span}\{1,\mathcal J,\omega,\omega\mathcal J\}$, the commutant of 6.5(3), and it contains $Y=\mathcal J(2-\omega)$: within the colour-singlet observables the hypercharge is central, i.e. a superselection label that separates the two sectors ($Y=3\mathcal J$ on $Q$, $\mathcal J$ on $Q^\perp$).
4. $S$ supplies one canonical unit vector, $1\in Q$: fixed by colour, by every derivation and by $\tau$, and moved by every rotation and boost.

*Proof.* (1) is Theorem 2.5. (2) $J_n$ and $\mathcal J$ are commuting skew complex structures (6.4), so $J_n\mathcal J$ is symmetric with square $1$; $J_n\mathcal J\psi=\pm\psi$ is $J_n\psi=\mp\mathcal J\psi$; tracelessness is [EXACT] for $n=e_4,e_8,e_{12}$ (script C10) and holds for all $n$ by $\mathfrak{su}(2)_Q$-covariance. (3) [EXACT] (script C10): the commutant of colour has certified nullity $24$ with the exhibited basis; its intersection with the commutant of $\mathcal J$ has certified nullity $16$ with the exhibited basis; each block is closed under multiplication. $\mathbb H\otimes_{\mathbb R}\mathbb C\cong M_2(\mathbb C)$ is standard; $\mathfrak{so}(1,3)_Q\subset\mathcal A_0$ by 6.4; the Weyl identification is 6.5; the centre and $Y\in Z(\mathcal A_0)$ are [EXACT] (script C10) and 6.7(4). (4) The unit is fixed by every automorphism and killed by every derivation; the rest is [EXACT]. $\square$

**Theorem 10.3 (the hollow) [THM].**

1. *No individual outcome is a function of the algebraic data.* Let $\mathcal D$ be any collection of data definable from $S$, the criterion, the selections and $\mathcal J$ — in particular the state vector $\psi$, the context $n$, and every operator of 10.2; by 10.2(1) the algebraic data are exhausted by these. A map $o:\mathcal D\to\{+,-\}$ makes the outcome a function of the data, so conditional on the data its distribution is a point mass; for generic $\psi$ and $n$ the Born measure is not. Hence the two premises — *the outcome is a function of the algebraic data*, and *the Born measure is the distribution of the outcome conditional on that same data* — are jointly inconsistent. Under the second premise, which is stated here and not derived, any argument $\lambda$ that determines individual outcomes is therefore not a function of the algebraic data; and $S$ contains no such $\lambda$, since everything $S$ supplies lies in $\mathcal D$. What $S$ does force is that alternatives *are* alternatives: up and down along $n$ are orthogonal projections (10.2(2)), and mutually exclusive in every state.
2. *Probabilities are forced on the full skeleton, and only there.* On $(S,\mathcal J)\cong\mathbb C^8$ every countably additive probability assignment to events is Born for some density operator (Gleason 1957, dimension $8\ge3$): once the event lattice is given, the form of the measure is not free. On $\mathcal A_0$ alone it is free *for assignments to projections*: each factor is $M_2(\mathbb C)$, where Gleason's theorem fails. It is **not** free for assignments to effects: if the settlement layer assigns probabilities to effects $0\le E\le1$ (unsharp measurements) additively, Busch's theorem (2003) forces the Born rule in every dimension, including $2$. So on the colour-singlet skeleton the Born rule is an input only if the layer is restricted to sharp projections; on effects it is a theorem.
3. *What the missing argument must satisfy.* (a) On $\mathcal A_0$, deterministic non-contextual value maps on *projections* exist: choose a sector, then apply Bell's 1966 construction on that $M_2(\mathbb C)$ factor (the direct-sum structure means the two factors never share a context, so no Kochen–Specker relation links them); on *effects* they do not, by Cabello's single-qubit POVM argument (2003), though the premise that effects carry definite values is contested: $S$ does not exclude a deterministic $\lambda$ for colour-blind one-particle observables. (b) On the full presentation algebra, which contains $M_8(\mathbb C)$, no deterministic non-contextual value map exists (Kochen–Specker 1967): if colour-non-singlet contexts are physical, $\lambda$ is contextual. (c) Composite systems arise only at the Fock level (8.2), where Bell 1964 applies: $\lambda$ is then nonlocal or non-deterministic.

*Proof.* (1) A function of the data has, conditional on the data, a point-mass distribution, while the Born measure of a generic pair $(\psi,n)$ is non-degenerate; exhaustion of the data is 10.2(1). (2), (3) are the cited theorems applied to the algebras identified in 10.2; Busch's theorem is Gleason's for positive-operator-valued frame functions, valid in dimension $2$. $\square$

*Interpretation. Three readings are compatible with 10.3(1), and the algebra ranks none of them: an argument $\lambda$ outside the algebraic data (a hidden variable, constrained by (3)); no determination at all (irreducible randomness); all outcomes realised (a many-worlds reading, likewise no function of the data). The trichotomy is a classification of positions, not a theorem of $S$; (2) and (3) constrain the first reading and are silent on the other two.*

**10.4 [POSTULATE] The settlement layer.** A reader who wants individual events is, by 10.3(1), adding an argument. The postulate has a definite shape: a probability space $(\Lambda,\mathfrak m)$; for each preparation a measure $\mathfrak m_\psi$; for each context — a sharp one, $n\in S^2$ with the eigenplanes of 10.2(2), or an unsharp one, a resolution of the identity by effects — a measurable outcome map $o:\Lambda\to$ outcomes. The unsharp form is the more natural for this program (the algebra supplies effects generically and projections as their limit) and the more constrained: on it Born is a theorem even on the two-qubit skeleton (10.3(2)). It must pass one theorem — the pushforward $(o_n)_*\mathfrak m_\psi$ is the Born measure for every $\psi,n$ — and the three constraints of 10.3(3), which bite at definite places: not on $\mathcal A_0$, on the full one-particle lattice, and at the composite level. If it is adopted, every "which outcome" question in the ledger becomes [POSTULATE], and nothing else in the ledger changes.

**10.5 [BOUNDARY] What cannot yet be said.** (a) Whether the physical observables are $\mathcal A_0$ or the full lattice — the dichotomy 10.3(3a)/(3b) — is decided by physics, not by $S$; if only colour-singlet operators are observable in isolation, $S$ leaves a deterministic settlement layer open at the one-particle level — on projections; on effects only under the contested premise of 10.3(3a). (b) The composite level requires the Fock construction of 8.2, which $S$ reaches only through a chosen $\mathcal J$; the theorems of 10.3 at that level are Bell's, and their interaction with 7.6 (no squeeze-invariant state) is untouched. (c) Dynamics is bounded by 7.7. (d) What $\lambda$ *is* — a pre-algebraic reality, a "Ding an sich", an ensemble — is a name; the theorems say exactly one thing about it: it is not a function of the algebraic data.

*Interpretation. The skeleton is complete and the hollow is exact. Inside $S$: every event and every context; two qubit algebras of colour-blind observables carrying Lorentz as Weyl; one canonical vector. Forced, given the full lattice and a state: every probability. Outside $S$, and provably so: the event itself, the choice between "determined by $\lambda$" and "determined by nothing", the Born rule on the singlet skeleton if the full lattice is not admitted and the settlement is restricted to sharp projections (10.3(2)), and the dynamics. That is the precise sense in which the structure is hollow: it fixes what can happen and with what weight, and it contains nothing that happens.*

**10.6 [STANCE].** (a) The three worlds are three generations — a reading that, by 12.1, cannot be realised inside $S$ and requires an enlarged carrier. (b) The seam is physical and its cone carries the thermal state of K3a. (c) Time is the grading $\tau$, read through 7.2 and 7.9: the canonical squeeze $\tau L_{e_8}$, whose rapidity determines the failure index, $\beta/N=\operatorname{sech}2t$ (7.9(2)). These are readings of theorems 3.4, 3.5 and 6.4; they are used by nothing.

*Interpretation. The postulate is not a weakness that has been hidden; it is the one place where the program adds a premise, and 10.2–10.3 tell the reader exactly what shape the premise must have, which theorems it must pass, and where those theorems do and do not bite. That is more than most proposals for a sub-quantum layer state about themselves.*

---

## 11. Open problems

1. **Sharpness of $c_n$** — *closed (Theorem 5.6)*: $c_n=2^{(n-3)/2}$ for all $n\ge4$, by an explicit lifting recursion with an exact base case. The value is in the literature (Biss–Christensen–Dugger–Isaksen 2009), so the theorem stands as an independent proof.
2. **K3a, restated natively.** By 7.9 the carrier is canonical — $L^2(S)$ (or $L^2(S^{pp})$, or functions on the cone $\mathbb R_+\times Z$) with the unitary Koopman action of the group generated by $\mathfrak{so}(1,3)_Q$, colour and $G_2$ — and the flow is canonical: the pullback of $e^{tK_1}$, the radial flow of the failure disk. What is missing is a von Neumann algebra on this carrier, built from $S$'s own operators (multiplication by coordinate functions, the presentation acting on the argument), and a state for which this flow is the modular group. The Borchers route — a positive-energy representation of the affine group, whose modular flow is the dilation — would supply such a pair, but a positive generator is a spectrum condition of the kind field theory assumes and $S$ does not obviously provide; it is one route, and it is flagged as an import. By 7.6, 8.6 and 8.8 no finite-dimensional piece can carry the flow, and a hyperbolic Koopman flow has no invariant normal state on $L^2$, so the state, if it exists, is not a vector of $L^2(S)$. Constraint (conjectural, suggested by an independent reader): the modular conjugation must restrict to $\tau$ on the finite skeleton (8.6(4)). By 7.9(7) the flow is, on $L^2(\mathbb O)$, a signature-$(7,1)$ sum of $xp$ generators, so K3a is a case of the Berry–Keating–Connes problem for $H=xp$, with $S$ fixing the signature and the conjugation; the obstacles known there (no normalisable eigenstates, the need for a boundary condition or a cutoff to obtain a spectrum) are the obstacles here. A bridge that is now exact: the $1+3+3$ filtration contracts $\mathrm{Im}\,\mathbb O$ to the R-flux/monopole Malcev algebra and $\mathrm{Im}\,S$ to a seven-dimensional one with the mediator central (4.7(iv)–(v)); the monopole system has a known dynamics whose non-associativity is a quantised three-cocycle, and $S$'s cocycle is $\mathbb Z_2$-valued (1.7). Whether the uncontracted $S$ is the "finite-flux" completion of that system, and whether its dynamics lifts, is a precise question for the next paper.
3. **The "neither" edges** — *closed (Theorem 2.7)*: ranks $8$ and $12$ with rank $4$ on the exceptional pairs; the thirty generators generate $\mathfrak{so}(16)$, with $\tau$ all of $\mathfrak{sl}(16)$.
4. **The further $\mathfrak u(1)$'s** — *partly closed.* $Y$ is the superselection label of the colour-singlet observables (10.2(3)); $\omega\mathcal J$ is the spinor complex structure of the Pati–Salam $\mathfrak{so}(6)_c$, relative to which $Y$ has the $B-L$ pattern, and this fixes the block-relative sign of 6.10 (6.7(6)). The relation between $\omega\mathcal J$ and the canonical $R_{e_8}$ is now computed (8.7) and shown to be irreconcilable on $S$ for a structural reason (8.6(2)). Open: the physical role of the remaining overall sign ($\mathbf 4$ versus $\bar{\mathbf 4}$), and the meaning of the split $Q^\perp=V_+\oplus V_-$ of 8.7.
5. **Fock-level Lorentz** — *the vacuum question is closed*: the metaplectic implementation of $\mathfrak{so}(1,3)_Q|_Q$ on the four-mode Fock space of $(Q,\sigma_{J_e})$ has no boost-invariant vector (7.6) and, more strongly, no finite-dimensional carrier has one (8.6, 8.8). Open: what Lorentz covariance means for a theory built on this block, i.e. the field-theoretic statement on the cone.
6. **The observable skeleton.** Whether the physical one-particle observables are $\mathcal A_0$ (10.2(3)) or the full lattice; the answer decides which of 10.3(3a)/(3b) governs the settlement layer. (The $\mathfrak{so}(1,3)_Q$-invariant subalgebra of $\mathcal A_0$ is not open: it is the centre $\mathrm{span}\{1,\mathcal J,\omega,\omega\mathcal J\}$, by 6.5(3) with 10.2(3).)
7. **The seam bundle as an internal gauge field** — *computed*: $\mathfrak g_2=\mathfrak{su}(2)_q\oplus\mathfrak m$ is reductive ($3+11$), and the curvature values $[\mathfrak m,\mathfrak m]_{\mathfrak h}$ of the canonical connection on $G_2\to G_2/SU(2)_q$ span all of $\mathfrak{su}(2)_q$ [EXACT]: the holonomy is the full $SU(2)_q$. The seam carries a non-flat internal $SU(2)$ gauge field with maximal holonomy, and its structure group is a sub-$\mathfrak{su}(2)$ of colour. *Completed (Theorem 3.8): the curvature is the quaternion-Kähler $\mathfrak{sp}(1)$-curvature of the associative Grassmannian $G_2/SO(4)$ pulled back to the seam, and the connection is Yang–Mills for the normal metric.*
8. **A second proof of 5.4(1)** — *closed, and strengthened.* Let $z_1=2e_1+e_2+e_5-e_{25}+2e_{26}+e_{30}$, of norm$^2$ $12$; $L_{z_1}$ has rank $28$ exactly, corank $4$. Write $K=\ker L_{z_1}$ and, in blocks adapted to $\mathrm{Im}\,A_5=K\oplus K^\perp$, $L_z=\begin{pmatrix}A(z)&-B(z)^{\!\top}\\B(z)&D(z)\end{pmatrix}$; $D(z_1)$ is invertible, since a skew operator maps the orthogonal complement of its kernel bijectively to itself. Near $z_1$ the corank-$4$ locus is therefore $\{\Phi=0\}$ for the Schur complement $\Phi(z)=A(z)+B(z)^{\!\top}D(z)^{-1}B(z)$, a real-analytic map into the skew forms on $K$ — six equations — with $d\Phi(z_1)\,\delta z=P_K L_{\delta z}|_K$, of rank $6$ exactly: a submersion. So the corank-$4$ locus is, near $z_1$, a manifold of dimension $31-6=25$ in $\mathrm{Im}\,A_5$, of dimension $24$ after normalisation, while every $\mathrm{Aut}(A_5)$-orbit has dimension at most $\dim G_2=14$: the unit zero divisors of $A_5$ meet uncountably many orbits — in particular at least three, independently of the strata of 5.3. The count required a generic witness: at the two-term representative $e_1+e_{26}$, hence on its whole orbit, the same derivative has rank only $3$ **[EXACT]** (script C31).

---

## 12. What the boundaries demand

A map of boundaries is not a route. This section says, for each boundary the paper has drawn, whether it is fatal for $S$ alone, what exactly it demands of the next construction, and what would count as meeting the demand. It is the section a reader should test the program against.

### 12.1 What $S$ is, in Standard-Model terms

**Theorem 12.1 [THM + STANDARD].** With the complex structure $\omega\mathcal J$ (criterion 6.11), $S$ is the module $\mathrm{Weyl}\otimes(\mathbf 3_{1}\oplus\mathbf 1_{-3})$ for $\mathfrak{so}(1,3)_Q\oplus\mathrm{colour}\oplus\mathfrak u(1)_Y$ (6.5, 6.7(4),(6)): one Pati–Salam quartet of a single chirality, without isospin. **[STANDARD]** A Standard-Model generation is sixteen Weyl fermions, i.e. four such quartets — $(Q_L,L_L)$ twice (isospin up and down), $(u_R,\nu_R)$, $(d_R,e_R)$ — of real dimension $64$. Hence $S$ is one quarter of one generation, and the three worlds are at most three quarters of one; the stance 10.6(a) cannot be realised inside $S$. Moreover the Pati–Salam $\mathfrak{su}(4)$ does not commute with $\mathfrak{so}(1,3)_Q$ on $S$ (6.7(6)), so even the quartet is not a joint $\mathrm{Lorentz}\times\mathfrak{su}(4)$ module.

### 12.2 [SELECTED] Statistics

Quantising $S$ by its canonical symplectic form gives a CCR (bosonic) representation. The canonical Euclidean structure and $J_e$ equally define a CAR (fermionic) Fock representation, canonical up to conjugation; both are theorems of $S$ (3.7), and *which statistics* is a selection (12.2). Under CAR, Bogoliubov transformations are orthogonal: the squeezes $e^{tK_i}$ are not orthogonal for $t\ne0$ and so do not act at all, while each $K_i$ itself is an orthogonal involution and acts as a discrete reflection [EXACT] (script C14); $G_2\times\Sigma_3$ acts as in 8.4(i). Two levels must be kept apart: the statistics of the *modes of the presentation* is fermionic by theorem (2.10, 6.12), while the statistics of a *field* whose one-particle space is $S$ is the selection made here. By the spin–statistics theorem (Pauli 1940) any relativistic completion in which $S$ carries the spin-$\tfrac12$ content of 6.5 must use CAR, in which case the symplectic results of §§7–8 describe a bosonic reading of $S$ and the boosts have no one-particle action whatever on $S$ — which sharpens, not weakens, 8.6 and 8.8.

### 12.3 Where the complexification lives: the state, twice

The program's rule is that nothing is added to $S$ by hand; a complex structure, an extra index, a state must be found *in* $S$ or shown absent. The following three theorems apply that rule to the boundaries of 12.1. Their common instrument is the observation that expectation values are scalar parts of products.

**Theorem 12.3 (the lone scalar, and the twofold complexification of the state) [THM + EXACT].**

1. For every unit $\psi\in S$ and every $x\in S$: $\langle\psi,L_x\psi\rangle=\langle\psi,R_x\psi\rangle=x_0$, the scalar part of $x$. In every vector state of the presentation the seven imaginary directions of each half are invisible; only the scalar that a product spits out — for pure $u,w$, $uw=-\langle u,w\rangle+\tfrac12[u,w]$, and only $-\langle u,w\rangle$ survives — is an expectation value.
2. The imaginary part of $x$ acquires an expectation value only through a complex structure: $\langle\psi,J L_x\psi\rangle$ is real and in general nonzero, and the pair $(\langle\psi,L_x\psi\rangle,\langle\psi,JL_x\psi\rangle)$ is the complex expectation $\langle\psi,x\psi\rangle_J$. The state is complex-valued because $J$ is; $S$ itself is not complexified.
3. $S$ supplies $J$ twice, from two of its own substructures: $R_{e_8}$ from the canonical line $\mathbb C_e$ (3.7), and $\omega\mathcal J$ from a world and a mediator (6.7(6)). On the singlet block these are $R_{e_8}|_Q$ and $-R_{e_4}|_Q$, and together with their product $R_{e_{12}}|_Q$ they generate the right action $R_Q\cong\mathbb H$: the twofold complexification of the state on $Q$ is a quaternionic structure. Its $\mathfrak{su}(2)$, $R_{\mathrm{Im}\,Q}|_Q$, commutes with the rotations and with colour and is broken by the boosts [EXACT] (script C6, the commutant basis $R_{e_4}|_Q,R_{e_8}|_Q,R_{e_{12}}|_Q$ and the anticommutation of $R_{e_8},R_{e_{12}}$ with $K_i$). It is the second $\mathfrak{su}(2)$ of $\mathfrak{so}(4)$ on a real Weyl spinor, not an internal symmetry.
4. $S$ supplies canonical states: the vector state of the unit $1\in Q$ (10.2(4)) and the Fock vacuum $\omega_e$ (8.4), the latter invariant under all of $\mathrm{Aut}(S)$.

*Proof.* (1) $L_x=x_0+L_P$ with $L_P$ skew. (2) $\langle\psi,JL_x\psi\rangle=\langle\psi,JL_P\psi\rangle$ is the quadratic form of the symmetric part of $JL_P$, which is $JL_P$ itself when $J$ commutes with $L_P$ (for instance $J=\mathcal J$ and $P\in\mathrm{Im}\,Q$, where it is the Bloch component of $\psi$ along $P$) and is nonzero in general. (3) $R_{e_8}R_{e_4}=R_{e_{12}}$ by associativity of $Q$; the rest is cited. (4) is cited. $\square$

**Theorem 12.4 (no weak isospin in $S$, in its operator space, or in its Fock space) [THM + EXACT].** Let $\mathfrak k=\mathfrak{so}(1,3)_Q\oplus\mathrm{colour}\oplus\mathfrak u(1)_Y$ act on $S$ with the complex structure $\omega\mathcal J$ (criterion 6.11), so that $S\cong\mathrm{Weyl}\otimes(\mathbf 3_1\oplus\mathbf 1_{-3})$.

1. On $S$ the commutant of $\mathfrak k$ is abelian (6.5(3), 6.8).
2. On $\mathrm{End}(S)$ regarded as the $S$-bimodule of the presentation (left action by $L$, right action by $R$), no right multiplication $R_y$ commutes with the induced action of $\mathfrak k$ unless it does so on $S$; the bimodule adds nothing.
3. Every particle-number sector of the Fock space over $S$ — $\Lambda^kS_{\mathbb C}$ for all $k$ (fermions) and $\mathrm{Sym}^kS_{\mathbb C}$ for all $k$ (bosons) — is a *multiplicity-free* $\mathfrak k$-module. Hence the commutant of $\mathfrak k$ in every sector is abelian: no $\mathfrak{su}(2)$ commuting with Lorentz, colour and hypercharge acts on any state of definite particle number.

*Proof.* (1) is cited. (2) The induced action on $\mathrm{End}(S)$ is $X\mapsto gXg^{-1}$; $[\,\cdot\,,R_y]$ commutes with it iff $[g,R_y]=0$. (3) Fermions: by the Cauchy formula $\Lambda^k(V\otimes W)=\bigoplus_{\lambda\vdash k}S_\lambda V\otimes S_{\lambda'}W$ with $V=\mathbb C^2$, $W=\mathbf 3\oplus\mathbf 1$; $\ell(\lambda)\le2$ and $\lambda_1\le4$ leave finitely many $\lambda$, each with a distinct Lorentz spin $(\lambda_1-\lambda_2)/2$ for fixed $k$, and $S_{\lambda'}(\mathbf 3\oplus\mathbf 1)=\bigoplus_{\mu\subseteq\lambda'}S_\mu\mathbf 3\otimes S_{\lambda'/\mu}\mathbf 1$ has hypercharge $4|\mu|-3k$ on the $\mu$-summand, so distinct $\mu$ of equal size give distinct $\mathfrak{su}(3)$-irreps and distinct sizes give distinct $Y$. Bosons: $\mathrm{Sym}^k(V\otimes W)=\bigoplus_{\lambda\vdash k,\ \ell(\lambda)\le2}S_\lambda V\otimes S_\lambda W$, and the same argument applies. **[EXACT]** (script `fock_multiplicity.py`): the highest-weight spaces of all sectors $\Lambda^0,\dots,\Lambda^8$ and $\mathrm{Sym}^0,\dots,\mathrm{Sym}^4$, computed exactly with their weights, have every multiplicity equal to $1$ ($1,2,5,6,8,6,5,2,1$ and $1,2,5,8,14$ summands respectively). $\square$

**Theorem 12.5 (the seam's own $\mathfrak{su}(2)$) [THM].** The stabiliser in $G_2$ of a point $(u,w)$ of the seam $Z=G_2/SU(2)$ is the group $SU(2)_q$ fixing the quaternion subalgebra $\mathbb H_{u,w}$ pointwise; its centraliser contains the second factor $SU(2)_p$ of the $SO(4)=(SU(2)_p\times SU(2)_q)/\mathbb Z_2\subset G_2$ that preserves $\mathbb H_{u,w}$, and $SU(2)_p$ acts on $Z$ from the right, commuting with the whole $G_2$ — hence with colour. This is a canonical $\mathfrak{su}(2)$ that $S$ supplies through its zero divisors. But on scalar functions over the seam it has only integer spin: $L^2(Z)=\bigoplus_\pi V_\pi\otimes(V_\pi^*)^{SU(2)_q}$ (Frobenius), and since $(-1,-1)$ is the identity of $G_2$, every $(j_p,j_q)$ occurring in a $G_2$-representation has $j_p+j_q\in\mathbb Z$, so $SU(2)_q$-invariants ($j_q=0$) carry $j_p\in\mathbb Z$. No doublet arises on the seam alone. More precisely, the group of canonical symmetries of $Z$ commuting with $G_2$ is $N_{G_2}(SU(2)_q)/SU(2)_q=SO(4)/SU(2)_q\cong SO(3)_p$, which has no doublet representation at all. Nor can the fibre supply the missing half-integer: an $\mathfrak{su}(2)$ acting on $S$-valued fields over $Z$ as $X_i\otimes1+1\otimes Y_i$, with $X_i$ on the base and $Y_i$ on the fibre, and commuting with Lorentz and colour, has $Y_i$ in the commutant $\mathbb C\oplus\mathbb C$ of 6.5(3), which is abelian, so the $\mathfrak{su}(2)$ relations force $Y_i=0$; and no subgroup of $G_2$ acting on the fibre commutes with colour, since the centraliser of the maximal-rank subgroup $SU(3)$ in $G_2$ is its centre $\mathbb Z_3$. Hence **no weak-isospin doublet arises from the seam's canonical symmetry, on scalar or on $S$-valued fields.**

*Proof.* An automorphism fixing $u,w$ fixes $\mathbb H_{u,w}$; the pointwise stabiliser of a quaternion subalgebra in $G_2$ is $SU(2)$ acting on $\mathbb H^\perp=\mathbb H\ell$ by $b\ell\mapsto(qb)\ell$, and $(p,q):a+b\ell\mapsto pa\bar p+(qb\bar p)\ell$ is the $SO(4)$ (Baez 2002, §4.1; Harvey–Lawson). The normaliser of the pointwise stabiliser of $\mathbb H$ is the setwise stabiliser $SO(4)$, whence the quotient $SO(3)_p$. The parity statement is the $\mathbb Z_2$ in $SO(4)\subset G_2$. The fibre statement: $[X_i\otimes1+1\otimes Y_i,X_j\otimes1+1\otimes Y_j]=[X_i,X_j]\otimes1+1\otimes[Y_i,Y_j]$, and $[Y_i,Y_j]=0$ in an abelian commutant. The centraliser of a closed connected subgroup of maximal rank is its centre. $\square$

### 12.4 The boundaries, ranked — with what is deduced

| boundary | fatal for $S$ alone? | deduced status | what would count |
|---|---|---|---|
| **(a) isospin** (6.8–6.9) | yes | **closed at the kinematic level, negatively.** The missing factor is not in $S$, not in $\mathrm{End}(S)$ as a bimodule, not in any sector of the Fock space of $S$ (12.4), and not in the canonical symmetry of the seam on scalar or $S$-valued fields (12.5). The second $\mathfrak{su}(2)$ of the twofold complexification is the boost-broken $\mathfrak{su}(2)_R$ of a real Weyl spinor (12.3(3)). The extensions in the literature ($\mathbb C\otimes\mathbb H\otimes\mathbb O$: Furey 2018, Gresnigt et al. 2023) add the factor by hand and are not admitted here | *superseded by §13*: weak isospin is not inside $S$, its operator space, its Fock space or its seam, but the two presentations of $S$ are inequivalent modules (13.1), and on $S$'s own doublings this inequivalence appears as doublets — on the singlet block of $A_5$ and on both blocks of $A_6$ (13.2) — which the doubling's product then breaks (13.3). What remains is dynamical |
| **(b) dynamics** (7.6–7.9, 8.6–8.8) | yes | no finite carrier can host it (8.6, 8.8); the carrier and the flow are now canonical (7.9): $L^2(S)$ with the Koopman action, and the pullback of the canonical squeeze $e^{tK_1}$, which is the radial flow of the failure disk; the only known mechanism producing a flow from an algebra and a state is modular theory; the Borchers route (positive-energy affine group) is one route and imports a spectrum condition; in finite dimension $[D,P]=iP$ with $P\ge0$ forces $P=0$ | a von Neumann algebra on $L^2(S)$ built from $S$'s own operators, and a state, whose modular group is the Koopman $K_1$-flow and whose modular conjugation restricts to $\tau$ |
| **(c) measurement** (10.3–10.4) | no | nothing derives outcomes (10.3(1)); expectation values are scalar parts of products (12.3(1)) and become complex through $S$'s own $J$'s (12.3(2)–(3)) | a measure on the cone whose pushforwards are Born, constructed from the seam |
| **(d) chirality** | not separate | reduces to (a): no weak $\mathfrak{su}(2)$ on $S$ to couple chirally; the block-relative sign is fixed (6.7(6)), the overall sign is a convention | resolved with (a) |

**12.6 [BOUNDARY] The shape of the next construction.** Boundaries (a) and (b) are both fatal for $S$ alone. Boundary (a) is answered kinematically by §13: the doublets are the multiplicity of $S$'s two presentations (inequivalent by 13.1) on its own double doubling $A_6$, and the carrier is $A_6$-valued rather than $S$-valued. Boundary (b) is unchanged. The boundaries therefore constrain the next construction without determining it uniquely: an infinite-dimensional carrier over the canonical continuum (the candidates of §11.2: $L^2(S)$, $L^2(S^{pp})$, or functions on the cone), $A_6$-valued fields if the doublets of 13.2 are to be present, fermionic (12.2), with $\tau$ in the seat of the modular conjugation and the radial dilation as modular flow (12.4(b)); which carrier is physical is [OPEN] (13.5(v)). Whatever construction meets these constraints carries two burdens: to exist, and to turn the doublet commutants of 13.2 — already broken by the doubling's own product (13.3) — into dynamics. Nothing in it is imported from the Standard Model; the reading of Appendix C is applied afterwards.

*Interpretation. A factor $S\otimes\mathbb H$ is what the literature would add here; inserting it would answer a reader's objection with exactly what the objection asked for. The corrected section answers it by computation. All four places where the factor could have been hiding kinematically are now closed by theorems — the algebra, its operator space, its Fock space, and the seam's own symmetry. The program's own intuition — that the complexification belongs to the state and not to $S$, and that it should arise from $S$'s relation to its substructures — is Theorem 12.3, and it is true in exactly the form stated: the state is complex twice, from $\mathbb C_e$ and from a world with a mediator, and on the singlet block the two together are quaternionic. What that intuition does not supply is the weak isospin; the theorems above say where it is not, and where it still could be.*

---

## 13. The two presentations, and $S$ acting on its own doublings

Section 12 closed every place *inside* $S$, its operator space, its Fock space and its seam where a Lorentz-commuting doublet could have been. It did not examine the one structure this paper began with: the presentation itself has two halves, $x\mapsto L_x$ and $x\mapsto R_x$ (0.2). The first theorem below is about $S$ alone and says that the two halves are *different* modules for Lorentz $\oplus$ colour. The rest of the section says what happens when $S$ acts, by its own product, on the objects that its own defining construction produces next — the doublings $A_5$, $A_6$, $A_7$ — which lay the two halves side by side with definite multiplicities.

**Theorem 13.1 (the two presentations as modules) [THM + EXACT].** Let $\mathfrak k=\mathfrak{so}(1,3)_Q\oplus\mathrm{colour}$ act on $S$ through the left presentation ($L_x$ and the derivations) and, separately, through the right presentation ($R_x$ and the derivations), and let $\bar R$ denote the right presentation of the conjugate, $x\mapsto R_{\bar x}$.

1. $(S,L)$ and $(S,\bar R)$ are isomorphic $\mathfrak k$-modules, intertwined by conjugation $C$.
2. $(S,L)$ and $(S,R)$ are isomorphic on the singlet block $Q$ — the intertwiners are $C\,R_{e_8}|_Q$ and $C\,R_{e_{12}}|_Q$, conjugation composed with the canonical complex structures of 7.3 — and **inequivalent on the coloured block** $Q^\perp$: $\mathrm{Hom}_{\mathfrak k}\big((S,L),(S,R)\big)$ has dimension $2$ and vanishes on $Q^\perp$.
3. On the coloured block the two presentations realise the two real modules $(\tfrac12,0)\otimes\mathbf 3$ and $(\tfrac12,0)\otimes\bar{\mathbf 3}\cong(0,\tfrac12)\otimes\mathbf 3$: relative to any complex structure making colour act as $\mathbf 3$ on both, the left and the right presentation have **opposite chirality**.

*Proof.* $CL_xC=-R_x$ for pure $x$, so $C$ intertwines rotations with rotations and boosts $\tau L_x$ with $-\tau R_x=\tau R_{\bar x}$; $C$ commutes with derivations. The Hom spaces are [EXACT] (script C16). (3): a real irreducible $\mathfrak{so}(1,3)\oplus\mathfrak{su}(3)$-module that is Weyl$\,\otimes\,$triplet is the realification of $(\tfrac12,0)\otimes\mathbf 3$ or of $(\tfrac12,0)\otimes\bar{\mathbf 3}$; these are the only two and they are inequivalent; two inequivalent such modules therefore realise both. $\square$

*Interpretation. Nothing in §13 concerns dynamics; it is a statement about modules, made after §§7–8 have shown that no flow of states lives on $S$, and it neither rescues nor touches that result. It is a statement about $S$ and nothing else: the algebra acts on itself from the left and from the right, and the two actions, restricted to the Lorentz-and-colour structure, are the same on the colour-singlet part and chirally opposite on the coloured part. The *relative* chirality of the two presentations is therefore not a sign a reader selects — it is the difference between multiplying on the left and on the right (13.1(3)) — while which of the two is called left remains the selected sign of 6.6.*

**Theorem 13.2 (the native action on the doublings) [THM + EXACT].** For $x\in S\subset A_n$, left multiplication in $A_n$ is block-diagonal on the $2^{n-4}$ copies of $S$ and places on them the presentations $L$, $R$, $\bar R$ in the pattern obtained by iterating $L^{(n+1)}_x=L^{(n)}_x\oplus R^{(n)}_x$, $R^{(n+1)}_x=R^{(n)}_x\oplus R^{(n)}_{\bar x}$: $A_5$ carries $(L,R)$; $A_6$ carries $(L,R,R,\bar R)$; $A_7$ carries $(L,R,R,\bar R,R,\bar R,\bar R,R)$. The derivations of $S$ lift diagonally and $\tau\oplus\cdots\oplus\tau$ is an automorphism (8.5(4)). Hence, as $\mathfrak k$-modules, the coloured block of $A_n$ ($n\ge5$) consists of the two inequivalent classes $\{L,\bar R\}$ and $\{R\}$ of 13.1, each with multiplicity $2^{n-5}$, and the singlet block of $2^{n-4}$ isomorphic copies. The commutant of $\mathfrak k$ on $A_n$ is therefore
$$M_{2^{n-4}}(\mathbb C)\ \oplus\ M_{2^{n-5}}(\mathbb C)\ \oplus\ M_{2^{n-5}}(\mathbb C),$$
of dimension $12$ on $A_5$ and $48$ on $A_6$ [EXACT]. **The first level at which the coloured block has any multiplicity is $n=6$, and there the multiplicity is $2$**: the coloured Weyl spinor occurs as two doublets of opposite chirality, each with a Lorentz-and-colour-commuting $\mathfrak{su}(2)$.

*Proof.* $(x,0)(a,b)=(xa,bx)$ and $(a,b)(x,0)=(ax,b\bar x)$ from Definition 0.1; iterate. The copy patterns and Hom spaces are [EXACT] (scripts C16, C17); the commutant of a block-diagonal action is the sum of the Hom spaces, which depend only on the copy types (13.1), so the formula follows from the multiplicities. $\square$

**Theorem 13.3 (the doublings' products break the doublets, at every level) [THM + EXACT].** The doublet $\mathfrak{su}(2)$ on $A_5$ — spanned by the skew mixing operators built from $C\,R_{e_8}|_Q$ and $C\,R_{e_{12}}|_Q$ and their bracket — commutes with the native action of $\mathfrak k$ but is not a Lie algebra of derivations of $A_5$: its generators violate the Leibniz rule on $640$ of the $1024$ basis pairs. On $A_6$ the generators of both coloured doublets violate it likewise ($1260$ and $1836$ pairs for the $\{R,R\}$ class, $4096$ for the $\{L,\bar R\}$ class, of $4096$). The doublets are symmetries of $S$'s action on the composites, not of the composites' own products, and no level of the sequence is distinguished by its product respecting them.

*Proof.* [EXACT] (script C17); consistent with $\mathrm{Der}(A_5)\cong\mathfrak g_2$ (Theorem 3.1), which is diagonal and does not mix the copies. $\square$

**Corollary 13.4 (content of the sequence) [THM; reading in italics].** As $\mathfrak k$-modules: $S$ is one colour-singlet and one coloured Weyl spinor (no multiplicity); $A_5$ adds the first multiplicity, a doublet on the singlet block only; $A_6$ is the first level with multiplicity on the coloured block, where the coloured Weyl spinor occurs as two inequivalent doublets of opposite chirality and the singlet as a quartet; $A_7$ has quartets on the coloured block and an octet on the singlet block; and so on with multiplicities $2^{n-5}$ and $2^{n-4}$. Each "first" is a theorem. *Read with Appendix C, $A_6$ is the fermion content of one generation in its left–right-symmetric form — a doublet of left-handed quarks, a doublet of right-handed quarks, four leptons — with the two $\mathfrak{su}(2)$'s of 13.2 as the two isospins; $A_5$ is the half on which only the leptons are doubled, $A_7$ carries two generations.* Resting the reading at $A_6$ privileges the coloured block over the singlet block, and that privilege is the reader's, not $S$'s: by 13.3 the product distinguishes no level.

**13.5 On the charter.** A reader has objected that passing to $A_6$ abandons the charter's "$S$ is the only primitive". Three facts answer this. (i) The content of §13 is Theorem 13.1, which is about $S$ alone: its two presentations are inequivalent modules. (ii) The doublings are $\prec S$ (8.5(4)): the construction consumes the product of $S$ and nothing else, with no choice, and the only thing used about them is that $S$ acts on them by its own product. (iii) The level $n=6$ is not chosen for its dimension; it is the first level at which the coloured block has multiplicity, and the multiplicity there is forced to be $2$ (13.2). But $A_5$ is equally the first level at which *any* block has multiplicity, and 13.3 shows the products of the doublings treat all levels alike. So the intrinsic object is the sequence, the "firsts" are theorems, and resting at $A_6$ is a reading that privileges the coloured block. Which carrier is physical — $S$, $A_5$, $A_6$, or the sequence — is [OPEN], and nothing in §13 decides it; 14.3 states what evidence would. (A domain-wall mass term would obtain chirality dynamically; the term is inserted, and its kinematic residue is Remark 7.8. §13 obtains chirality from $S$ alone, 13.1(3).)

**13.6 On the two notions of composite.** The same reader objected that a Fock space is an associative, tensor-product composite grafted onto a non-associative algebra. The paper agrees, and has proved the consequence: the associative composite is barren (12.4, no doublet in any sector), and the native composite is not (13.2) — but the native composite's product breaks the doublet its module structure carries (13.3). Non-associativity is not suppressed here; it is where the first "interaction" between copies lives, and it acts on exactly the structure the reading calls isospin.

**13.7 Status of the finite questions [THM + EXACT].** (i) *Closed.* The product $\tau_{16}\tau_{32}$ of the two doubling gradings is an automorphism of $A_6$ equal to $+1$ on the coloured class $\{L,\bar R\}$ and $-1$ on $\{R,R\}$: the class containing the world's own left presentation is the fixed subalgebra of the canonical mixed involution of the double doubling. Whether "fixed" means "preferred" is a criterion, not a theorem. (ii) *Closed.* On the $R$-type copies the hypercharge is $Y_R=CY_LC$, with $Y_R^2=-9$ on $Q$, $-1$ on $Q^\perp$, $Y_R|_Q=-3L_{e_4}$, commuting with colour, the $R$-rotations and $\tau$; on $A_6$ the pattern is $(Y_L,Y_R,Y_R,Y_R)$. (iii) *Closed.* The doublet generator is not a $\sigma$-twisted derivation of $A_5$ for any of the canonical gradings $\sigma\in\{1,\hat\tau,\tau_{16},\hat\tau\tau_{16}\}$ (defect $640/1024$ in every case): the breaking is not a graded twist. The Lie algebra generated by the doublet $\mathfrak{su}(2)$ together with the native mixing operators $L_{e_{16}},R_{e_{16}}$ has dimension exactly $17$ and is $\mathfrak u(1)^2\oplus\mathfrak{su}(4)$: it consists of skew operators, hence is a compact Lie algebra; its centre has dimension exactly $2$, its derived algebra dimension exactly $15$ and rank $3$, and the unique compact semisimple algebra of dimension $15$ and rank $3$ is $\mathfrak{su}(4)$ (Knapp 2002). It is not the direct sum $\mathfrak{su}(2)\oplus(\mathfrak{so}(1,3)_Q\oplus\mathrm{colour})$ of the same dimension: the rotation $A$ lies outside it. Adjoining the native $\mathfrak k$-action gives dimension exactly $81$. Both closures are certified over $\mathbb Q$ **[EXACT]** (script C30). The comparison with the $\mathfrak{so}(6)_c$ of 6.7(6) is settled negatively: the $\mathfrak{su}(4)$ so generated fixes pointwise the $24$-dimensional complement of $V=Q\oplus Qe_{16}$ and acts on $V$ as a single irreducible realified quartet, with an exhibited exact complex structure and commutant of dimension $24^2+2=578$ on $A_5$, while the diagonal lift of $\mathfrak{so}(6)_c$ acts with four quartets and no fixed vector (commutant dimension $4\cdot8=32$); the two intersect in $0$ inside $\mathfrak{so}(32)$, and since the commutant dimension is a conjugation invariant they are not conjugate in $GL(32,\mathbb R)$. The isomorphism $\mathfrak{su}(4)\cong\mathfrak{so}(6)$ is abstract only: the closure's $\mathfrak{su}(4)$ is the unitary algebra of the doubled quaternion block, not colour **[EXACT]** (script C34). (iv) *Closed.* $\mu$ lifts to every doubling copy-by-copy, so the worlds act within copies and cannot index them; three generations are not three doublings. (v) *Open.* Which carrier is physical.


## 14. The continuum, the carrier, and the one postulate

*The sections above consume no dynamical postulate. This section first proves that the continuum is native to the presentation, then states the one postulate the program's founding intuition requires, and derives its consequences from standard theory. Nothing in §§0–13 depends on anything below.*

**Proposition 14.0 (the continuum is native, and the certificates decide it) [THM].** (i) The centre of $S$ is $\mathbb R\cdot1=\mathbb Re_0$ (4.7(vii)); scaling is its action, and every expectation value projects to it (12.3(1)): the line of scalings is inside the primitive, not adjoined to it. (ii) Every [EXACT] claim of this paper is a polynomial identity in rational data, an exact rank statement over $\mathbb Q$, or a rational linear-programming decision; each is stable under the base change $\mathbb Q\to\mathbb R$, so the rational verification decides the real object. (iii) The irrationalities the canonical geometry forces are algebraic, and arise across dimensions, never along the centre line: $\sqrt2$ at the seam and the composition constant (2.8, 3.5, 5.6), $\sqrt3$ at the third automorphism ($\zeta=(-1+\sqrt3\,e_8)/2$; the frames of 3.9, verified over $\mathbb Q(\sqrt2)$ and $\mathbb Q(\sqrt3)$, script C29). The mechanism is precise: the table is trilinear over $\mathbb Z$ on distinct slots, and multilinear relations among distinct slots preserve rationality at every arity; irrationality enters exactly where a slot repeats — the norm $x\bar x$, the square $\zeta^2$ of the third automorphism, the eigenvalue conditions of the spectra — and lands, always, in a finite extension: no relation of any arity or degree reaches past the algebraic numbers. In particular the algebra is defined over $\mathbb Q$ while its automorphism group is not: $\mu$ requires $\mathbb Q(\sqrt3)$.

*Proof.* (i) is 4.7(vii) with 12.3(1). (ii) A polynomial identity with rational coefficients holds over $\mathbb R$ iff over $\mathbb Q$; rank is invariant under field extension; a rational linear system is solvable over $\mathbb R$ iff over $\mathbb Q$. (iii) is the cited loci and script C29; the multilinearity clause is the definition of the table, and a polynomial relation with rational coefficients confines its solutions to algebraic numbers. $\square$

*Interpretation. The object is the real algebra — being, the full line of scalings; the verification layer is rational — doing, of finite capacity; the proposition says the second decides the first. The presentation is a continuum certified by its grid, not a grid. The repetition is universal, and it is where geometry begins: every element satisfies the quadratic identity $x^2=t(x)x-n(x)1$ (1.1) — a law, not a case — its constant term lands on the non-eliminable centre line (1.8, 12.3(1)), and the inner product, hence every notion of distance and locality in the presentation, is determined by exactly that term (3.7(i)): the self-relation of each element is its cast onto the line of scalings. Whether one reads the base line as $\mathbb R$ given, or as the rationals together with unlimited refinement, is not a difference the presentation can express: completion under arbitrary precision is the construction of $\mathbb R$, and Definition 0.1 takes the completed line as ground field. What no completion supplies is the next item's carrier.*

**14.1 [POSTULATE] K3a (the modular dynamics).** No external structure is adjoined. The carrier is one of the two infinite constructions $S$ itself supplies: the $*$-algebra generated by the native action (13.2) along the doubling tower — which consumes the product of $S$ and nothing else (8.5(4)), and whose finite levels are the associative matrix algebras of 2.10 — or the image of the quantisation functor of 8.4 over the tower; both act on the completion of the construction's canonical inner-product space (3.2). The finite levels themselves are excluded: no invariant state and no modular flow in finite dimensions (7.6, 8.6), and a finite level is of type I (2.10). What is postulated is one state: a cyclic separating vacuum $\Omega$ for the construction, with $M$ the weak closure of the construction's algebra in the representation the state generates, such that (i) the modular flow of $(M,\Omega)$ extends the canonical squeeze of 7.9; (ii) the modular conjugation extends the reversal $\tau$ (3.7(iv)); (iii) some proper subalgebra $N\subset M$ from within the construction makes $(N\subset M,\Omega)$ a standard half-sided modular inclusion. $S$ supplies the tower, the native action, the functor, the squeeze and the reversal; the postulate supplies the state and the relations. That it must be a postulate is itself a theorem: 7.6 and 8.6.

**Theorem 14.2 (what the postulate buys) [THM + STANDARD].** Under 14.1: (1) $M$ is a factor of type III$_1$ (Wiesbrock 1993; proof completed by Araki–Zsidó 2005). (2) Both admissible carriers are generated by increasing sequences of finite-dimensional subalgebras, so $M$ is injective, hence the injective factor of type III$_1$, unique by Haagerup 1987. (3) The normal state space of $M$ is homogeneous: for any two normal states $\varphi,\psi$ and any $\varepsilon>0$ there is a unitary $u\in M$ with $\|\varphi\circ\mathrm{Ad}\,u-\psi\|<\varepsilon$ (Connes–Størmer 1978). No normal state is invariantly distinguished.

*Proof.* The cited theorems applied to $(N\subset M,\Omega)$; nothing is proved anew here. (1) uses (iii) with properness. (2) uses the finite-dimensional generation with (1). (3) uses (1) and separability of the predual, which the finite-dimensional generation supplies. $\square$

*Interpretation. The founding intuition of the program was that no state of the world is perfect. On $S$ itself the intuition is false: the state space of a finite-dimensional algebra is compact with distinguished points, and 8.9 lists the states $S$ does supply. Under the one postulate it becomes a theorem: the dynamics forces type III$_1$, and there the homogeneity of Connes–Størmer says the state space has no distinguished points — approximate indistinguishability is not the absence of structure but the structure itself. The postulate buys the intuition, and it is the only thing in this paper that does.*

**14.3 [BOUNDARY] What would decide the carrier.** The [OPEN] of 13.5 is not decided here. What would decide it: (a) which of the two constructions of 14.1 admits the inclusion with the stated generator — the postulate is falsifiable carrier by carrier; (b) compatibility of the flow with the native action of 13.2, which the Fock composite does not carry (12.4); (c) the content of the level the flow selects, against 13.4. The row remains [OPEN]; 14.1 sharpens what evidence would close it.

**14.4 [STANCE]** One stance, consumed by nothing: if the vacuum of 14.1 is the state of the world, the failure of the modular flow to be inner is itself a content of the vacuum; a cosmological constant as the price of type III is a reading, not a result.


---

## References

Standard results cited in the text.

- Albuquerque, H., Majid, S. (1999). Quasialgebra structure of the octonions. *J. Algebra* 220, 188–224.
- Araki, H., Zsidó, L. (2005). Extension of the structure theorem of Borchers and its application to half-sided modular inclusions. *Rev. Math. Phys.* 17, 491–543.
- Atiyah, M. F., Bott, R., Shapiro, A. (1964). Clifford modules. *Topology* 3 (Suppl. 1), 3–38.
- Baez, J. C. (2002). The octonions. *Bull. Amer. Math. Soc.* 39, 145–205.
- Bisognano, J. J., Wichmann, E. H. (1975). On the duality condition for a Hermitian scalar field. *J. Math. Phys.* 16, 985–1007.
- Bell, J. S. (1964). On the Einstein–Podolsky–Rosen paradox. *Physics* 1, 195–200.
- Bell, J. S. (1966). On the problem of hidden variables in quantum mechanics. *Rev. Mod. Phys.* 38, 447–452.
- Berry, M. V., Keating, J. P. (1999). $H=xp$ and the Riemann zeros. In *Supersymmetry and Trace Formulae*, Kluwer, 355–367.
- Biss, D. K., Dugger, D., Isaksen, D. C. (2008). Large annihilators in Cayley–Dickson algebras. *Comm. Algebra* 36, 632–664.
- Biss, D. K., Christensen, J. D., Dugger, D., Isaksen, D. C. (2009). Eigentheory of Cayley–Dickson algebras. arXiv:0905.2987.
- Borchers, H.-J. (1992). The CPT-theorem in two-dimensional theories of local observables. *Comm. Math. Phys.* 143, 315–332.
- Brown, R. B. (1967). On generalized Cayley–Dickson algebras. *Pacific J. Math.* 20, 415–422.
- Bruck, R. H., Kleinfeld, E. (1951). The structure of alternative division rings. *Proc. Amer. Math. Soc.* 2, 878–890.
- Bakas, I., Lüst, D. (2014). 3-cocycles, non-associative star-products and the magnetic paradigm of R-flux string vacua. *JHEP* 01, 171.
- Bargmann, V. (1964). Note on Wigner's theorem on symmetry operations. *J. Math. Phys.* 5, 862–868.
- Busch, P. (2003). Quantum states and generalized observables: a simple proof of Gleason's theorem. *Phys. Rev. Lett.* 91, 120403.
- Cabello, A. (2003). Kochen–Specker theorem for a single qubit using positive operator-valued measures. *Phys. Rev. Lett.* 90, 190401.
- Connes, A. (1999). Trace formula in noncommutative geometry and the zeros of the Riemann zeta function. *Selecta Math.* 5, 29–106.
- Chan, K. C., Đoković, D. Ž. (2006). Conjugacy classes of subalgebras of the real sedenion algebra. *Canad. Math. Bull.* 49, 492–507.
- Connes, A., Rovelli, C. (1994). Von Neumann algebra automorphisms and time-thermodynamics relation in generally covariant quantum theories. *Class. Quantum Grav.* 11, 2899–2917.
- Connes, A., Størmer, E. (1978). Homogeneity of the state space of factors of type III$_1$. *J. Funct. Anal.* 28, 187–196.
- de Marrais, R. P. C. (2000). The 42 assessors and the box-kites they fly: diagonal axis-pair systems of zero-divisors in the sedenions' 16 dimensions. arXiv:math/0011260.
- Eakin, P., Sathaye, A. (1990). On automorphisms and derivations of Cayley–Dickson algebras. *J. Algebra* 129, 263–278.
- Flaut, C., Boboescu, R. (2021). A twisted group algebra structure for an algebra obtained by the Cayley–Dickson process. arXiv:2103.12805.
- Folland, G. B. (1989). *Harmonic Analysis in Phase Space*. Princeton University Press.
- Günaydin, M., Minic, D. (2013). Nonassociativity, Malcev algebras and string theory. *Fortschr. Phys.* 61, 873–892.
- Günaydin, M., Lüst, D., Malek, E. (2016). Non-associative deformations of geometry in double field theory. *JHEP* 04, 101.
- Harvey, R., Lawson, H. B. (1982). Calibrated geometries. *Acta Math.* 148, 47–157.
- Gleason, A. M. (1957). Measures on the closed subspaces of a Hilbert space. *J. Math. Mech.* 6, 885–893.
- Haagerup, U. (1987). Connes' bicentralizer problem and uniqueness of the injective factor of type III$_1$. *Acta Math.* 158, 95–148.
- Jackiw, R. (1985). Three-cocycle in mathematics and physics. *Phys. Rev. Lett.* 54, 159–162.
- Kochen, S., Specker, E. P. (1967). The problem of hidden variables in quantum mechanics. *J. Math. Mech.* 17, 59–87.
- Knapp, A. W. (2002). *Lie Groups Beyond an Introduction*. Second edition, Birkhäuser.
- Laquer, H. T. (1984). Stability properties of the Yang–Mills functional near the canonical connection. *Canad. J. Math.* 36, 1015–1024.
- Lawson, H. B., Michelsohn, M.-L. (1989). *Spin Geometry*. Princeton University Press.
- Longo, R. (2008). Real Hilbert subspaces, modular theory, $SL(2,\mathbb R)$ and CFT. In *Von Neumann Algebras in Sibiu*, Theta, 33–91.
- Moreno, G. (1998). The zero divisors of the Cayley–Dickson algebras over the real numbers. *Bol. Soc. Mat. Mexicana* 4, 13–28.
- Moreno, G. (2005). Constructing zero divisors in the higher dimensional Cayley–Dickson algebras. arXiv:math/0512517.
- Pauli, W. (1940). The connection between spin and statistics. *Phys. Rev.* 58, 716–722.
- Pati, J. C., Salam, A. (1974). Lepton number as the fourth "color". *Phys. Rev. D* 10, 275–289.
- Reggiani, S. (2024). The geometry of sedenion zero divisors. arXiv:2411.18881.
- Ren, G., Zhao, X. (2022). The twisted group algebra structure of the Cayley–Dickson algebra. arXiv:2205.07986.
- Rieffel, M. A., van Daele, A. (1977). A bounded operator approach to Tomita–Takesaki theory. *Pacific J. Math.* 69, 187–221.
- Schafer, R. D. (1954). On the algebras formed by the Cayley–Dickson process. *Amer. J. Math.* 76, 435–446.
- Schafer, R. D. (1966). *An Introduction to Nonassociative Algebras*. Academic Press.
- Springer, T. A., Veldkamp, F. D. (2000). *Octonions, Jordan Algebras and Exceptional Groups*. Springer.
- Takesaki, M. (1970). *Tomita's Theory of Modular Hilbert Algebras and its Applications*. Lecture Notes in Mathematics 128, Springer.
- Wiesbrock, H.-W. (1993). Half-sided modular inclusions of von Neumann algebras. *Comm. Math. Phys.* 157, 83–92.
- Zhevlakov, K. A., Slin'ko, A. M., Shestakov, I. P., Shirshov, A. I. (1982). *Rings That Are Nearly Associative*. Academic Press.

Related programs, not used in the argument: Furey, C. (2018). *Eur. Phys. J. C* 78, 375; Gresnigt, N. G., Gourlay, L., Varma, A. (2023). *Eur. Phys. J. C* 83, 747; Todorov, I., Dubois-Violette, M. (2018). *Int. J. Mod. Phys. A* 33, 1850118.

---

## Appendix A. The exact-verification script and its output

Seven scripts are attached. `composition_witnesses.py` constructs exact saturating pairs in $A_5,\dots,A_8$ by the lifting recipe of 5.3(c) and prints them. `fock_multiplicity.py` computes, exactly over $\mathbb Q$, the highest-weight spaces of $\Lambda^kS_{\mathbb C}$ ($k\le8$) and $\mathrm{Sym}^kS_{\mathbb C}$ ($k\le4$) under $\mathfrak{sl}(2)\oplus\mathfrak{su}(3)\oplus\mathfrak u(1)_Y$ and reports every multiplicity (all are $1$; Theorem 12.4). `c28_doubling.py` verifies the finite instances of clause 8.5(4) — the conjugation read off the table by the quadratic identity, the reproduction of the $A_5$ table by the doubling of the $S$-table, the tower from $\mathbb R$, and the lifts $\hat\tau$, $\widehat{D_{a,b}}$, $\hat\mu$ on all $1024$ basis pairs of $A_5$, the last exactly over $\mathbb Q(\sqrt3)$ — in integer arithmetic with no rank computation and hence no mod-$p$ certificate; its output is reproduced at the end of this appendix. `c29_frames.py` verifies the finite instances of Theorem 3.9 — the generation rule read off the standard basis, and the reproduction of the table of Definition 0.1 by the frames of four nonstandard frame data, exactly over $\mathbb Z$, $\mathbb Z[\sqrt2]$ and, for the $\mu$-world datum, $\mathbb Q(\sqrt3)$ with a scale denominator — in integer arithmetic with no rank computation and hence no mod-$p$ certificate; its output likewise follows. `c30_open_items.py` verifies the closures of 13.7(iii) and §11 item 8: block C30 finds the Lie closures of 13.7(iii) modulo $p$ and certifies them over $\mathbb Q$ by exact echelon reduction of all $136$, respectively $3240$, pairwise brackets, with the centre, derived algebra and rank certified two-sidedly; block C31 computes the exact ranks of the Schur-chart derivative at the witnesses of §11 item 8; block C34 settles the comparison of 13.7(iii) — the $\mathfrak{su}(4)$ of the closure fixes twenty-four dimensions and acts on $Q\oplus Qe_{16}$ as one realified quartet, the diagonal $\mathfrak{so}(6)_c$ acts with four and no fixed vector, and the commutant dimensions $578$ and $32$ forbid conjugacy. Running time is under a minute; its output likewise follows. `c32_filtrations.py` proves the completeness claims of Proposition 4.7: block C32 enumerates the closed tight-sets of the contraction arrangement of $\mathrm{Im}\,\mathbb O$ by exact rational echelon forms, certifies the $520$ realisable cells by exhibited integer witnesses checked over $\mathbb Z$, decides the remaining $5327$ by an exact rational phase-one simplex, and matches the collineation orbits against the weights-$\le6$ survey; block C33 classifies the block extensions of the R-flux filtration on $\mathrm{Im}\,S$ by the same methods, with the Malcev identity verified with polarisation in its quadratic argument. Running time is under four minutes; its output likewise follows. `sedenion_exact.py` builds the signed multiplication tables of $A_3,\dots,A_6$ from Definition 0.1, represents every operator as an integer matrix, and verifies each [EXACT] claim other than C28–C34 under the protocol of §0.3. Kernels and commutants are certified by an exhibited exact null basis together with a rank computation modulo $p=2^{31}-1$; identities are checked on all basis tuples; $\mu$ is checked exactly over $\mathbb Q(\sqrt3)$. The single floating-point operation in the script is a screen in block C8 that proposes candidate pairs $(x,y)$ in $A_5$; every candidate is then certified by an exact integer null vector and an exact norm identity. Running time is under two minutes. The output follows.

```
Exact verification of the finite claims of the deductive edition
======================================================================

C1. Identities on S, verified on all basis tuples (Section 1.1)
  [ok]   polarised quadratic identity on all 256 basis pairs
  [ok]   conjugation is an anti-automorphism; x conj(y) + y conj(x) = 2<x,y> (256 pairs)
  [ok]   linearised flexibility and trace-form invariance on all 4096 basis triples
  [ok]   L_x^T = L_{conj x}, R_x^T = R_{conj x} on the basis
  [ok]   L_{e_i}^2 = -Id for i = 1..15 (basis units are alternative)
  [ok]   e_1 + e_10 is not alternative: L_z^2 != -||z||^2 Id
  [ok]   e_1 + e_10 is a zero divisor with dim ker L_z = 4 (exact)

C2. Tunnel lemma: L_A^T L_A = ||A||^2 Id + [[0,-Phi],[Phi,0]], Phi(y) = (u, conj y, w) (Section 1.3)
  [ok]   A=([0, 1, 0, 0, 0, 0, 0, 0],[0, 0, 1, 0, 0, 0, 0, 0]): block form True, Phi skew True, Phi^T Phi(Phi^T Phi - beta^2)=0 True, rank Phi = 4, beta^2 = 4
  [ok]   A=([0, 1, 2, 0, 0, 0, 0, 0],[3, 0, 0, 1, 0, -1, 0, 0]): block form True, Phi skew True, Phi^T Phi(Phi^T Phi - beta^2)=0 True, rank Phi = 4, beta^2 = 40
  [ok]   A=([2, 1, 0, 0, -1, 0, 0, 1],[0, 0, 1, -3, 0, 0, 1, 0]): block form True, Phi skew True, Phi^T Phi(Phi^T Phi - beta^2)=0 True, rank Phi = 4, beta^2 = 132
  [ok]   A=([0, 1, 0, 1, 0, 0, 0, 0],[0, 2, 0, 2, 0, 0, 0, 0]): block form True, Phi skew True, Phi^T Phi(Phi^T Phi - beta^2)=0 True, rank Phi = 0, beta^2 = 0
  [ok]   converse of 'diagonal blocks vanish iff u, b alternative' fails: u = e_1+e_10, b = -e_1+e_10 give T_u != 0 but T_u + T_b = 0

C3. The commutation graph on the thirty pure generators (Section 2.2-2.3)
  [ok]   L-L anticommuting pairs = 63 = 105 - 42; exceptions are exactly (e_i, e_{8+j}), i != j
  [ok]   R-R anticommutation graph is identical
  [ok]   no mixed L/R pair anticommutes (0); commuting mixed pairs are exactly (L_i,R_i) (15)
  counts over 435 pairs: anticommute 126, commute 15, neither 294
  [ok]   maximal anticommuting cliques among the fifteen L_{e_i}: 9 (two of size 8, seven of size 3)

C4. The even Cl(0,8) system generates End(R^16) (Section 2.4)
  [ok]   Cl(0,8) relations {L_i, L_j} = -2 delta_ij for the even system
  [ok]   rank of the 256 Clifford words = 256 = 256 (mod-p certificate suffices for full rank)

C5. Derivations, colour, and the automorphisms tau and mu (Section 3, 6.1)
  [ok]   D_{a,b} = [L_a,L_b]+[L_a,R_b]+[R_a,R_b] are derivations of O (all 21)
  [ok]   they span a space of exact dimension 14 = dim g_2
  [ok]   the diagonal lifts are derivations of S (all 256 basis pairs, 14 generators)
  [ok]   colour = stabiliser of e_4 in Der(S) has exact dimension 8 = 8
  [ok]   colour annihilates e_0, e_4, e_8, e_12
  [ok]   tau = diag(1_8, -1_8) is an automorphism of S (all 256 basis pairs)
  [ok]   mu(x) = zeta x conj(zeta) is an automorphism (exact over Q(sqrt 3), all basis pairs)
  [ok]   mu^3 = 1, mu fixes e_8, tau mu tau = mu^{-1}

C6. Given the mediator e_4: Q, its Clifford triple, su(2)_Q, J, so(1,3), omega (Section 6)
  [ok]   L_4, L_8, L_12 mutually anticommute and square to -Id
  [ok]   A=L8L12, B=L4L8, C=L4L12: skew, square -Id, pairwise anticommuting, AB = C
  [ok]   [B,C]=2A, [C,A]=2B, [A,B]=2C
  [ok]   J = tau L_4: J^2 = -Id, J skew, [J,A]=[J,B]=[J,C]=0
  [ok]   [tau, L4] = 0, {tau, L8} = {tau, L12} = 0
  [ok]   K3 = J A, K1 = -J B, K2 = -J C
  [ok]   K_i symmetric with K_i^2 = Id
  [ok]   J and all six commute with colour
  [ok]   omega symmetric involution commuting with the six, with J and with colour
  [ok]   omega = -1 on Q, +1 on Q^perp
  [ok]   the six, J, omega and colour preserve Q and Q^perp
  [ok]   J|_Q = R_{e_4}|_Q
  [ok]   R_{e_8}^2 = -Id on S (S is a right C_e-space)
  [ok]   span{A,B,C,K1,K2,K3} closes under bracket; Killing signature (+,0,-) = (3, 0, 3)
  [ok]   commutant of so(1,3) + colour: nullity_P = 4; {1, J, omega, omega J} commute exactly and are independent
  [ok]   commutant of su(2)_Q + colour on S: nullity_P = 6; exhibited basis 1_Q, R_4|_Q, R_8|_Q, R_12|_Q, 1_Qperp, J|_Qperp
  [ok]   on Q: R_8 commutes with A,B,C and anticommutes with K1,K2,K3  (so(1,3)|_Q is symplectic for sigma_{R_8})
  [ok]   on Q: the same holds for R_12 (the circle R_{cos t e_8 + sin t e_12})
  [ok]   for J = A the symplectic members of the six are A, K1, K2: [True, False, False, True, True, False]
  [ok]   for J_0 = -L_4 the symplectic members are A, K1, K2: [True, False, False, True, True, False]
  [ok]   no colour-and-su(2)-invariant complex structure on Q^perp anticommutes with J (commutant there is {1, J}, dim 2 by the certificate above)

C7. The odd Cl(0,8) system, tau, and the hypercharge Y (Section 6.6)
  [ok]   Cl(0,8) relations for Gamma_i = L_{e_{8+i}}
  [ok]   tau anticommutes with every Gamma_i
  [ok]   anticommutant of the odd system: nullity_P = 1, spanned by tau (exact)
  [ok]   tau = +/- Gamma_0 ... Gamma_7 (the volume element)
  [ok]   Y commutes with A,B,C,K1,K2,K3, tau, colour
  [ok]   Y^2 = -9 on Q and -1 on Q^perp; Y|_Q = 3 R_4|_Q
  [ok]   Y lies in the commutant span{1,J,omega,omega J}: Y = J(2 - omega) is True, Y = J(1 - 2 omega) is False
  [ok]   Gamma_1Gamma_5, Gamma_2Gamma_6, Gamma_3Gamma_7 commute pairwise and square to -Id
  [ok]   J_0 = -L_4 pairs (e_1,e_5),(e_2,e_6),(e_3,e_7)
  [ok]   the 36 bivectors of the Cl(1,8) system have rank 36; adjoining A,K1,K2 keeps 36, adjoining B,C,K3 gives 37: {'A': 36, 'B': 37, 'C': 37, 'K1': 36, 'K2': 36, 'K3': 37}

C8. A_5: annihilator strata and the exact composition witness (Section 5)
  [ok]   the 84 elements e_i +/- e_j (i in 1..7, j in 9..15, j-8 != i) are all zero divisors of S with 4-dim kernel
  [ok]   S: x = e_1+e_10, y = [0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0]: ||xy||^2 = 8, ||x||^2||y||^2 = 4  -> ratio^2 = 2 exactly
  [ok]   A_5: the 930 two-term elements e_i +/- e_j (1 <= i < j <= 31) have annihilator dimensions [0, 4, 8, 12] with counts {0: 342, 4: 168, 8: 168, 12: 252}
    representative with dim ker = 4: e_1 + e_26
    representative with dim ker = 8: e_1 + e_10
    representative with dim ker = 12: e_1 + e_18
    (z,0) in A_6 for the dim-4 representative: dim ker = 8
    (z,0) in A_6 for the dim-8 representative: dim ker = 16
    (z,0) in A_6 for the dim-12 representative: dim ker = 24
  [ok]   annihilator dimension doubles under z -> (z,0) (Lemma 5.2), checked on the three representatives
    witness x = +e_1 +e_10 +e_18 -e_25
    witness y = -e_4 -e_15 -e_23 +e_28
    ||x||^2 = 4, ||y||^2 = 4, ||xy||^2 = 64, top eigenspace dim = 4
  [ok]   A_5: exact pair with ||xy||^2 = 4 ||x||^2 ||y||^2, i.e. composition ratio exactly 2
  [ok]   hence c_5 = 2 exactly (upper bound by Theorem 5.1, lower bound by the witness)

C9. Zero divisors exhibited for the split classes (Section 4.2)
  [ok]   e_1 - e_13 in S_8: dim ker L = 4
  [ok]   e_4 + e_15 in twin^perp: dim ker L = 4
  [ok]   e_4 + e_9 in S_8^perp: dim ker L = 4

C10. The colour-singlet observable skeleton and the up/down involutions (Section 10.2)
  [ok]   commutant of colour in End(S): nullity_P = 24; exhibited basis End(Q) (16) + {1,J,A,B,C,JA,JB,JC}|_Qperp (8) commutes exactly and has rank 24
  [ok]   J-linear colour-singlet operators: nullity_P = 16; exhibited basis {1,J,A,B,C,JA,JB,JC} on Q and on Qperp commutes exactly and has rank 16
  [ok]   each block is closed under multiplication: two copies of H (x) C = M_2(C), with J central and A,B,C the quaternion units
  [ok]   for n = e_4, e_8, e_12: J_n J is a symmetric involution, traceless on Q and on Qperp (the up/down eigenplanes are 2-dimensional)
  [ok]   the centre of A_0 is span{1_Q, J_Q, 1_Qperp, J_Qperp} = span{1, J, omega, omega J} (the commutant of 6.5(3)); Y commutes with all of A_0 and lies in it
  [ok]   the unit 1 is annihilated by colour and by every derivation lift, and fixed by tau

C11. The canonical complex structure R_{e_8} and the canonical quantisation (Sections 3.7, 8.2, 8.4)
  [ok]   R_{e_8} is skew with square -Id; it commutes with every derivation lift and with colour; tau R_{e_8} tau = -R_{e_8}
  [ok]   for sigma_e = <x, y e_8>: on Q all six are symplectic [True, True, True, True, True, True]; on Qperp exactly C, K1, K3 are [False, False, True, True, False, True]
  [ok]   {C, K1, K3} closes: [C,K1] = 2K3, [C,K3] = -2K1, [K1,K3] = -2C  (an so(1,2))
  [ok]   no bivector of either Cl(0,8) system is symplectic for sigma_e (0 + 0 of 56); of the boosts tau Gamma_i exactly tau Gamma_0 = K1 is: [True, False, False, False, False, False, False, False]
  [ok]   the unit 1 is not separating for A_0: A_0 . 1 = Q (so no faithful vector state, no modular flow)

C12. The coloured so(6) of the odd system and the complex structure omega J (Section 6.7(6))
  [ok]   omega J = -tau Gamma_0 Gamma_4 (built from the odd system and the grading alone)
  [ok]   omega J commutes with all 15 bivectors of so(6)_c; J does not
  [ok]   colour lies inside so(6)_c: rank of the 15 bivectors is 15, unchanged when colour is adjoined
  [ok]   each colour derivation D equals its bivector (1/4) sum_ij M_ij Gamma_i Gamma_j with [D,Gamma_k] = sum_j M_jk Gamma_j (exact, up to the sign convention)
  [ok]   commutant of so(6)_c: nullity_P = 8; exhibited basis of rank 8 commutes exactly; omega J is central in it
  [ok]   commutant of so(1,3)_Q + colour + so(6)_c: nullity_P = 2; spanned by 1 and omega J -> the invariant complex structures are +/- omega J only
  [ok]   readings of Y: tr(J Y) = -24 (not a branching), tr(omega J . Y) = 0; Y = -3 omega J on Q and + omega J on Qperp (the branching 4 -> 3_1 + 1_-3)

C13. R_{e_8} versus omega J, and why no squeeze is unitary (Sections 8.6-8.7)
  [ok]   [R_{e_8}, omega J] = -2 R_{e_12} P_Q exactly; the two commute on Qperp
  [ok]   on Qperp, R8.omegaJ is a symmetric involution; Qperp = V+ (R8 = omega J) + V- (R8 = -omega J) with dims 6, 6
  [ok]   V+ and V- are colour-invariant and C-invariant; the boosts K1, K3 exchange them; A, B do not preserve them
  [ok]   every boost K_i and every tau Gamma_i is a symmetric involution with trace 0 (eigenvalues +1, -1 each of multiplicity 8), so e^{tX} has eigenvalues e^{+t}, e^{-t}
  [ok]   the J_e-linear operators commuting with tau form a space of dimension 64 (many standard subspaces have J_H = tau: none is canonical)

C14. so(1,3)_Q versus so(6)_c, and the boosts as CAR reflections (Section 12)
  [ok]   of the six, exactly A, K1, K2 commute with the Pati-Salam so(6)_c: {'A': True, 'B': False, 'C': False, 'K1': True, 'K2': True, 'K3': False} -> so(1,3)_Q and su(4) do not commute on S
  [ok]   Y commutes with all of so(1,3)_Q, so S is a module for so(1,3)_Q + colour + u(1)_Y jointly
  [ok]   each boost K_i is an orthogonal involution (a CAR-Bogoliubov reflection), while e^{tK_i} is not orthogonal for t != 0

C15. Ranks on the 'neither' edges; Lie algebras generated by the thirty generators (Theorem 2.7)
  [ok]   L-L neither edges: rank of {L_i,L_j} is 8 on all 42 ({8: 42}); L-R neither edges: rank of [L_i,R_j] is {12: 126, 4: 84}, rank 4 exactly on the exceptional pairs (i,8+j),(8+j,i)
  [ok]   the thirty generators generate a Lie algebra of dimension 120 = dim so(16) (mod-p lower bound; it is contained in so(16), so equal); with tau, dimension 255 = dim sl(16)

C16. The native action of S on its doublings A_5 = S + S e_16 and A_6 (Section 13)
  [ok]   for x in S: L^(5)_x = L_x (+) R_x on A_5, and L^(6)_x = L_x (+) R_x (+) R_x (+) R_xbar on A_6 (block-diagonal)
  [ok]   tau (+) tau (+) tau (+) tau is an automorphism of A_6
  [ok]   intertwiner spaces between the copy types (dim; Q-part; Qperp-part): L->L (4, 2, 2), R->R (4, 2, 2), L->R (2, 2, 0), L->Rbar (4, 2, 2), R->Rbar (2, 2, 0)
  [ok]   commutant of so(1,3)_Q + colour: on A_5 dim 12 = M_2(C) + C + C (a doublet on the singlet block only); on A_6 dim 48 = M_4(C) + M_2(C) + M_2(C) (two inequivalent coloured doublet classes {L,Rbar} and {R,R}, and a singlet quartet)
  [ok]   canonical intertwiners: C R_{e_8}|_Q and C R_{e_12}|_Q from the L-copy to the R-copy (singlet block); conjugation C from the L-copy to the Rbar-copy (all of S)

C17. Multiplicity pattern on A_7; the doublet su(2) is not a derivation of A_5 (Section 13)
  [ok]   A_7 native action: copy types ['L', 'R', 'R', 'Rbar', 'R', 'Rbar', 'Rbar', 'R'] -> L:1, R:4, Rbar:3, so the two coloured classes {L,Rbar}, {R} each have multiplicity 4 = 2^(7-5)
  [ok]   on A_5 the mixing operators M1 = [[0,-T1^T],[T1,0]], M2 (T1 = C R_8 P_Q, T2 = C R_12 P_Q) and [M1,M2] span a 3-dimensional Lie algebra commuting with the native so(1,3)_Q + colour (the doublet su(2))
  [ok]   the doublet generators are not derivations of A_5: the Leibniz defect of M1 is nonzero on 640 of the 1024 basis pairs (the doubling's product breaks the doublet)
  [ok]   the colour-fixed subspace of the odd index space is exactly span{Gamma_0, Gamma_4}; its complement W is canonical and so(6)_c is the bivector algebra of W

C18. Box-kites (Theorem 2.8), quaternion subalgebras (2.9), tau-graded Malcev survival (4.4(iii)), K_1 triplets (7.8)
  [ok]   tau-graded Malcev survival: defects for tau-even x 0, tau-odd x 0 (y in Im O, all z); inhomogeneous x gives 3360 defects; y in Im S gives 1848
  [ok]   the analogous survival fails for the twin grading (720, 1440 defects) and for the S_8 grading (1440, 1728): Malcev survival characterises the tau-kind
  [ok]   box-kites: the 84 two-term zero divisors e_i +- e_{8+j} (i != j) lie in 42 assessor planes; each annihilates exactly 4 others; the annihilation graph is 7 octahedra K_k, k a point of the basis Fano plane, whose 3 struts are the Fano lines through k
  [ok]   orientation bits: tau flips all 84 diagonals; the twin involution phi (fixing <1,e1,e2,e3>, negating e4..e7) fixes every diagonal of the kites K_1,K_2,K_3 = [1, 2, 3] and flips every diagonal of K_4..K_7 = [4, 5, 6, 7]; tau phi flips 36
  [ok]   each assessor spans with 1 and e_i e_{8+j} a quaternion subalgebra of the zero-divisor type (its diagonals are zero divisors, its third unit is not)
  [ok]   K_1 = tau L_8 splits Qperp into +1 and -1 eigenspaces of dimension 6 and 6, colour-invariant, exchanged by tau (and Q into 2 + 2)

C19. Graded contractions of Im O and Im S; the (H, l) frame of O; B1/B2 quaternion subalgebras (2.9, 4.7)
  [ok]   Im O is Malcev (0 defects) and its contraction along the quaternion grading (kill [odd,odd]) is Malcev (0 defects)
  [ok]   Im S is not Malcev (11088 defects) and its contraction along each split kind is not Malcev either: {'tau': 3948, 'twin': 4032, 'S8': 4812}
  [ok]   the (H, l) frame of Im O = P + W + X has bracket table [P,P] in P, [P,W] in X, [P,X] in W+X, [W,X] in P, [X,X] in P: {('P', 'P'): ['P'], ('P', 'W'): ['X'], ('P', 'X'): ['W', 'X'], ('W', 'P'): ['X'], ('W', 'X'): ['P'], ('X', 'P'): ['W', 'X'], ('X', 'W'): ['P'], ('X', 'X'): ['P']}
  [ok]   B1 <1,e_1,e_8,e_9> consists of alternative elements; B2 <1,e_1,e_10,e_11> does not (it is a quaternion subalgebra containing zero divisors)
  [ok]   doubling along the three Fano lines through e_1: type A ['alt', 'alt', 'alt'], B1 ['alt', 'alt', 'alt'] (three octonion subalgebras), B2 ['alt', 'zd', 'zd'] (one octonion, two with zero divisors)

C20. so(6)_c = centraliser of {A,K1,K2} in so(1,8); the A_6 doublets are broken by the product; the presentation is a CAR algebra (2.10, 6.12)
  [ok]   the centraliser of {A, K1, K2} in so(1,8) has dimension 15 and equals so(6)_c
  [ok]   on A_6 the coloured doublet generators are not derivations of the product: Leibniz defects 1260, 1836 ({R,R} class) and 4096 ({L,Rbar} class) of 4096 basis pairs
  [ok]   the even system is a CAR algebra: {L_i, L_j} = -2 delta_ij, so gamma_i = i L_i (i = 1..8) are eight Majorana operators; S (x) C = C^16 = 2^4 is the Fock space of four modes
  [ok]   the mediator pairs the eight Majoranas as (e_8,e_4),(e_1,e_5),(e_2,e_6),(e_3,e_7); the four number bivectors L_a L_b commute pairwise and square to -1
  [ok]   the joint eigenline of the four number bivectors (the Fock vacuum of the presentation) is the real plane spanned by [-1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0] and [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0], i.e. (1 - e_8) C_{e_4}, inside Q
  [ok]   tau carries the vacuum plane (1 - e_8) C_{e_4} to (1 + e_8) C_{e_4}

C21. The pairing of the even Clifford generators is the colour-commuting complex structure on V_E (Theorem 6.12)
  [ok]   colour acts on V_E = span{L_1..L_8} by commutators, fixing exactly the plane span{L_4, L_8}
  [ok]   the commutant of colour in End(V_E) has dimension 6 = 4 (fixed plane) + 2 (W_E); on W_E it is span{1, J_W} with J_W = (L_x -> L_{e_4 x}), so the colour-commuting complex structures on W_E are exactly +- J_W (Schur)
  [ok]   with J = J_W on W_E and the 90-degree rotation on span{L_4, L_8}, the basis-free vacuum condition (L_v + i L_{Jv}) Omega = 0 for all v in V_E has the solution Omega = x + i y with real plane (1 - e_8) C_{e_4} subset Q
  [ok]   the four sign choices of J give exactly the two planes (1 - e_8) C_{e_4} and (1 + e_8) C_{e_4}, exchanged by tau

C22. K_1 = tau L_8 on the seam and the background disk; unimodularity of so(1,3)_Q (Theorem 7.9)
  [ok]   the six generators of so(1,3)_Q are traceless: the group they generate is unimodular on S, so its pullback action on L^2(S) is unitary
  [ok]   K_1 commutes with every derivation lift (D e_8 = 0, [D, tau] = 0): it is canonical given the world alone
  [ok]   K_1 acts on the doubly-pure subspace as the swap (u,w) -> (w,u), preserving it and mapping the seam to itself (all 84 two-term zero divisors)
  [ok]   along e^{tK_1} every seam point acquires failure index beta/N = 1/cosh(2t), i.e. |Q| = tanh(2t) in the background disk (30 seam points, cosh t = 5/4, 13/12, 17/8)
  [ok]   mediator-dependent boosts differ: K_2 maps the mediator-orthogonal seam point e_1+e_10 along the seam (failure index stays 1) but carries the mediator-aligned seam point e_4+e_9 out of the doubly-pure subspace; K_3 moves e_1+e_10 radially like K_1

C23. S as a twisted group algebra of Z_2^4 with a {+-1}-valued associator cocycle (1.7); R-flux contractions (4.7 revised)
  [ok]   Cayley-Dickson basis of S: e_i e_j = F(i,j) e_{i XOR j} for all i, j (so S = R_F[Z_2^4])
  [ok]   the associator sign phi = dF is a {+-1}-valued 3-cocycle on Z_2^4 (identity on all 65536 quadruples); phi = -1 on 1848 of 4096 basis triples (168 of 512 for O)
  [ok]   1+3+3 filtration contraction of Im O with weights X:1, P:2, W:3 exists, is Malcev (0 defects), has [x,x] in P, [x,p] = 2 delta I, [p,p] = 0, I central, and Jacobiator [x1,x2,x3] = [0, 0, 0, 0, 12, 0, 0, 0] = 12 I (the R-flux / monopole algebra)
  [ok]   Im S admits a Malcev filtration contraction extending it (weights e_8:1, P':1, W':2, X':2): 56 surviving brackets, 0 Malcev defects; shape V1 (7 coordinates) + V2 (7 momenta) + R e_4 (central), seven Heisenberg pairs, flux 3-form on the 7 lines of a Fano plane with components [4, 12]

C24. Contractions of Im O up to Fano collineations (4.7(vi)); the centre of S
  [ok]   contractions of Im O with weights in {0..6}: 17 orbits of nonzero limits, 4 non-Lie (the trivial one, the su(2)-fixed one, a u(1)-fixed one, and R-flux); with strictly positive weights: 13 orbits, exactly 1 non-Lie (R-flux)
  [ok]   locked ratio in the R-flux limit: [x_1,p_1] = 2 W and [x_1,x_2,x_3] = 12 W, ratio 6
  [ok]   the centre of S has dimension 1: it is R 1 (the unit is the only central element)

C25. The seam bundle's canonical connection; Y on the R-copies; tau_16 tau_32 on A_6 (Section 11.7, 13.7)
  [ok]   g_2 = su(2)_q + m is reductive (dim 3 + 11); the curvature values [m,m]_h of the canonical connection on G_2 -> G_2/SU(2)_q span su(2)_q (rank 3): full holonomy
  [ok]   on the R-type copies the hypercharge is Y_R = C Y_L C (conjugation), with Y_R^2 = -9 on Q, -1 on Qperp, Y_R|_Q = -3 L_4, commuting with colour, with the R-copy rotations and with tau
  [ok]   tau_16, tau_32 and tau_16 tau_32 are automorphisms of A_6; tau_16 tau_32 is +1 on the coloured class {L,Rbar} (copies 0,3) and -1 on {R,R} (copies 1,2)
  [ok]   the doublet generator on A_5 is not a sigma-twisted derivation for sigma in {1, tau^, tau_16, tau^ tau_16}: defects [640, 640, 640, 640] of 1024

C26. The seam bundle G_2 -> G_2/SU(2)_q: curvature on m', quaternionic structure, Yang-Mills (Theorem 3.8)
  [ok]   so(4) = su(2)_q + su(2)_p (3+3) and m = su(2)_p + m' (3+8); the curvature Omega = -[.,.]_h vanishes on su(2)_p x m and has rank 3 on Lambda^2 m'
  [ok]   su(2)_q acts on m' by three anticommuting complex structures (up to scale) and trivially on su(2)_p: m' is quaternionic and the three components of Omega are its Kaehler forms <X, ad(h_a) Y>/|h_a|^2
  [ok]   the canonical connection is Yang-Mills for the normal metric: sum_ij g^ij [E_i,[E_j,X]_m]_h = 0 for all X in m

C27. Base case and recursion of the lifting quadruple (x,y,b,d) (Theorem 5.6)
  [ok]   base case n = 4: x = e_1+e_10, y = -e_7+e_12, b = e_2-e_9, d = e_4+e_15 are pure, |x|=|b|, |y|=|d|, |xy|^2 = 2|x|^2|y|^2, |dx|^2 = 2|d|^2|x|^2, db = xy, by = -dx, and <x,d> = <x,y> = <b,y> = <b,d> = 0
  [ok]   the recursion (x,y,b,d) -> ((-x,b),(-y,d),(b,x),(d,y)) preserves all invariants with c^2 doubled, verified through A_8 (the general step is proved algebraically in Theorem 5.6)

======================================================================
failures: 0
```

The output of `c28_doubling.py`, followed by those of `c29_frames.py`, `c30_open_items.py` and `c32_filtrations.py`:

```
C28. Definability of the doubling: conjugation from the quadratic identity; the lifts (Theorem 8.5(4))
  [ok]   conjugation read off the S-table by x^2 = t x - n: t = (2,0,...,0), conj = t - id
  [ok]   the doubling of the S-table with this conjugation reproduces the A5 table entry by entry (2 x 1024 signed entries)
  [ok]   iterating the same doubling from R reproduces A_1..A_6 (the tower is definable from every level, including R)
  [ok]   hat-tau = tau (+) tau is an automorphism of A5 (all 1024 basis pairs)
  [ok]   D conj = conj D on O for all 21 generators D_{a,b} (the identity used in the inline proof)
  [ok]   all 21 generator lifts D_{a,b} (+) D_{a,b} satisfy Leibniz on A5 (all 1024 basis pairs)
  [ok]   mu commutes with the conjugation (exact over Q(sqrt 3))
  [ok]   mu^3 = 1 (exact); mu(e8) = e8
  [ok]   hat-mu = mu (+) mu is an automorphism of A5 (all 1024 basis pairs, exact over Q(sqrt 3))

failures: 0
```

```
C29. The Cayley-Dickson frames of the presentation (Theorem 3.9)
  [ok]   the generation rule is read off the standard basis: f3=f1f2, f5=f1f4, f6=f2f4, f7=f3f4, F_{8+i}=F_i F_8
  [ok]   the standard datum (O, +1, (e1,e2,e4)) regenerates the standard basis
  [ok]   the frame of (O, +1, (e1,e5,e2)) satisfies the table of Definition 0.1 on all 256 pairs
  [ok]   the frame of (O, -1, (e1,e2,e4)) satisfies the table on all 256 pairs (the tau image)
  [ok]   the frame of (O, +1, ((e1+e2)/sqrt2, (e1-e2)/sqrt2, e4)) satisfies the table, exactly over Q(sqrt 2)
  [ok]   the frame of (mu O, +1, (mu e1, mu e2, mu e4)) satisfies the table, exactly over Q(sqrt 3)
  [ok]   the generated mu-world frame agrees with the mu-images of the basis (consistency with C28)

failures: 0
```

```
C30. The Lie closure of the doublet with the native mixing operators (13.7(iii))
  [ok]   dim< doublet su(2), L_16, R_16 > = 17 exactly: Q-independent basis, all 136 brackets and the generators in the span (exact echelon reduction)
  [ok]   the closure consists of skew operators: a compact Lie algebra
  [ok]   centre of dimension exactly 2: two exact central elements exhibited; mod-p bound 2 from the commuting system
  [ok]   derived algebra of dimension exactly 15, and centre + derived = the whole algebra (direct sum)
  [ok]   rank of the semisimple part = 3: an exact commuting independent triple in the derived algebra, and a generic centralizer of dimension 5 = 2 + 3 [mod-p]
        => the closure is u(1)^2 (+) su(4): compact, centre 2, semisimple part of dimension 15 and rank 3 (the unique such algebra)
  [ok]   the rotation A = L_8 L_12 is not in the closure: it differs from the direct sum su(2) (+) (so(1,3)_Q (+) colour) of the same dimension 17
  [ok]   dim< doublet, L_16, R_16, native so(1,3)_Q + colour > = 81 exactly: all 3240 brackets and the generators in the span (exact)

C31. The zero-divisor stratum of A_5 has dimension 24 > 14 = dim Aut(A_5) (Section 11, item 8)
  [ok]   witness z1 = 2e1+e2+e5-e25+2e26+e30 (norm^2 = 12): rank L_{z1} = 28 exactly, corank 4
  [ok]   the derivative of the Schur chart, dz -> P_K L_dz|_K into the skew forms on ker L_{z1}, has rank 6 exactly: a submersion
        => near z1 the corank-4 locus is a manifold of dimension 31 - 6 = 25 in Im A_5, i.e. 24 after normalisation;
           every Aut(A_5)-orbit has dimension at most dim G_2 = 14, so the unit zero divisors of A_5 meet uncountably many orbits
  [ok]   at the two-term witness e1+e26 the same derivative has rank only 3: the chart is degenerate on that orbit, and the dimension count needs a generic witness
C34. The su(4) of the closure against the coloured so(6)_c (the comparison of 13.7(iii))
  [ok]   the su(4) vanishes on the 24 coordinates outside V = Q + Q e_16, preserves V, acts faithfully on it and fixes no vector of it: its fixed space is exactly the 24-dimensional complement
  [ok]   End of the su(4) on V is exactly two-dimensional and contains an exhibited exact complex structure, and no element of R+R squares to -1: V is one irreducible realified quartet, so the commutant of the su(4) on A_5 has dimension 24^2 + 2 = 578
  [ok]   so(6)_c on S: eight exhibited commuting operators, independent, and the commutant has dimension exactly 8 (mod-p bound both ways); fixed space 0 -- so the diagonal lift to A_5 has commutant of dimension 4*8 = 32 and no fixed vector
  [ok]   the su(4) of the closure and the lifted so(6)_c intersect in 0 inside so(32); their commutant dimensions 578 and 32 are conjugation invariants, so the two are not conjugate in GL(32,R): the isomorphism su(4) = so(6) is abstract only

failures: 0
```

```
C32. Completeness of the contraction classification of Im O (Proposition 4.7(vi))
  [ok]   weights <=6: 18 collineation orbits of surviving-edge sets (17 nonzero), 14 with positive weights (13 nonzero)
  [ok]   every realisable surviving-edge set is closed under linear span; the closed sets number exactly 5847
  [ok]   exactly 520 closed sets are realisable, each certified by an integer witness with entries at most 4
  [ok]   exactly 484 of them are realisable with strictly positive weights, entries at most 4
  [ok]   the remaining 5327 closed sets are infeasible, each decided by the exact rational simplex
  [ok]   the realisable sets fall into the same 18 (resp. 14) orbits as the weights<=6 survey: the classification of 4.7(vi) is complete for all weights

C33. Block extensions of the R-flux filtration on Im S (Proposition 4.7(v))
  [ok]   the block-level commutator structure of Im S has exactly 31 edges
  [ok]   exactly 43 surviving patterns are admissible over all non-negative integer extension weights: each has an exhibited witness; every other closed cell is either infeasible over the rationals or (11 cells) rationally feasible but confined to the surveyed box with no integer point
  [ok]   exactly 39 of the 43 patterns have Malcev limits: the Malcev property does not select a filtration
  [ok]   exactly two patterns attain the maximal surviving structure (9 block edges): the extensions (1,1,2,2) and (2,2,1,1), both with 28 bracket pairs, a one-dimensional centre and jacobiator on 7 triples

failures: 0
```

## Appendix C. Dictionary of readings

Every physical name used in this paper labels an intrinsic object of $S$ defined by a theorem. No deduction uses the name. A reader who rejects a reading loses a word, not a result.

| name | intrinsic object | defined in |
|---|---|---|
| world | an octonion subalgebra in the canonical $\Sigma_3$-orbit | 3.3, 4.6 |
| grading / time | the involution $\tau$ of the $\tau$-kind | 4.1, 4.4; time is [STANCE] 10.6 |
| mediator | a unit of $\mathrm{Im}\,\mathbb O$ (one $G_2$-orbit) | 6.0 |
| colour | the stabiliser $\mathfrak{su}(3)$ of the mediator in $\mathfrak g_2$ | 6.1 |
| rotations | $\mathfrak{su}(2)_Q=\mathrm{span}\{A,B,C\}$ | 6.3 |
| boosts, Lorentz | $\mathcal J\,\mathfrak{su}(2)_Q$, $\mathfrak{so}(1,3)_Q$ | 6.4 |
| Weyl spinor | the real irreducible $\mathfrak{so}(1,3)_Q$-module on which rotations act as spin-$\tfrac12$ | 6.5 |
| chirality, handedness | on $S$: the sign of the complex structure (6.6, [SELECTED]); between the two presentations: left versus right (13.1(3)) | 6.6, 13.1 |
| hypercharge | the $\mathfrak u(1)$ centralising colour in $\mathfrak{so}(1,8)$; $Y=\mathcal J(2-\omega)$ | 6.7 |
| Pati–Salam $\mathfrak{su}(4)$ | the bivector algebra $\mathfrak{so}(6)_c$ on the coloured index directions | 6.7(6) |
| $B-L$ pattern | the traceless reading of $Y$ relative to $\omega\mathcal J$ | 6.7(5)–(6) |
| squeeze, seed of dynamics | the symmetric involutions $\tau\Gamma_i$, $K_i$ | 7.2 |
| time, scale line | the rapidity of the canonical squeeze $K_1=\tau L_{e_8}$; along its flow the disk radius is $\tanh2t$ and the failure index $\operatorname{sech}2t$ (7.9(2)) | 7.9 (stance in 10.6) |
| $xp$ Hamiltonian | the canonical squeeze on $L^2(\mathbb O)$: $\sum_{i=1}^7D_i-D_0$, signature $(7,1)$ | 7.9(7) |
| quantisation | a choice of complex structure; the passage to a Weyl or Clifford algebra is [CRITERION] | 7.1, 8.2 |
| vacuum | the Fock state of $(S,\sigma_e)$ | 8.4 |
| configuration space, momentum space | the world $\mathbb O$ and its shadow $\mathbb Oe_8$, Lagrangian for $\sigma_e$ | 3.7(iv) |
| thermal state, temperature | the Gibbs family of the canonical number operator; $\beta$ is not supplied | 8.9(3) |
| up/down along $n$ | the eigenplanes of $J_n\mathcal J$ (sharp); effects $0\le E\le1$ are the unsharp generic case | 10.2(2), 10.4 |
| being / doing | states (the convex set of expectation functionals) / effects (bounded, continuous, of limited resolution) — a reading | 10.2–10.4 |
| superselection | the centre of $\mathcal A_0$ | 10.2(3) |
| weak isospin | *a reading, and a partial one*: the multiplicity $\mathfrak{su}(2)$'s of the two presentations on the doublings. They are symmetries of $S$'s action, not of the doubling's product (13.3); a gauged isospin is a symmetry of the interactions, which these are not shown to be | 13.2, 13.3 |
| generation | *a reading*: the $\mathfrak k$-module $A_6$, the first doubling with multiplicity on the coloured block; the singlet block already has it at $A_5$ | 13.2, 13.4 |
| Majorana modes of the presentation | the Clifford cliques of 2.4 read as CAR algebras | 2.10 |
| vacuum of the presentation | the joint eigenline $(1-e_8)\mathbb C_{e_4}\subset Q$ of the mediator's number bivectors | 6.12 |
| box-kite, assessor, strut | the annihilation octahedra of the two-term zero divisors, their planes, their Fano lines | 2.8 |
| three-space, colour space | $\mathrm{Im}\,Q=\langle e_4,e_8,e_{12}\rangle$ (the adjoint of the rotations, colour-blind) / $\mathrm{Im}\,\mathbb O=\mathbb Re_4\oplus\mathbb C^3$ (coloured) | 6.13 |
| field (internal) | a function on the world (3.7(iv)); the twist $F$ as a connection on $\mathbb Z_2^4$ with curvature $\varphi$ (1.7); the canonical Yang–Mills connection on the seam bundle (3.8) | — |
| equation of motion | the Yang–Mills equation satisfied by the seam bundle's canonical connection; the only one in the paper | 3.8(5) |
| orientation bit, mirror parity | the diagonal sign of an assessor and its behaviour under the three involution kinds | 2.8 |
| domain-wall triplet | a $\pm1$ eigenspace of a boost on the coloured block | 7.8 |
| $1+3+3$ ($W/P/X$) | the Cayley–Dickson frame $(\mathbb H,\ell)$ of $\mathbb O$; a filtration, not a grading | 4.7, 1.5, 6.1 |
| flux, monopole charge | the $\mathbb Z_2$-valued associator cocycle $\varphi=\delta F$; the Jacobiator of the R-flux contraction | 1.7, 4.7(iv) |
| R-flux algebra, coordinates/momenta | the filtration contraction of $\mathrm{Im}\,\mathbb O$ (weights 1,2,3) and of $\mathrm{Im}\,S$ | 4.7(iv)–(v) |
| $\hbar$ (placeholder) | the central element $W$ of the R-flux limit ($\ell$; for $S$, the mediator $e_4$), scalar by Schur, locked to the flux in the ratio $1:6$; not the unit of $S$ | 4.7(vii) |
| B1 / B2 quaternions | quaternion subalgebras through $e_8$ (alternative) versus through other shadow directions (zero divisors) | 2.9 |
| left–right-symmetric content | the two inequivalent coloured doublet classes | 13.1(2), 13.4 |

### C.2 Canonical objects without a reading, and readings that fail

A dictionary invites the objection that a rich algebra can be made to match any terminology by choosing which of its objects to name. The answer is an inventory: the canonical objects this paper derives are few, they are defined as stabilisers, centralisers, commutants and orbits rather than chosen among alternatives, and several of them have no physical reading at all, while one proposed reading fails. A reader can judge the match rate from the whole list.

| canonical object | defined in | reading |
|---|---|---|
| the seam $Z\cong G_2/SU(2)$ and its cone | 3.5 | none in the Standard Model; the program's [STANCE] |
| the background disk and the failure index | 3.6, 1.6 | none; the clock of 7.9 is a reading |
| the three worlds ($\Sigma_3$-orbit) | 3.4 | "three generations" **fails** (12.1: $S$ is a quarter of one) |
| $\mathfrak{so}(1,8)$ of the odd system | 6.7 | none (a nine-dimensional Lorentz algebra) |
| the two $\mathfrak{so}(8)$'s of the Clifford cliques | 2.4 | none |
| the quaternionic $\mathfrak{su}(2)_R=R_{\mathrm{Im}\,Q}$ on $Q$ | 12.3(3) | none (broken by boosts; not an internal symmetry) |
| the non-commutation of $R_{e_8}$ and $\omega\mathcal J$; the split $V_\pm$ | 8.7 | none |
| the vacuum plane $(1-e_8)\mathbb C_{e_4}$ of the presentation | 6.12 | none |
| the box-kites and their Fano labelling | 2.8 | none in the Standard Model |
| the composition constants $c_n=2^{(n-3)/2}$ | 5.6 | none |
| the $\mathbb Z_2$ associator cocycle; the R-flux contraction | 1.7, 4.7 | a reading outside the Standard Model (monopole / R-flux) |
| colour, Lorentz, hypercharge, $\mathfrak{so}(6)_c$, chirality, the doublets | §6, §13 | the readings of C.1 |

The objects with Standard-Model readings are the stabiliser of a mediator, the Lorentz completion of the rotations of the quaternion block, the $\mathfrak u(1)$ centralising colour in $\mathfrak{so}(1,8)$, the centraliser of the shared $\mathfrak{so}(1,2)$, and the module structure of the two presentations. That these five canonical constructions carry the readings they do is the evidence the paper offers; that seven others carry none, and that the reading most natural to the program's founding intuition — three worlds, three generations — is refuted by a dimension count, is the evidence that the dictionary was not written backwards from the answer key.

## Appendix D — provenance

Each ledger row of §9 is classified against the literature. **Classes.** K — statement known; the paper contributes citation and machine verification. KP — statement known; the paper's proof is independent and self-contained. NA — new assembly: every input is standard and cited, but the assembled statement was not found in the literature. N — statement and proof not found in the literature. R — criterion, selection, boundary or reading; not a mathematical novelty claim.

**Search scope.** Novelty is asserted relative to the following searched corpus and nothing more: Biss–Christensen–Dugger–Isaksen 2009 and Biss–Dugger–Isaksen 2008; Moreno 1998 and 2005; de Marrais; Chan–Đoković; Baez 2002; Schafer; Springer–Veldkamp; Reggiani 2024 (arXiv:2411.18881); Wilmot 2025 (arXiv:2505.11747); the determinant-factorisation preprint arXiv:2512.13002; the Potton letter; and the standard-theory anchors already cited (Laquer, Bargmann, Bruck–Kleinfeld, Knapp, Takesaki, Busch, Jackiw, Bakas–Lüst, Günaydin–Lüst–Malek, Pati–Salam). A classification of N or NA is a report that the searched corpus does not contain the statement, not a guarantee that no literature does.

| row | class | anchor / note |
|---|---|---|
| 1.1 identities | K | Cayley–Dickson standard (Schafer; Moreno). |
| 1.3 bridge; 1.4 bounds | KP | adjacent to Moreno 1998 / BCDI eigentheory; proofs self-contained. |
| 1.5 tunnel lemma | KP | BCDI 2009 §7 (credited); proof independent. |
| 1.6 spectral zero-divisor test | KP | BCDI 2009 Cor. 4.8 territory; the determinant preprint 2512.13002 is a parallel elaboration. |
| 1.7 twisted group algebra, cocycle | KP | Albuquerque–Majid 1999, Flaut–Boboescu 2021, Ren–Zhao 2022 (cited); the explicit F for A₄ verified independently. |
| 2.1–2.5 pattern, cliques, generation | KP | the anticommutation pattern is implicit in Moreno/de Marrais; the clique census [EXACT] is new bookkeeping. |
| 2.7–2.9 box-kites, 84 elements, types | K | de Marrais (credited); Wilmot 2025 is downstream of the same material; orientation bit NA. |
| 2.10 CAR algebra | NA | standard CAR inputs; the statement about the presentation not found. |
| 3.1–3.4 symmetry, canonical objects | K | Eakin–Sathaye / Schafer standard; 3.2 composition standard. |
| 3.5 seam ≅ G₂/SU(2) ≅ V₂(ℝ⁷); pair manifold ≅ G₂ | K | Moreno 1998 (credited). |
| 3.6 background coordinates | K | Chan–Đoković Thm 5.1 (credited); the β=√(1−|Q|²) clause KP (one-line proof). |
| 3.7 Hilbert/symplectic structure; T*𝕆 with τ as time reversal | N | elementary, not found in the searched corpus. |
| 3.8(1) fibration over G₂/SO(4) | K | folklore from SO(4)⊂G₂; the metric form is Reggiani 2024 (credited). |
| 3.8(2)–(5) canonical connection, qK curvature, holonomy, Yang–Mills (normal metric) | NA | Laquer supplies Yang–Mills [STANDARD]; the assembled identification not found; disjoint from Reggiani's induced metrics. |
| 3.9 frames, simple transitivity of Aut(S) | NA | Baez §4.1 basic triples + the Σ₃ factor (Eakin–Sathaye); the frame theorem as stated not found. |
| 4.1–4.4 splits, capability, τ-kind | N | program-specific; elementary proofs; not found. |
| 4.5, 4.6 | R | criterion and selection. |
| 4.7(i) | K | Malcev property of Im 𝕆 classical (Sagle lineage). |
| 4.7(ii) defect counts | N | the non-Malcev certificates with exact counts not found. |
| 4.7(iv) R-flux limit | K | Bakas–Lüst; Günaydin–Lüst–Malek (credited): the contraction origin is theirs. |
| 4.7(v) 15-dim extension; block classification 43/39/2 | N | script C33. |
| 4.7(vi) classification 17/13; completeness for all weights | N | script C32. |
| 4.7(vii) locked ratio 12/2 | N | observation; not found. |
| 5.1 selection inequalities | K/KP | (iii) is BCDI Prop. 4.7 (credited); (i)–(ii) elementary. |
| 5.4 uncountably many orbits in A₅ | N | dimension argument; not found stated, though elementary from Moreno-type dimension counts — classified N with that caveat. |
| 5.6 cₙ = 2^{(n−3)/2} | KP | BCDI 2009 Thm 8.2/8.3 + Cor. 4.8 (credited); the lifting-quadruple proof independent. |
| 6.1 colour as stabiliser | K | classical su(3)⊂g₂ (Springer–Veldkamp cited). |
| 6.2–6.5, 6.8–6.9 Q, so(1,3)_Q, content, exclusivity | N | program assembly with elementary proofs; the exclusivity statements not found. |
| 6.7 so(1,8), τ, Y | NA | standard Clifford/spinor inputs; assembly not found. |
| 6.6, 6.10, 6.11 | R | selections and criterion. |
| 6.12 vacuum | NA | standard Fock vacuum characterisation applied to the presentation. |
| 7.1–7.6 dynamics; finite-mode no-go | NA | standard-subspace/Tomita inputs; the no-go as stated not found. |
| 7.8 domain wall | N | exact computation; not found. |
| 7.9 canonical squeeze, failure disk | N | observation with exact content; not found. |
| 7.7 | R | boundary. |
| 8.2 | R | criterion (Stone–von Neumann standard). |
| 8.3–8.4 implementation, canonical quantisation | NA | Bargmann standard; assembly not found. |
| 8.5 necessity (doubling = second quantisation, with converse discipline) | N | program theorem; not found. |
| 8.6 no finite-dimensional modular dynamics | NA | Tomita–Takesaki standard subspaces; the statement for S not found. |
| 8.7 the two complex structures | N | elementary; not found. |
| 8.9 the states S supplies | NA | type-III input standard (Takesaki); the S-specific inventory not found. |
| 10.1–10.5 Born, sharpness, Busch scope | K/R | Busch's theorem [STANDARD] (credited); the S-specific restriction structure R with NA elements. |
| 12.1 | R | dictionary reading over standard SM content. |
| 12.3 lone scalar | N | elementary; not found. |
| 12.4 no isospin; multiplicity-freeness of Λ*S_ℂ, Sym≤4 | N | the plethysm computation [EXACT] (fock_multiplicity.py) not found. |
| 12.5 the seam's su(2) | K | SO(4)⊂G₂ classical. |
| 12.2, 12.4 table, 12.6 | R | selection and boundaries. |
| 13.1–13.4 modules, native action, broken doublet, A₆ content | N | doubling-tower module theory of the program; not found. |
| 13.7 finite questions; (iii) closure ≅ u(1)²⊕su(4), and its su(4) not conjugate to so(6)_c | N | scripts C30, C34. |
| §11 item 8; §11.8 orbit manifold (25-dim submersion image) | N | script C31; second proof of 5.4(1). |
| 14.0 the continuum is native | N | elementary; the base-change stability of the certificate layer not found stated. |
| 14.1 K3a | R | the one dynamical postulate. |
| 14.2 type III₁, uniqueness, homogeneity | K | Wiesbrock 1993 with Araki–Zsidó 2005; Haagerup 1987; Connes–Størmer 1978 — standard theorems applied under 14.1. |
| 14.3, 14.4 | R | boundary and stance. |

*The classes K and KP name the credited backbone; N and NA name what this paper asserts beyond the searched corpus. The classification is itself a claim of the paper and is maintained under the same revision discipline as the results it describes.*

*End of the deductive edition.*
