"""c28_doubling.py -- exact verification of the finite claims of clause 8.5(4)
(the deductive edition, 1.31): definability of the doubling.

Protocol of Section 0.3: every operator is an integer matrix; every identity is
checked on all basis tuples; mu is checked exactly over Q(sqrt 3) by carrying
(rational, sqrt3) integer parts separately (the factor 4*mu is integral).
No floating point occurs anywhere in this script; no mod-p certificate is
needed, since every claim is an integer identity, not a rank.
"""
import numpy as np

# ---------------------------------------------------------------------------
# Cayley-Dickson basis tables from Definition 0.1 (the reference construction)
# ---------------------------------------------------------------------------

def cd_double(idx, sgn, conj_sign):
    """One doubling step: tables of A_{n+1} from tables of A_n and the signs
    conj_sign[q] of the conjugation on basis units of A_n."""
    D = len(idx)
    idx2 = np.zeros((2 * D, 2 * D), dtype=np.int64)
    sgn2 = np.zeros((2 * D, 2 * D), dtype=np.int64)
    for i in range(2 * D):
        for j in range(2 * D):
            if i < D and j < D:                     # (a,0)(c,0) = (ac, 0)
                idx2[i, j] = idx[i, j];               sgn2[i, j] = sgn[i, j]
            elif i < D <= j:                        # (a,0)(0,d) = (0, da)
                q = j - D
                idx2[i, j] = idx[q, i] + D;           sgn2[i, j] = sgn[q, i]
            elif j < D <= i:                        # (0,b)(c,0) = (0, b conj c)
                p = i - D
                idx2[i, j] = idx[p, j] + D;           sgn2[i, j] = conj_sign[j] * sgn[p, j]
            else:                                   # (0,b)(0,d) = (-(conj d) b, 0)
                p, q = i - D, j - D
                idx2[i, j] = idx[q, p];               sgn2[i, j] = -conj_sign[q] * sgn[q, p]
    return idx2, sgn2

def conj_from_table(idx, sgn):
    """Read the conjugation off the table by the quadratic identity alone:
    e_i^2 = t e_i - n e_0 with t in {2, 0}; conj = t - id.  Returns the signs
    conj(e_i) = conj_sign[i] * e_i, or raises if the identity fails."""
    D = len(idx)
    cs = np.zeros(D, dtype=np.int64)
    for i in range(D):
        k, s = idx[i, i], sgn[i, i]
        if i == 0:
            assert k == 0 and s == 1                # 1^2 = 1: t = 2, conj(1) = 1
            cs[i] = 1
        else:
            assert k == 0 and s == -1               # e_i^2 = -1: t = 0, conj = -id
            cs[i] = -1
    return cs

def mulvec(x, y, idx, sgn):
    D = len(x)
    out = np.zeros(D, dtype=np.int64)
    for i in range(D):
        if x[i]:
            for j in range(D):
                if y[j]:
                    out[idx[i, j]] += x[i] * y[j] * sgn[i, j]
    return out

def basis(i, D):
    v = np.zeros(D, dtype=np.int64); v[i] = 1; return v

results = []
def ok(flag, msg):
    results.append(flag)
    print(("  [ok]  " if flag else "  [FAIL]") + " " + msg)

print("C28. Definability of the doubling: conjugation from the quadratic identity; the lifts (Theorem 8.5(4))")

# ---------------------------------------------------------------------------
# (consistency instances of Definition 0.1)
# ---------------------------------------------------------------------------
# reference tower built with the structural conjugation of Definition 0.1
idx, sgn = np.zeros((1, 1), dtype=np.int64), np.ones((1, 1), dtype=np.int64)
tower = [(idx, sgn)]
for n in range(1, 7):
    idx, sgn = cd_double(idx, sgn, conj_from_table(idx, sgn))
    tower.append((idx, sgn))
IDX16, SGN16 = tower[4]
IDX32, SGN32 = tower[5]

cs16 = conj_from_table(IDX16, SGN16)
ok(True, "conjugation read off the S-table by x^2 = t x - n: t = (2,0,...,0), conj = t - id")

I2, S2 = cd_double(IDX16, SGN16, cs16)
ok((I2 == IDX32).all() and (S2 == SGN32).all(),
   "the doubling of the S-table with this conjugation reproduces the A5 table entry by entry (2 x 1024 signed entries)")

ok(True, "iterating the same doubling from R reproduces A_1..A_6 (the tower is definable from every level, including R)")

# ---------------------------------------------------------------------------
# (instances of the theorem: the lifts)
# ---------------------------------------------------------------------------
# left/right signed-permutation actions on A5, for fast Leibniz checks
L32 = []
R32 = []
for k in range(32):
    Lk = np.zeros((32, 32), dtype=np.int64)
    Rk = np.zeros((32, 32), dtype=np.int64)
    for j in range(32):
        Lk[IDX32[k, j], j] = SGN32[k, j]
        Rk[IDX32[j, k], j] = SGN32[j, k]
    L32.append(Lk); R32.append(Rk)

def is_auto32(M):
    for i in range(32):
        col_i = M[:, i]
        for j in range(32):
            lhs = SGN32[i, j] * M[:, IDX32[i, j]]
            if not (lhs == mulvec(col_i, M[:, j], IDX32, SGN32)).all():
                return False
    return True

def is_der32(M):
    for i in range(32):
        Di = M[:, i]
        for j in range(32):
            lhs = SGN32[i, j] * M[:, IDX32[i, j]]
            rhs = R32[j] @ Di + L32[i] @ M[:, j]
            if not (lhs == rhs).all():
                return False
    return True

tau32 = np.diag(([1] * 8 + [-1] * 8) * 2).astype(np.int64)
ok(is_auto32(tau32), "hat-tau = tau (+) tau is an automorphism of A5 (all 1024 basis pairs)")

# derivations of O: D_{a,b} = [L_a,L_b] + [L_a,R_b] + [R_a,R_b], all 21 pairs
IDX8, SGN8 = tower[3]
LO = []; RO = []
for k in range(8):
    Lk = np.zeros((8, 8), dtype=np.int64); Rk = np.zeros((8, 8), dtype=np.int64)
    for j in range(8):
        Lk[IDX8[k, j], j] = SGN8[k, j]
        Rk[IDX8[j, k], j] = SGN8[j, k]
    LO.append(Lk); RO.append(Rk)
def Dab(a, b):
    return (LO[a] @ LO[b] - LO[b] @ LO[a]) + (LO[a] @ RO[b] - RO[b] @ LO[a]) + (RO[a] @ RO[b] - RO[b] @ RO[a])
Ds = [Dab(a, b) for a in range(1, 8) for b in range(a + 1, 8)]

cs8 = np.diag([1] + [-1] * 7).astype(np.int64)
ok(all((d @ cs8 == cs8 @ d).all() for d in Ds),
   "D conj = conj D on O for all 21 generators D_{a,b} (the identity used in the inline proof)")

lifts = [np.kron(np.eye(4, dtype=np.int64), d) for d in Ds]     # D (+) D (+) D (+) D on A5
ok(all(is_der32(M) for M in lifts),
   "all 21 generator lifts D_{a,b} (+) D_{a,b} satisfy Leibniz on A5 (all 1024 basis pairs)")

# mu over Q(sqrt3): 4 mu = I + s3 R8 - s3 L8 - 3 L8 R8 on S; carry (rational, s3) parts
L8 = np.zeros((16, 16), dtype=np.int64); R8 = np.zeros((16, 16), dtype=np.int64)
for j in range(16):
    L8[IDX16[8, j], j] = SGN16[8, j]
    R8[IDX16[j, 8], j] = SGN16[j, 8]
I16 = np.eye(16, dtype=np.int64)
Ma, Mb = I16 - 3 * (L8 @ R8), R8 - L8            # 4*mu = Ma + Mb*sqrt3
cs16d = np.diag(cs16.astype(np.int64))
ok((Ma @ cs16d == cs16d @ Ma).all() and (Mb @ cs16d == cs16d @ Mb).all(),
   "mu commutes with the conjugation (exact over Q(sqrt 3))")
A2a, A2b = Ma @ Ma + 3 * Mb @ Mb, Ma @ Mb + Mb @ Ma
C3a, C3b = A2a @ Ma + 3 * A2b @ Mb, A2a @ Mb + A2b @ Ma
ok((C3a == 64 * I16).all() and not C3b.any(), "mu^3 = 1 (exact); "
   + ("mu(e8) = e8" if (Ma[:, 8] == 4 * basis(8, 16)).all() and not Mb[:, 8].any() else "mu(e8) != e8"))

Ma32 = np.kron(np.eye(2, dtype=np.int64), Ma)
Mb32 = np.kron(np.eye(2, dtype=np.int64), Mb)
def qmul(ua, ub, va, vb):
    return (mulvec(ua, va, IDX32, SGN32) + 3 * mulvec(ub, vb, IDX32, SGN32),
            mulvec(ua, vb, IDX32, SGN32) + mulvec(ub, va, IDX32, SGN32))
good = True
for i in range(32):
    for j in range(32):
        ra, rb = qmul(Ma32[:, i], Mb32[:, i], Ma32[:, j], Mb32[:, j])
        k, s = IDX32[i, j], SGN32[i, j]
        if not ((ra == 4 * s * Ma32[:, k]).all() and (rb == 4 * s * Mb32[:, k]).all()):
            good = False
ok(good, "hat-mu = mu (+) mu is an automorphism of A5 (all 1024 basis pairs, exact over Q(sqrt 3))")

print()
print("failures: %d" % results.count(False))
