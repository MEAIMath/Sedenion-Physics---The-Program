"""Exact test: is the k-particle sector of the Fock space over (S, omega J) = Weyl (x) (3_1 + 1_-3)
multiplicity-free under sl(2,C) + su(3) + u(1)_Y ?  (fermionic Lambda^k for all k; bosonic Sym^k, k<=4)
Method: highest-weight vectors = joint kernel of the raising operators (exact, sympy); graded by the
exact weights (h, h1, h2, Y); multiplicity of a type = dim of its highest-weight space."""
import itertools, numpy as np
from sympy import Matrix, Rational, zeros, eye
# one-particle space C^8 = C^2 (x) C^4,  C^4 = C^3 (+) C^1
def E(n,i,j):
    M = zeros(n,n); M[i,j] = 1; return M
I2, I4 = eye(2), eye(4)
def kron(A,B):
    return Matrix(A.shape[0]*B.shape[0], A.shape[1]*B.shape[1], lambda r,c: A[r//B.shape[0], c//B.shape[1]]*B[r%B.shape[0], c%B.shape[1]])
# sl(2): h = diag(1,-1), e = E01, f = E10 on C^2
h2, e2, f2 = E(2,0,0)-E(2,1,1), E(2,0,1), E(2,1,0)
# sl(3) on first three coordinates of C^4: Cartan h1 = E00-E11, h2' = E11-E22; raising E01, E12, E02
h31, h32 = E(4,0,0)-E(4,1,1), E(4,1,1)-E(4,2,2)
r31, r32, r33 = E(4,0,1), E(4,1,2), E(4,0,2)
Y = E(4,0,0)+E(4,1,1)+E(4,2,2)-3*E(4,3,3)
gens_raise = [kron(e2,I4), kron(I2,r31), kron(I2,r32), kron(I2,r33)]
cartan = [kron(h2,I4), kron(I2,h31), kron(I2,h32), kron(I2,Y)]

def induced(M, k, sym):
    """action of a one-particle operator M (8x8) on Lambda^k or Sym^k as a derivation, in the
    basis of k-subsets (Lambda) or k-multisets (Sym) of {0..7}."""
    basis = list(itertools.combinations(range(8),k)) if not sym else list(itertools.combinations_with_replacement(range(8),k))
    index = {b:i for i,b in enumerate(basis)}
    N = len(basis); out = zeros(N,N)
    for c,b in enumerate(basis):
        for pos in range(k):
            for a in range(8):
                coef = M[a,b[pos]]
                if coef == 0: continue
                new = list(b); new[pos] = a
                if not sym:
                    if len(set(new)) < k: continue
                    # sort with sign
                    sign = 1; arr = new[:]
                    for i in range(k):
                        for j in range(k-1-i):
                            if arr[j] > arr[j+1]: arr[j],arr[j+1] = arr[j+1],arr[j]; sign = -sign
                    out[index[tuple(arr)], c] += sign*coef
                else:
                    out[index[tuple(sorted(new))], c] += coef
    return out, basis

def analyse(k, sym):
    R = [induced(M,k,sym)[0] for M in gens_raise]
    H = [induced(M,k,sym)[0] for M in cartan]
    N = R[0].shape[0]
    K = Matrix.vstack(*R).nullspace()          # highest-weight vectors
    # weight decomposition of K: K is Cartan-stable; diagonalise the Cartans on K
    if not K: return N, {}, True
    B = Matrix.hstack(*K)                      # N x m
    # project: find weights of basis vectors of K by simultaneous eigen-decomposition
    # (Cartans are diagonal in the monomial basis, so weight spaces are coordinate subspaces)
    weights = {}
    # weight of each monomial basis vector
    wt_of_basis = [tuple(int(Hm[i,i]) for Hm in H) for i in range(N)]
    for w in set(wt_of_basis):
        rows = [i for i in range(N) if wt_of_basis[i]==w]
        sub = B.extract(rows, list(range(B.shape[1])))
        r = sub.rank()
        if r: weights[w] = r
    return N, weights, all(v==1 for v in weights.values())

for k in range(0,9):
    N, w, mf = analyse(k, False)
    print(f"Lambda^{k}: dim {N:3d}, irreducible summands {sum(w.values()):2d}, multiplicities {sorted(w.values())}, multiplicity-free: {mf}")
for k in range(0,5):
    N, w, mf = analyse(k, True)
    print(f"Sym^{k}:    dim {N:3d}, irreducible summands {sum(w.values()):2d}, multiplicities {sorted(w.values())}, multiplicity-free: {mf}")
