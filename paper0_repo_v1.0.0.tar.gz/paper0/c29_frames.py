"""c29_frames.py -- exact verification of the finite claims of Theorem 3.9
(the deductive edition, 1.35): the Cayley-Dickson frames of the presentation.

Protocol of Section 0.3: every check is an integer identity -- over Z, over
Z[sqrt2] (integer rational and sqrt2 parts carried separately), or over
Z[sqrt3] with a scale denominator (elements (a + b sqrt3)/s, all integral).
No rank is computed, so no mod-p certificate is needed; no floating point
occurs anywhere.

A frame datum is (world, sign of e_8, basic triple); the generation rule,
read off the standard basis, is
    F_3 = F_1 F_2,  F_5 = F_1 F_4,  F_6 = F_2 F_4,  F_7 = F_3 F_4,
    F_8 = eps e_8,  F_{8+i} = F_i F_8,
and the claim verified is that each generated frame satisfies the
multiplication table of Definition 0.1 with the standard signs.
"""
import numpy as np

# ---------------------------------------------------------------- tables
def cd_double(idx, sgn, cs):
    D = len(idx)
    idx2 = np.zeros((2 * D, 2 * D), dtype=np.int64)
    sgn2 = np.zeros((2 * D, 2 * D), dtype=np.int64)
    for i in range(2 * D):
        for j in range(2 * D):
            if i < D and j < D:
                idx2[i, j] = idx[i, j];      sgn2[i, j] = sgn[i, j]
            elif i < D <= j:
                q = j - D; idx2[i, j] = idx[q, i] + D; sgn2[i, j] = sgn[q, i]
            elif j < D <= i:
                p = i - D; idx2[i, j] = idx[p, j] + D; sgn2[i, j] = cs[j] * sgn[p, j]
            else:
                p, q = i - D, j - D
                idx2[i, j] = idx[q, p];      sgn2[i, j] = -cs[q] * sgn[q, p]
    return idx2, sgn2

idx, sgn = np.zeros((1, 1), dtype=np.int64), np.ones((1, 1), dtype=np.int64)
for n in range(4):
    cs = np.array([1] + [-1] * (len(idx) - 1), dtype=np.int64)
    idx, sgn = cd_double(idx, sgn, cs)
IDX, SGN = idx, sgn                                    # the S table

def mv(x, y):
    out = np.zeros(16, dtype=np.int64)
    for i in range(16):
        if x[i]:
            for j in range(16):
                if y[j]:
                    out[IDX[i, j]] += x[i] * y[j] * SGN[i, j]
    return out

E = [np.eye(16, dtype=np.int64)[i] for i in range(16)]

results = []
def ok(flag, msg):
    results.append(flag)
    print(("  [ok]  " if flag else "  [FAIL]") + " " + msg)

print("C29. The Cayley-Dickson frames of the presentation (Theorem 3.9)")

# ------------------------------------------- the generation rule, and Z-frames
rule = ((mv(E[1], E[2]) == E[3]).all() and (mv(E[1], E[4]) == E[5]).all()
        and (mv(E[2], E[4]) == E[6]).all() and (mv(E[3], E[4]) == E[7]).all()
        and all((mv(E[i], E[8]) == E[8 + i]).all() for i in range(1, 8)))
ok(rule, "the generation rule is read off the standard basis: f3=f1f2, f5=f1f4, f6=f2f4, f7=f3f4, F_{8+i}=F_i F_8")

def frame(f1, f2, f4, eps):
    F = [E[0], f1, f2, mv(f1, f2), f4, mv(f1, f4), mv(f2, f4), mv(mv(f1, f2), f4), eps * E[8]]
    F += [mv(F[i], F[8]) for i in range(1, 8)]
    return F

def table_ok(F):
    return all((mv(F[i], F[j]) == SGN[i, j] * F[IDX[i, j]]).all()
               for i in range(16) for j in range(16))

Fstd = frame(E[1], E[2], E[4], 1)
ok(all((Fstd[i] == E[i]).all() for i in range(16)),
   "the standard datum (O, +1, (e1,e2,e4)) regenerates the standard basis")
ok(table_ok(frame(E[1], E[5], E[2], 1)),
   "the frame of (O, +1, (e1,e5,e2)) satisfies the table of Definition 0.1 on all 256 pairs")
ok(table_ok(frame(E[1], E[2], E[4], -1)),
   "the frame of (O, -1, (e1,e2,e4)) satisfies the table on all 256 pairs (the tau image)")

# ------------------------------------------- an irrational frame over Z[sqrt2]
# elements a + b sqrt2, carried as integer pairs; the triple is scaled by 2
def mv2(u, v):
    return (mv(u[0], v[0]) + 2 * mv(u[1], v[1]), mv(u[0], v[1]) + mv(u[1], v[0]))
Z = np.zeros(16, dtype=np.int64)
f1 = (Z, E[1] + E[2]); f2 = (Z, E[1] - E[2]); f4 = (2 * E[4], Z)      # 2*f
def pm(u, v):
    a, b = mv2(u, v); return (a // 2, b // 2)                          # (2f)(2g)/2 = 2*(fg)
F = [(2 * E[0], Z), f1, f2, pm(f1, f2), f4, pm(f1, f4), pm(f2, f4), pm(pm(f1, f2), f4), (2 * E[8], Z)]
F += [pm(F[i], F[8]) for i in range(1, 8)]
good = all(((mv2(F[i], F[j])[0] == 2 * SGN[i, j] * F[IDX[i, j]][0]).all()
            and (mv2(F[i], F[j])[1] == 2 * SGN[i, j] * F[IDX[i, j]][1]).all())
           for i in range(16) for j in range(16))
ok(good, "the frame of (O, +1, ((e1+e2)/sqrt2, (e1-e2)/sqrt2, e4)) satisfies the table, exactly over Q(sqrt 2)")

# ------------------------------------------- the mu-world frame over Z[sqrt3]
# 4*mu = I + sqrt3 R8 - sqrt3 L8 - 3 L8R8; elements (a + b sqrt3)/s
L8 = np.zeros((16, 16), dtype=np.int64); R8 = np.zeros((16, 16), dtype=np.int64)
for j in range(16):
    L8[IDX[8, j], j] = SGN[8, j]
    R8[IDX[j, 8], j] = SGN[j, 8]
I16 = np.eye(16, dtype=np.int64)
Ma, Mb = I16 - 3 * (L8 @ R8), R8 - L8

def mv3(u, v):   # numerator pair product over Z[sqrt3]
    return (mv(u[0], v[0]) + 3 * mv(u[1], v[1]), mv(u[0], v[1]) + mv(u[1], v[0]))
def prod(x, y):  # (numx/sx)(numy/sy)
    return (mv3(x[0], y[0]), x[1] * y[1])
mu = lambda i: ((Ma[:, i].copy(), Mb[:, i].copy()), 4)                 # mu(e_i), scale 4
G1, G2_, G4 = mu(1), mu(2), mu(4)
G0 = ((E[0], Z), 1); G8 = ((E[8], Z), 1)
Gs = [G0, G1, G2_, prod(G1, G2_), G4, prod(G1, G4), prod(G2_, G4), prod(prod(G1, G2_), G4), G8]
Gs += [prod(Gs[i], Gs[8]) for i in range(1, 8)]
def eq(x, y):    # numx/sx == numy/sy  <=>  numx*sy == numy*sx
    return (x[0][0] * y[1] == y[0][0] * x[1]).all() and (x[0][1] * y[1] == y[0][1] * x[1]).all()
good = True
for i in range(16):
    for j in range(16):
        lhs = prod(Gs[i], Gs[j])
        k, s = IDX[i, j], SGN[i, j]
        rhs = ((s * Gs[k][0][0], s * Gs[k][0][1]), Gs[k][1])
        if not eq(lhs, rhs): good = False
ok(good, "the frame of (mu O, +1, (mu e1, mu e2, mu e4)) satisfies the table, exactly over Q(sqrt 3)")
ok(all(eq(Gs[i], mu(i)) for i in range(1, 8)),
   "the generated mu-world frame agrees with the mu-images of the basis (consistency with C28)")

print()
print("failures: %d" % results.count(False))
