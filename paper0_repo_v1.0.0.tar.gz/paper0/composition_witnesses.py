"""composition_witnesses.py -- exact saturating pairs for the composition constant c_n = 2^{(n-3)/2}
in A_5, A_6, A_7, A_8, built by a uniform lifting recipe from the A_5 witness of Theorem 5.3(b).
Requires sedenion_exact.py in the same directory (for the Cayley-Dickson tables and exact nullity)."""
import numpy as np, itertools
src = open("sedenion_exact.py").read().split("# ================================================================ start")[0]
ns = {}; exec(src, ns)
Alg, exact_nullity = ns["Alg"], ns["exact_nullity"]

def pool_of(alg, x, y):
    """the witnesses, and the exact integer vectors spanning the top eigenspaces of L_z^T L_z and R_z^T R_z, z in {x,y}"""
    c2 = alg.norm2(alg.mul(x, y)) // (alg.norm2(x) * alg.norm2(y))
    pool = {tuple(x), tuple(y), tuple(-x), tuple(-y)}
    for z in (x, y):
        N = alg.norm2(z)
        for M in (alg.L(z), alg.R(z)):
            k, vs = exact_nullity(M.T @ M - c2 * N * np.eye(alg.d, dtype=np.int64))
            for v in (vs or []): pool.add(tuple(v)); pool.add(tuple(-v))
    return [np.array(p, dtype=np.int64) for p in pool]

def lift(alg_lo, alg_hi, x, y):
    """search (a,b),(c,d) in the pool with ||xy||^2 = 2 c_lo^2 ||x||^2 ||y||^2"""
    c2 = alg_lo.norm2(alg_lo.mul(x, y)) // (alg_lo.norm2(x) * alg_lo.norm2(y))
    P = pool_of(alg_lo, x, y)
    for a, b, c, d in itertools.product(P, repeat=4):
        X = np.concatenate([a, b]); Y = np.concatenate([c, d])
        if alg_hi.norm2(alg_hi.mul(X, Y)) == 2 * c2 * alg_hi.norm2(X) * alg_hi.norm2(Y):
            return X, Y, len(P)
    return None, None, len(P)

fmt = lambda v: " ".join(f"{'+' if v[i]>0 else '-'}{abs(v[i]) if abs(v[i])!=1 else ''}e_{i}" for i in np.nonzero(v)[0])
A = {n: Alg(n) for n in range(5, 9)}
x = np.zeros(32, dtype=np.int64); y = np.zeros(32, dtype=np.int64)
for c, i in [(1, 1), (1, 10), (1, 18), (-1, 25)]: x[i] = c
for c, i in [(-1, 4), (-1, 15), (-1, 23), (1, 28)]: y[i] = c
for n in range(5, 9):
    alg = A[n]
    r2 = alg.norm2(alg.mul(x, y)) / (alg.norm2(x) * alg.norm2(y))
    print(f"A_{n}: ||x||^2 = {alg.norm2(x)}, ||y||^2 = {alg.norm2(y)}, ||xy||^2 = {alg.norm2(alg.mul(x, y))}, ratio^2 = {r2:g} = 2^{n-3} = {2**(n-3)}  ->  c_{n} = 2^({n}-3)/2 exactly")
    print(f"      x = {fmt(x)}\n      y = {fmt(y)}")
    if n < 8:
        x, y, ps = lift(alg, A[n + 1], x, y)
        print(f"      lifted to A_{n+1} from a pool of {ps} elements")
