"""c32_filtrations.py -- exact verification of the completeness claims of
Proposition 4.7 (the deductive edition, 1.39): block C32, the classification of
filtration contractions of Im O is complete for all non-negative integer
weights; block C33, the block extensions of the R-flux filtration on Im S.

Protocol of Section 0.3.  All decisions are exact: tight-sets are enumerated as
closed sets under rational linear span (exact reduced echelon forms over Q);
realisable cells are certified by exhibited integer witnesses, checked over Z;  The Malcev
identity is bilinear in (y,z) and quadratic in x, so it is verified for x
running over the basis and over all pairwise sums of basis vectors.
non-realisable cells are decided by an exact rational phase-one simplex with
Bland's rule, a complete and terminating decision procedure for linear
feasibility.  No floating point occurs anywhere.
"""
import numpy as np, time
from fractions import Fraction
from itertools import product
from math import gcd
t0 = time.time()

# ---------------------------------------------------------------- tables
def cd_double(idx, sgn, cs):
    D = len(idx)
    i2 = np.zeros((2*D,2*D),dtype=np.int64); s2 = np.zeros((2*D,2*D),dtype=np.int64)
    for i in range(2*D):
        for j in range(2*D):
            if i < D and j < D:   i2[i,j]=idx[i,j];         s2[i,j]=sgn[i,j]
            elif i < D <= j:      q=j-D; i2[i,j]=idx[q,i]+D;  s2[i,j]=sgn[q,i]
            elif j < D <= i:      p=i-D; i2[i,j]=idx[p,j]+D;  s2[i,j]=cs[j]*sgn[p,j]
            else:                 p,q=i-D,j-D; i2[i,j]=idx[q,p]; s2[i,j]=-cs[q]*sgn[q,p]
    return i2, s2
idx, sgn = np.zeros((1,1),dtype=np.int64), np.ones((1,1),dtype=np.int64)
for n in range(4):
    cs = np.array([1]+[-1]*(len(idx)-1),dtype=np.int64)
    idx, sgn = cd_double(idx, sgn, cs)
IDX16, SGN16 = idx, sgn

results=[]
def ok(flag,msg):
    results.append(flag); print(("  [ok]  " if flag else "  [FAIL]")+" "+msg)

# ---------------------------------------------------------------- exact helpers
def rref(rows, ncol):
    R=[list(map(Fraction,r)) for r in rows]; out=[]; piv=[]
    for c in range(ncol):
        pr=None
        for i,row in enumerate(R):
            if row[c]!=0 and all(row[j]==0 for j in range(c)): pr=i; break
        if pr is None: continue
        row=R.pop(pr); row=[x/row[c] for x in row]
        for i,r2 in enumerate(R):
            if r2[c]!=0: R[i]=[a-r2[c]*b for a,b in zip(r2,row)]
        for i,r2 in enumerate(out):
            if r2[c]!=0: out[i]=[a-r2[c]*b for a,b in zip(r2,row)]
        out.append(row); piv.append(c)
        R=[r for r in R if any(x!=0 for x in r)]
        if not R: break
    order=sorted(range(len(out)),key=lambda i:piv[i])
    return tuple(tuple(out[i]) for i in order)

def in_span(v, basis, ncol):
    v=list(map(Fraction,v))
    for row in basis:
        c=next(j for j in range(ncol) if row[j]!=0)
        if v[c]!=0: v=[a-v[c]*b for a,b in zip(v,row)]
    return all(x==0 for x in v)

def lp_feasible(A, b):
    """decide exactly whether {x in R^d : A x >= b} is nonempty (A,b integer).
    Phase-one simplex over Q with Bland's rule: x = u - v, slacks, artificials."""
    m = len(A); d = len(A[0]) if m else 0
    rows=[]; rhs=[]
    for a,bi in zip(A,b):
        a=list(a)
        if bi<0: a=[-x for x in a]; bi=-bi; sgn=-1
        else: sgn=1
        rows.append([Fraction(x) for x in a]+[Fraction(-x) for x in a]
                    +[Fraction(-sgn) if j==len(rows) else Fraction(0) for j in range(m)])
        rhs.append(Fraction(bi))
    n = 2*d+m
    # tableau with artificial basis
    T=[rows[i]+[Fraction(1) if j==i else Fraction(0) for j in range(m)]+[rhs[i]] for i in range(m)]
    basis=[n+i for i in range(m)]
    cost=[Fraction(0)]*n+[Fraction(1)]*m+[Fraction(0)]
    z=[Fraction(0)]*(n+m+1)
    for i in range(m):
        for j in range(n+m+1): z[j]+=T[i][j]
    while True:
        # Bland: enter the smallest structural j with negative reduced cost c_j - z_j;
        # artificial columns are never allowed to re-enter the basis.
        ent=None
        for j in range(n):
            if cost[j]-z[j] < 0: ent=j; break
        if ent is None: break
        lv=None; best=None
        for i in range(m):
            if T[i][ent] > 0:
                r=T[i][-1]/T[i][ent]
                if best is None or r<best or (r==best and basis[i]<basis[lv]):
                    best=r; lv=i
        assert lv is not None, "phase-one objective unbounded: impossible"
        piv=T[lv][ent]
        T[lv]=[x/piv for x in T[lv]]
        for i in range(m):
            if i!=lv and T[i][ent]!=0:
                f=T[i][ent]; T[i]=[a-f*bb for a,bb in zip(T[i],T[lv])]
        f=z[ent]-cost[ent]
        if f!=0: z=[a-f*bb for a,bb in zip(z,T[lv])]
        basis[lv]=ent
    return z[-1]==0

# ================================================================ C32
print("C32. Completeness of the contraction classification of Im O (Proposition 4.7(vi))")
edges=[(a,b,a^b) for a in range(1,8) for b in range(a+1,8)]
G=np.zeros((21,7),dtype=np.int64)
for r,(a,b,c) in enumerate(edges):
    G[r,a-1]+=1; G[r,b-1]+=1; G[r,c-1]-=1
Grows=[tuple(int(x) for x in G[e]) for e in range(21)]

# ---- the <=6 survey and its collineation orbits ----
m6=set(); m6p=set()
shape=(7,)*7
tot=7**7
for start in range(0,tot,100000):
    idxs=np.arange(start,min(start+100000,tot))
    Wc=np.stack(np.unravel_index(idxs,shape),axis=1).astype(np.int64)
    Vc=Wc@G.T
    adm=(Vc>=0).all(axis=1)
    for row in Vc[adm]:
        m6.add(int(sum(1<<i for i in range(21) if row[i]==0)))
    admp=adm&(Wc>=1).all(axis=1)
    for row in Vc[admp]:
        m6p.add(int(sum(1<<i for i in range(21) if row[i]==0)))
del idxs,Wc,Vc,adm,admp
def apply_lin(M,x):
    bits=[(x>>k)&1 for k in range(3)]; y=0
    for k in range(3): y|=(sum(M[k][j]*bits[j] for j in range(3))%2)<<k
    return y
GL=[]
for mm in product([0,1],repeat=9):
    M=[mm[0:3],mm[3:6],mm[6:9]]
    im=[apply_lin(M,x) for x in range(1,8)]
    if sorted(im)==list(range(1,8)): GL.append({x:apply_lin(M,x) for x in range(1,8)})
eidx={frozenset((a,b)):r for r,(a,b,c) in enumerate(edges)}
perms=[[eidx[frozenset((g[a],g[b]))] for (a,b,c) in edges] for g in GL]
def orb(mask):
    best=mask
    for p in perms:
        m2=0
        for i in range(21):
            if (mask>>i)&1: m2|=1<<p[i]
        best=min(best,m2)
    return best
o6={orb(m) for m in m6}; o6p={orb(m) for m in m6p}
import gc; gc.collect()
ok(len(GL)==168 and len(o6)==18 and len(o6p)==14,
   "weights <=6: 18 collineation orbits of surviving-edge sets (17 nonzero), 14 with positive weights (13 nonzero)")

# ---- closed tight-sets ----
def intkey(B):
    out=[]
    for row in B:
        den=1
        for x in row: den=den*x.denominator//gcd(den,x.denominator)
        out.append(tuple(int(x*den) for x in row))
    return tuple(out)
def fracbasis(K):
    out=[]
    for row in K:
        lead=row[next(j for j in range(7) if row[j]!=0)]
        out.append(tuple(Fraction(x,lead) for x in row))
    return out
def closure_of(basis):
    return frozenset(e for e in range(21) if in_span(Grows[e],basis,7))
root=intkey(rref([],7))
seen={root: frozenset()}
frontier=[root]
while frontier:
    new=[]
    for K in frontier:
        T=seen[K]; B=fracbasis(K)
        for e in range(21):
            if e in T: continue
            B2=rref(B+[Grows[e]],7)
            K2=intkey(B2)
            if K2 not in seen:
                seen[K2]=closure_of(B2); new.append(K2)
    frontier=new
closed={}
for K,T in seen.items(): closed.setdefault(T,K)
ncells=len(closed)
cells=[]
for T,K in sorted(closed.items(),key=lambda kv:len(kv[0])):
    B=fracbasis(K)
    piv=[next(j for j in range(7) if row[j]!=0) for row in B] if B else []
    free=[c for c in range(7) if c not in piv]
    cols=[]
    for f in free:
        v=[Fraction(0)]*7; v[f]=Fraction(1)
        for row,p in zip(B,piv): v[p]=-row[f]
        den=1
        for x in v: den=den*x.denominator//gcd(den,x.denominator)
        cols.append([int(x*den) for x in v])
    N=np.array(cols,dtype=np.int64).T if cols else np.zeros((7,0),dtype=np.int64)
    cells.append((T,N))
del seen, frontier, closed; gc.collect()
ok(ncells==5847, "every realisable surviving-edge set is closed under linear span; the closed sets number exactly 5847")

# ---- witnesses and exact decisions ----
def wsearch(T,N,positive,K):
    d=N.shape[1]; lo=1 if positive else 0
    slack=[e for e in range(21) if e not in T]
    if d==0: return np.zeros(7,dtype=np.int64) if (lo==0 and not slack) else None
    if d==7: return np.ones(7,dtype=np.int64)      # T empty: all slacks equal 1
    Gs=G[slack].T if slack else None
    if (2*K+1)**d>600_000: K=3 if d>=6 else 4
    shape=(2*K+1,)*d; tot=(2*K+1)**d
    best=None; bestmax=None
    for start in range(0,tot,60000):
        idxs=np.arange(start,min(start+60000,tot))
        X=np.stack(np.unravel_index(idxs,shape),axis=1).astype(np.int64)-K
        W=X@N.T
        okm=(W>=lo).all(axis=1)
        if Gs is not None: okm&=(W@Gs>=1).all(axis=1)
        ix=np.nonzero(okm)[0]
        if len(ix):
            j=ix[np.argmin(W[ix].max(axis=1))]
            mx=int(W[j].max())
            if bestmax is None or mx<bestmax: best,bestmax=W[j].copy(),mx
    return best
witnesses={}; witnesses_pos={}; infeas=0
for T,N in cells:
    slack=[e for e in range(21) if e not in T]
    A=[tuple(int(x) for x in N[i]) for i in range(7)]+[tuple(int(x) for x in (G[e]@N)) for e in slack]
    if not lp_feasible(A,[0]*7+[1]*len(slack)):
        infeas+=1; continue
    w=wsearch(T,N,False,6)
    if w is None: w=wsearch(T,N,False,12)
    assert w is not None, "cell feasible by simplex but no witness in the search box"
    assert all(int(w@G[e])==0 for e in T) and all(int(w@G[e])>=1 for e in slack) and (w>=0).all()
    witnesses[T]=w
    wp=wsearch(T,N,True,6)
    if wp is None: wp=wsearch(T,N,True,12)
    if wp is not None:
        witnesses_pos[T]=wp
    else:
        assert not lp_feasible(A,[1]*7+[1]*len(slack)), \
            "cell feasible with positive weights by simplex but no witness in the search box"
ok(len(witnesses)==520 and int(max(w.max() for w in witnesses.values()))<=4,
   "exactly 520 closed sets are realisable, each certified by an integer witness with entries at most 4")
ok(len(witnesses_pos)==484 and int(max(w.max() for w in witnesses_pos.values()))<=4,
   "exactly 484 of them are realisable with strictly positive weights, entries at most 4")
ok(infeas==5327, "the remaining 5327 closed sets are infeasible, each decided by the exact rational simplex")
def mk(T): return sum(1<<e for e in T)
ok({orb(mk(T)) for T in witnesses}==o6 and {orb(mk(T)) for T in witnesses_pos}==o6p,
   "the realisable sets fall into the same 18 (resp. 14) orbits as the weights<=6 survey: the classification of 4.7(vi) is complete for all weights")

# ================================================================ C33
print("\nC33. Block extensions of the R-flux filtration on Im S (Proposition 4.7(v))")
blk={**{i:'P' for i in (1,2,3)},4:'W',**{i:'X' for i in (5,6,7)},8:'E8',
     **{i:"P'" for i in (9,10,11)},12:"W'",**{i:"X'" for i in (13,14,15)}}
world={'X':1,'P':2,'W':3}
bnames=['E8',"P'","W'","X'"]
bedges=sorted({(blk[a],blk[b],blk[a^b]) for a in range(1,16) for b in range(a+1,16)
               if SGN16[a,b]==-SGN16[b,a]})
ok(len(bedges)==31, "the block-level commutator structure of Im S has exactly 31 edges")
def coeffs(e):
    a=[0,0,0,0]; c=0
    for nm,s in ((e[0],1),(e[1],1),(e[2],-1)):
        if nm in world: c+=s*world[nm]
        else: a[bnames.index(nm)]+=s
    return tuple(a),c
H=[coeffs(e) for e in bedges]      # g_e(ext)=a.ext+c
# affine closed-set enumeration (augmented rows), feasibility by witness / exact FM
aug=[tuple(list(a)+[c]) for a,c in H]
def aclosure(basis):
    # consistency: no row in the span with zero coefficients and nonzero constant
    if any(all(r[j]==0 for j in range(4)) and r[4]!=0 for r in basis): return None
    return frozenset(e for e in range(31) if in_span(aug[e],basis,5))
aseen={rref([],5): frozenset()}
afr=[rref([],5)]
while afr:
    new=[]
    for B in afr:
        T=aseen[B]
        if T is None: continue
        for e in range(31):
            if e in T: continue
            B2=rref(list(B)+[aug[e]],5)
            if B2 not in aseen:
                aseen[B2]=aclosure(B2); new.append(B2)
    afr=new
acells={}
for B,T in aseen.items():
    if T is not None: acells.setdefault(T,B)
# realised patterns by direct survey (values shared across cells), then certify no others
EXT=np.stack(np.meshgrid(*([np.arange(0,26,dtype=np.int64)]*4),indexing='ij'),axis=-1).reshape(-1,4)
Amat=np.array([a for a,c in H],dtype=np.int64); cvec=np.array([c for a,c in H],dtype=np.int64)
VALS=EXT@Amat.T+cvec
admM=(VALS>=0).all(axis=1)
real={}
for row,ext in zip(VALS[admM],EXT[admM]):
    Tp=frozenset(int(e) for e in range(31) if row[e]==0)
    if Tp not in real: real[Tp]=tuple(int(x) for x in ext)
del EXT,VALS,admM
ratonly=0
for T in acells:
    if T in real: continue
    rows=[(tuple(1 if j==i else 0 for j in range(4)),0) for i in range(4)]
    rows+=[(H[e][0],-H[e][1]) for e in T]+[(tuple(-x for x in H[e][0]),H[e][1]) for e in T]
    rows+=[(H[e][0],1-H[e][1]) for e in range(31) if e not in T]
    A_=[a for a,_ in rows]; b_=[b for _,b in rows]
    if not lp_feasible(A_,b_): continue
    # rationally feasible: certify the region is confined to the surveyed box,
    # so its absence from the integer survey proves integer-infeasibility
    for i in range(4):
        assert not lp_feasible(A_+[tuple(1 if j==i else 0 for j in range(4))], b_+[26]), \
            "unbounded rational-only extension cell"
    ratonly+=1
ok(len(real)==43 and ratonly==11, "exactly 43 surviving patterns are admissible over all non-negative integer extension weights: each has an exhibited witness; every other closed cell is either infeasible over the rationals or (11 cells) rationally feasible but confined to the surveyed box with no integer point")

# limit algebras, Malcev test with polarisation, invariants
def limitC(ext):
    w=dict(world); w['E8'],w["P'"],w["W'"],w["X'"]=ext
    C=np.zeros((16,16),dtype=np.int64)
    for a in range(1,16):
        for b in range(1,16):
            if a!=b and SGN16[a,b]==-SGN16[b,a] and w[blk[a]]+w[blk[b]]==w[blk[a^b]]:
                C[a,b]=2*SGN16[a,b]
    return C
def AD(C):
    A=np.zeros((16,16,16),dtype=np.int64)     # A[a] = ad_{e_a}
    for a in range(1,16):
        for b in range(1,16):
            if C[a,b]: A[a][a^b,b]=C[a,b]
    return A
def malcev(C):
    A=AD(C)
    E=np.eye(16,dtype=np.int64)
    xs=[E[i] for i in range(1,16)]+[E[i]+E[j] for i in range(1,16) for j in range(i+1,16)]
    for x in xs:
        Ax=np.tensordot(x,A,axes=(0,0))       # ad_x
        Ax2=Ax@Ax
        for y in range(1,16):
            Ay=Ax[:,y]                        # [x,e_y]
            Ty=np.tensordot(Ay,A,axes=(0,0))  # ad_{[x,y]}
            lhs=Ty@Ax                         # [:,z] = [[x,y],[x,z]]
            r1=-Ax@Ty
            r2=Ax2@A[y]
            r3=np.tensordot((Ax2).T,A,axes=(1,0))[:, :, y].T   # [[ [z,x],x],y] over z
            # r3[:,z] = (sum_a (Ax2 e_z)_a A[a])[:,y]
            r3=np.einsum('az,akc->zkc',Ax2,A)[:,:,y].T
            if not (lhs==r1+r2+r3).all(): return False
    return True
mal=[]
for T,ext in sorted(real.items(),key=lambda kv:kv[1]):
    if malcev(limitC(ext)): mal.append((ext,T))
ok(len(mal)==39, "exactly 39 of the 43 patterns have Malcev limits: the Malcev property does not select a filtration")
def invars(ext):
    C=limitC(ext)
    nz=sum(1 for a in range(1,16) for b in range(a+1,16) if C[a,b])
    rows=[[C[a,b] if (a^b)==k else 0 for a in range(1,16)] for b in range(1,16) for k in range(1,16)]
    zdim=15-len(rref(rows,15)) if any(any(r) for r in rows) else 15
    A=AD(C); E=np.eye(16,dtype=np.int64)
    jac=sum(1 for a in range(1,16) for b in range(a+1,16) for c in range(b+1,16)
            if (np.tensordot(A[a][:,b],A,axes=(0,0))[:,c]
               +np.tensordot(A[b][:,c],A,axes=(0,0))[:,a]
               +np.tensordot(A[c][:,a],A,axes=(0,0))[:,b]).any())
    return nz,zdim,jac
mx=max(len(T) for _,T in mal)
tops=[(ext,T) for ext,T in mal if len(T)==mx]
inv=[invars(ext) for ext,_ in tops]
ok(len(tops)==2 and sorted(e for e,_ in tops)==[(1,1,2,2),(2,2,1,1)] and mx==9
   and all(i==(28,1,7) for i in inv),
   "exactly two patterns attain the maximal surviving structure (9 block edges): the extensions (1,1,2,2) and (2,2,1,1), both with 28 bracket pairs, a one-dimensional centre and jacobiator on 7 triples")

print()
print("failures: %d" % results.count(False))
